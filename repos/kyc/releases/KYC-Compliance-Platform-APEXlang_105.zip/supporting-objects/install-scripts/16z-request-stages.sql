--------------------------------------------------------------------------------
-- 16z Request stages and requesting country (release 105). KYC only (XXCUS).
--   Step 1: XXCMP_REQUESTS.REQUESTING_COUNTRY - the country the request is raised for (lookup JURISDICTION, the
--   party's country list). Runs before the request package body (16r), which writes it.
-- Idempotent: the column is added only when missing.
--------------------------------------------------------------------------------
begin
    xxfnd_ddl_pkg.add_column('XXCMP_REQUESTS', 'REQUESTING_COUNTRY', 'varchar2(30)');
    execute immediate q'~comment on column xxcmp_requests.requesting_country is 'Release 105: the requesting country (lookup JURISDICTION); required to submit.'~';
end;
/
--------------------------------------------------------------------------------
-- 16z step 2 (release 105): the old request status check (Draft, In Progress, ...) is dropped, only while it does not
-- have the request stages yet (step 4 adds the new one).
-- Idempotent: nothing happens once the new check is in place.
--------------------------------------------------------------------------------
begin
    for c in (select constraint_name from user_constraints
               where constraint_name = 'XXCMP_REQUESTS_CK3' and search_condition_vc not like '%UNDER_REVIEW%') loop
        xxfnd_ddl_pkg.drop_constraint('XXCMP_REQUESTS', 'XXCMP_REQUESTS_CK3');
    end loop;
end;
/
--------------------------------------------------------------------------------
-- 16z step 3 (release 105): the existing requests get their stage. The request is the parent of its case and
-- follows it: Investigation = Under Review, Pending Approval = In Approval, Pending Information = Information
-- Needed, Approved / Rejected / Cancelled the same. A request without a case: In Progress = Submitted; Approved
-- without a case (KYC not required or auto-approved) = KYC Not Required.
-- Idempotent: only In Progress requests and Approved requests whose case is still open or that have no case change.
--------------------------------------------------------------------------------
begin
    update xxcmp_requests r
       set r.request_status = (select case c.case_status when 'INVESTIGATION'       then 'UNDER_REVIEW'
                                                         when 'PENDING_APPROVAL'    then 'IN_APPROVAL'
                                                         when 'PENDING_INFORMATION' then 'INFO_NEEDED'
                                                         else c.case_status end
                                 from xxcmp_cases c
                                where c.case_id = (select max(c2.case_id) from xxcmp_cases c2 where c2.request_id = r.request_id))
     where r.request_status in ('IN_PROGRESS', 'APPROVED')
       and exists (select 1 from xxcmp_cases c where c.request_id = r.request_id
                      and c.case_status in ('INVESTIGATION', 'PENDING_APPROVAL', 'PENDING_INFORMATION', 'APPROVED',
                                            'REJECTED', 'CANCELLED'));
    update xxcmp_requests r set r.request_status = 'SUBMITTED'
     where r.request_status = 'IN_PROGRESS'
       and not exists (select 1 from xxcmp_cases c where c.request_id = r.request_id);
    update xxcmp_requests r set r.request_status = 'NOT_REQUIRED'
     where r.request_status = 'APPROVED'
       and not exists (select 1 from xxcmp_cases c where c.request_id = r.request_id);
    commit;
end;
/
--------------------------------------------------------------------------------
-- 16z step 4 (release 105): the request status check with the stages - Draft, Submitted, Under Review, In
-- Approval, Approved; Information Needed, KYC Not Required, Rejected, Cancelled.
-- Idempotent: added only when missing.
--------------------------------------------------------------------------------
begin
    xxfnd_ddl_pkg.add_constraint('XXCMP_REQUESTS', 'XXCMP_REQUESTS_CK3',
        q'~check (request_status in ('DRAFT','SUBMITTED','UNDER_REVIEW','IN_APPROVAL','INFO_NEEDED','APPROVED','NOT_REQUIRED','REJECTED','CANCELLED'))~');
end;
/
