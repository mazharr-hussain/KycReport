--------------------------------------------------------------------------------
-- 06_xxfnd_dff_pkg.sql
-- Descriptive flexfield runtime (0.5).
--
--   How a screen uses it (one shared pattern, no per-screen setup):
--     1. Dynamic Content region, PL/SQL body:
--          return xxfnd_dff_pkg.render('XXAPP_CUSTOMERS', :P10_CUSTOMER_ID,
--                                      p_context_code => :P10_DFF_CONTEXT);
--     2. Hidden page item Pnn_DFF_JSON; the application's dff.js copies the
--        field values into it when the page is submitted.
--     3. Validation (function body returning error text):
--          return xxfnd_dff_pkg.validate('XXAPP_CUSTOMERS', :P10_DFF_JSON, :P10_DFF_CONTEXT);
--     4. Process after the form's DML process:
--          xxfnd_dff_pkg.save('XXAPP_CUSTOMERS', :P10_CUSTOMER_ID, :P10_DFF_JSON, :P10_DFF_CONTEXT);
--
--   Registering a table in XXFND_DF_FLEXFIELDS and enabling contexts and
--   segments is all an administrator does; every screen carrying the region
--   renders the fields straight away.
--
--   Value exchange format (JSON keys are the reserved column names):
--     CHAR       text as entered
--     NUMBER     decimal point '.', no group separators
--     DATE       YYYY-MM-DD
--     TIMESTAMP  YYYY-MM-DDTHH24:MI[:SS]
--
--   TABLE value sets and SQL defaults may reference :CONTEXT_CODE once
--   (dynamic SQL binds by position).
--------------------------------------------------------------------------------

create or replace package xxfnd_dff_pkg authid definer as

    -- Flexfield code registered for a table, or null.
    function flexfield_for_table(p_table_name in varchar2) return varchar2;

    -- Context the row uses: reference column, user choice, stored value, default.
    function derive_context(p_table_name      in varchar2,
                            p_pk_value        in varchar2,
                            p_context_code    in varchar2 default null,
                            p_reference_value in varchar2 default null) return varchar2;

    -- HTML for the shared DFF region. Empty string when the table has no
    -- enabled DFF or no displayed segment.
    function render(p_table_name      in varchar2,
                    p_pk_value        in varchar2,
                    p_context_code    in varchar2 default null,
                    p_reference_value in varchar2 default null,
                    p_read_only       in varchar2 default 'N') return clob;

    -- First error found, or null. Used as an APEX validation.
    function validate(p_table_name      in varchar2,
                      p_values_json     in clob,
                      p_context_code    in varchar2 default null,
                      p_pk_value        in varchar2 default null,
                      p_reference_value in varchar2 default null) return varchar2;

    -- Writes ATTRIBUTE_CATEGORY and every configured segment column. Columns
    -- of contexts other than the one in use are cleared, as in EBS.
    procedure save(p_table_name      in varchar2,
                   p_pk_value        in varchar2,
                   p_values_json     in clob,
                   p_context_code    in varchar2 default null,
                   p_reference_value in varchar2 default null);

    -- SQL typed in by administrators (a TABLE value set's query, a segment's SQL default) runs with the
    -- schema's rights, so it must be a query: SELECT or WITH, one statement, :CONTEXT_CODE as the only bind.
    -- P_KIND = VALUE_SET (columns RETURN_VALUE and DISPLAY_VALUE) or DEFAULT (one value).
    -- P_PARSE = Y also parses it (setup screens, on save); the runtime re-checks without parsing.
    -- Returns the problem, or null when the SQL is acceptable.
    function admin_sql_error(p_sql in clob, p_kind in varchar2, p_parse in varchar2 default 'Y') return varchar2;

    -- Values for a segment's list: RETURN_VALUE, DISPLAY_VALUE, PARENT_VALUE.
    -- Also used by the setup screens to preview a value set.
    function value_list(p_value_set_code in varchar2,
                        p_context_code   in varchar2 default null)
        return sys_refcursor;


    -- Release 80 (from XXFND_DFF_SETUP_PKG): setup checks, called from the XXFND_DF_FLEXFIELDS / XXFND_DF_SEGMENTS
    -- triggers.
    procedure check_segment(p_dff_code      in varchar2,
                            p_context_code  in varchar2,
                            p_segment_code  in varchar2,
                            p_column_name   in varchar2,
                            p_value_set     in varchar2);
    procedure check_flexfield(p_table_name in varchar2, p_pk_column in varchar2,
                              p_context_column in varchar2, p_reference_column in varchar2);
    -- Creates or replaces <TABLE>_DFV: one readable column per segment, for reports and integrations (EBS "DFV"
    -- views). Release 80: GENERATE_ALL_DFV_VIEWS covers this schema's own tables only.
    procedure generate_dfv_view(p_dff_code in varchar2);
    procedure generate_all_dfv_views;
    -- Release 80: the flexfield's name (English) and its protected GLOBAL context, saved from page 153.
    procedure save_flexfield_name(p_dff_code in varchar2, p_flexfield_name in varchar2);

    -- Release 86: registration by an application. Added only when missing; what an administrator changed is kept;
    -- a re-run does nothing. The application must be registered (ORA-20180); a row of another application is refused
    -- (ORA-20186). COMMON's rows are the instance's (no application). Names: English, P_..._AR Arabic.
    -- Release 92 (UI issue 7): the value set that validates a segment against a lookup type (XXFND_LK_<TYPE>,
    -- INDEPENDENT, registered for the flexfield's application when missing); the segment grid offers lookups directly.
    function lookup_value_set(p_application_code in varchar2, p_lookup_type in varchar2) return varchar2;
    procedure register_value_set(p_application_code      in varchar2,
                                 p_value_set_code        in varchar2,
                                 p_value_set_name        in varchar2,
                                 p_validation_type       in varchar2 default 'NONE',
                                 p_format_type           in varchar2 default 'CHAR',
                                 p_maximum_size          in number   default null,
                                 p_lookup_type           in varchar2 default null,
                                 p_parent_value_set_code in varchar2 default null,
                                 p_table_query           in clob     default null,
                                 p_description           in varchar2 default null,
                                 p_uppercase_only_flag   in varchar2 default 'N',
                                 p_number_precision      in number   default null,
                                 p_minimum_value         in varchar2 default null,
                                 p_maximum_value         in varchar2 default null);
    -- The flexfield of a table (one per table: ORA-20190 when the table has another one), its name and its protected
    -- GLOBAL context.
    procedure register_flexfield(p_application_code             in varchar2,
                                 p_dff_code                     in varchar2,
                                 p_table_name                   in varchar2,
                                 p_pk_column_name               in varchar2,
                                 p_flexfield_name               in varchar2,
                                 p_flexfield_name_ar            in varchar2 default null,
                                 p_context_column_name          in varchar2 default 'ATTRIBUTE_CATEGORY',
                                 p_context_reference_column     in varchar2 default null,
                                 p_default_context_code         in varchar2 default null,
                                 p_context_required_flag        in varchar2 default 'N',
                                 p_context_user_selectable_flag in varchar2 default 'N',
                                 p_description                  in varchar2 default null,
                                 -- release 92: GLOBAL, ATTRIBUTE, FUNCTION or USER (default: from the reference column / user flag)
                                 p_context_rule_type            in varchar2 default null,
                                 p_context_rule_function        in varchar2 default null);
    -- A context of the application's flexfield (ORA-20187 when the flexfield is not registered).
    procedure register_context(p_application_code in varchar2,
                               p_dff_code         in varchar2,
                               p_context_code     in varchar2,
                               p_context_name     in varchar2,
                               p_context_name_ar  in varchar2 default null,
                               p_description      in varchar2 default null);
    -- Release 88 (C8, C9): removes what the application registered (its own rows only, through
    -- XXFND_APPLICATION_PKG.REMOVE_REGISTERED: ORA-20187 not registered, ORA-20186 another application's, ORA-20196 in use).
    procedure unregister_context(p_application_code in varchar2, p_flexfield_code in varchar2, p_context_code in varchar2);
    -- the flexfield with its contexts and segments
    procedure unregister_flexfield(p_application_code in varchar2, p_flexfield_code in varchar2);
    procedure unregister_value_set(p_application_code in varchar2, p_value_set_code in varchar2);
    procedure unregister_application(p_application_code in varchar2);
end xxfnd_dff_pkg;
/
