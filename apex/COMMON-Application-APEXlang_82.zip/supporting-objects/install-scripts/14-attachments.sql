--------------------------------------------------------------------------------
-- 07_xxfnd_attach_pkg.sql
-- Attachments runtime (0.1), EBS model: a document (XXFND_DOCUMENTS) is linked
-- to any registered entity row (XXFND_ATTACHED_DOCUMENTS, ENTITY_NAME + PK1-5).
-- Files live in Oracle UCM, SharePoint or the database; XXFND_STORAGE_CONFIG decides where.
-- This package owns the attachment rules: categories, expiry and recency, versions, permissions per page
-- region, soft delete - and (release 81) the store transport, merged from XXFND_ATTACH_STORE_PKG.
--------------------------------------------------------------------------------
-- Upload limits (R15): per document category and per attachment page; the application default is in the
-- application settings ATTACH_MAX_FILE_SIZE_MB and ATTACH_ALLOWED_FILE_TYPES.
begin
    for t in (select column_value table_name from table(apex_t_varchar2('XXFND_DOCUMENT_CATEGORIES', 'XXFND_ATTACHMENT_FUNCTIONS'))) loop
        xxfnd_ddl_pkg.add_column(t.table_name, 'MAX_FILE_SIZE_MB',   'number');
        xxfnd_ddl_pkg.add_column(t.table_name, 'ALLOWED_FILE_TYPES', 'varchar2(500)');
        xxfnd_audit_pkg.create_audit_trigger(t.table_name);   -- audit the new columns too
    end loop;
end;
/
comment on column xxfnd_document_categories.max_file_size_mb is 'Largest file accepted for this category (MB); overrides the page and the application default.';
comment on column xxfnd_document_categories.allowed_file_types is 'File extensions accepted for this category, comma-separated (e.g. pdf,jpg); * = any; overrides the page and the application default.';
comment on column xxfnd_attachment_functions.max_file_size_mb is 'Largest file accepted on this page (MB) unless the category says otherwise; overrides the application default.';
comment on column xxfnd_attachment_functions.allowed_file_types is 'File extensions accepted on this page unless the category says otherwise; overrides the application default.';

create or replace package xxfnd_attach_pkg authid definer as

    -- Most specific enabled storage row: entity+category, entity, category, default; DATABASE when none.
    function resolve_storage(p_entity_name in varchar2, p_category_code in varchar2)
        return xxfnd_storage_config%rowtype;

    -- Y/N: may the current page region insert/update/delete attachments of this entity?
    -- P_ACTION = INSERT | UPDATE | DELETE. Used in button server-side conditions.
    function block_permission(p_app_alias        in varchar2,
                              p_page_id          in number,
                              p_region_static_id in varchar2,
                              p_entity_name      in varchar2,
                              p_action           in varchar2) return varchar2;

    -- Y/N: may this page offer this category (no usage rows = all categories).
    function category_allowed(p_app_alias in varchar2, p_page_id in number,
                              p_category_code in varchar2) return varchar2;

    -- Upload a file from APEX_APPLICATION_TEMP_FILES (File Browse item value).
    -- Returns ATTACHED_DOCUMENT_ID.
    function add_file(p_entity_name    in varchar2,
                      p_pk1_value      in varchar2,
                      p_category_code  in varchar2,
                      p_temp_file_name in varchar2,
                      p_title          in varchar2 default null,
                      p_description    in varchar2 default null,
                      p_document_date  in date     default null,
                      p_expiry_date    in date     default null,
                      p_pk2_value      in varchar2 default null,
                      p_pk3_value      in varchar2 default null,
                      p_pk4_value      in varchar2 default null,
                      p_pk5_value      in varchar2 default null,
                      p_page_id        in number   default null) return number;

    -- Short/long text (DATATYPE SHORT_TEXT or LONG_TEXT) or web page link (WEB_PAGE).
    function add_text(p_entity_name   in varchar2,
                      p_pk1_value     in varchar2,
                      p_category_code in varchar2,
                      p_datatype_code in varchar2,
                      p_title         in varchar2,
                      p_text          in clob     default null,
                      p_url           in varchar2 default null,
                      p_description   in varchar2 default null,
                      p_pk2_value     in varchar2 default null,
                      p_pk3_value     in varchar2 default null,
                      p_pk4_value     in varchar2 default null,
                      p_pk5_value     in varchar2 default null) return number;

    -- Replace the file with a new version; the attachment then points at it.
    -- Earlier versions stay in XXFND_DOCUMENTS and in the external store.
    procedure add_version(p_attached_document_id in number,
                          p_temp_file_name       in varchar2,
                          p_document_date        in date default null,
                          p_expiry_date          in date default null,
                          p_page_id              in number   default null);

    -- Upload limits: the category's value, else the attachment page's (P_PAGE_ID = the page that shows the
    -- attachments), else the application setting. Types: lower-case extensions, comma-separated; * = any.
    function max_file_size_mb(p_page_id in number, p_category_code in varchar2) return number;
    function allowed_file_types(p_page_id in number, p_category_code in varchar2) return varchar2;
    -- "PDF, JPG, PNG up to 10 MB" for the upload item's help text.
    function upload_rules_text(p_page_id in number, p_category_code in varchar2) return varchar2;

    -- Release 81: the display name of a registered document entity (page 131), in English.
    procedure save_entity_display_name(p_entity_name in varchar2, p_display_name in varchar2);

    procedure update_details(p_attached_document_id in number,
                             p_title                in varchar2,
                             p_description          in varchar2,
                             p_document_date        in date,
                             p_expiry_date          in date,
                             p_seq_num              in number default null);

    -- Soft delete (EBS: EXPIRATION_DATE). The row and the stored file remain.
    procedure remove(p_attached_document_id in number);

    -- Streams the file to the browser (APEX_HTTP.DOWNLOAD). Call from an
    -- Ajax/before-header process; it stops the APEX engine when done.
    procedure download(p_document_id in number, p_inline in varchar2 default 'N');

    -- Copy all current attachments from one record to another (EBS COPY_ATTACHMENTS),
    -- e.g. from an intake request to the party. Shares the stored file.
    procedure copy_attachments(p_from_entity in varchar2, p_from_pk1 in varchar2,
                               p_to_entity   in varchar2, p_to_pk1   in varchar2,
                               p_category_code in varchar2 default null);

end xxfnd_attach_pkg;
/

create or replace package body xxfnd_attach_pkg as

    -- application defaults when the ATTACH_* application settings are empty
    c_default_size_mb constant number        := 10;
    c_default_types   constant varchar2(200) := 'pdf,jpg,jpeg,png,tif,tiff,doc,docx,xls,xlsx,msg,eml';

    ----------------------------------------------------------------------------
    -- release 81: the document store transport (was XXFND_ATTACH_STORE_PKG, 13): Oracle UCM (WebCenter Content)
    -- and SharePoint (Microsoft Graph); DATABASE (xxfnd_document_files) when nothing is configured.
    -- and SharePoint (Microsoft Graph); DATABASE (xxfnd_document_files) when nothing is configured. Kept apart from XXFND_ATTACH_PKG so the
    -- attachment rules and the storage protocols can change independently.
    --   UCM         POST <base_url>/cs/idcplg  IdcService=CHECKIN_UNIVERSAL (multipart,
    --               IsJson=1), GET_FILE by dID. Web Credential: Basic.
    --   SharePoint  <base_url> = https://graph.microsoft.com/v1.0
    --               PUT /drives/{drive}/root:/{path}/{file}:/content (<= 4 MB) or an
    --               upload session in 3.2 MB chunks; a new version is written to the
    --               same drive item. Download through @microsoft.graph.downloadUrl, or
    --               /versions/{id}/content for an older version.
    --               Web Credential: OAuth2 client credentials (scope set on the
    --               credential); token URL from XXFND_INTEGRATION_ENDPOINTS.
    --   Every external call is logged in XXFND_TRANSMISSIONS (purpose
    --   DOCUMENT_STORAGE) in an autonomous transaction. File bytes are never logged.
    ----------------------------------------------------------------------------
    c_purpose  constant varchar2(30) := 'DOCUMENT_STORAGE';
    c_database constant varchar2(30) := 'DATABASE';
    type t_stored is record (
        external_document_id varchar2(500),
        external_version_id  varchar2(500),
        external_url         varchar2(2000));


    c_crlf       constant varchar2(2) := chr(13) || chr(10);
    c_simple_max constant number := 4 * 1024 * 1024;      -- Graph simple-upload limit
    c_chunk      constant number := 10 * 327680;          -- 3.2 MB, multiple of 320 KiB

    function get_endpoint(p_endpoint_code in varchar2) return xxfnd_integration_endpoints%rowtype is
        l_ep xxfnd_integration_endpoints%rowtype;
    begin
        select * into l_ep from xxfnd_integration_endpoints where endpoint_code = p_endpoint_code;
        if l_ep.status_code <> 'ACTIVE' then
            raise_application_error(-20301, 'Storage endpoint ' || p_endpoint_code || ' is not active.');
        end if;
        return l_ep;
    end get_endpoint;

    ----------------------------------------------------------------------------
    -- transmission log (autonomous: survives a page rollback)
    ----------------------------------------------------------------------------
    function log_start(p_endpoint in varchar2, p_entity in varchar2, p_pk1 in varchar2,
                       p_method in varchar2, p_url in varchar2, p_payload in clob) return number is
        pragma autonomous_transaction;
        l_id number;
    begin
        insert into xxfnd_transmissions (endpoint_code, purpose_code, entity_name, pk1_value,
                                         http_method, request_url, request_payload, status_code, created_by)
        values (p_endpoint, c_purpose, p_entity, p_pk1, p_method, substr(p_url, 1, 4000), p_payload,
                'PENDING', xxfnd_util_pkg.current_user)
        returning transmission_id into l_id;
        commit;
        return l_id;
    end log_start;

    procedure log_end(p_id in number, p_status in number, p_response in clob, p_error in varchar2) is
        pragma autonomous_transaction;
        l_resp clob := p_response;
    begin
        -- Keep the log small: the first 8000 characters are enough to diagnose a failure.
        if dbms_lob.getlength(p_response) > 8000 then
            l_resp := dbms_lob.substr(p_response, 8000, 1);
        end if;
        update xxfnd_transmissions
           set response_status_code = p_status,
               response_payload     = l_resp,
               status_code          = case when p_error is null then 'SUCCESS' else 'FAILED' end,
               error_message        = substr(p_error, 1, 4000),
               responded_date       = systimestamp
         where transmission_id = p_id;
        commit;
    end log_end;

    -- URL-encode each path segment, keep the slashes.
    function encode_path(p_path in varchar2) return varchar2 is
        l_parts apex_t_varchar2 := apex_string.split(p_path, '/');
        l_out   varchar2(4000);
    begin
        for i in 1 .. l_parts.count loop
            if l_parts(i) is not null then
                l_out := l_out || case when l_out is not null then '/' end
                      || utl_url.escape(l_parts(i), true, 'AL32UTF8');
            end if;
        end loop;
        return l_out;
    end encode_path;

    procedure raise_http(p_what in varchar2, p_body in clob) is
    begin
        raise_application_error(-20310, p_what || ' failed (HTTP ' || apex_web_service.g_status_code || '): '
            || dbms_lob.substr(p_body, 500, 1));
    end raise_http;

    ----------------------------------------------------------------------------
    -- UCM (WebCenter Content)
    ----------------------------------------------------------------------------
    procedure add_part(p_body in out nocopy blob, p_boundary in varchar2, p_name in varchar2, p_value in varchar2) is
    begin
        dbms_lob.append(p_body, utl_i18n.string_to_raw(
            '--' || p_boundary || c_crlf
            || 'Content-Disposition: form-data; name="' || p_name || '"' || c_crlf || c_crlf
            || p_value || c_crlf, 'AL32UTF8'));
    end add_part;

    function ucm_checkin(p_ep in xxfnd_integration_endpoints%rowtype, p_cfg in xxfnd_storage_config%rowtype,
                         p_entity in varchar2, p_pk1 in varchar2, p_folder in varchar2,
                         p_file in blob, p_filename in varchar2, p_mime in varchar2,
                         p_title in varchar2, p_existing_doc_name in varchar2) return t_stored is
        l_boundary varchar2(60) := 'xxfnd' || rawtohex(sys_guid());
        l_body     blob;
        l_url      varchar2(2000) := rtrim(p_ep.base_url, '/') || '/cs/idcplg';
        l_resp     clob;
        l_json     json_object_t;
        l_local    json_object_t;
        l_log_id   number;
        l_stored   t_stored;
        l_status   varchar2(30);
        l_meta     json_object_t;
    begin
        dbms_lob.createtemporary(l_body, true);
        add_part(l_body, l_boundary, 'IdcService', 'CHECKIN_UNIVERSAL');
        add_part(l_body, l_boundary, 'IsJson', '1');
        add_part(l_body, l_boundary, 'dDocTitle', substr(nvl(p_title, p_filename), 1, 255));
        add_part(l_body, l_boundary, 'dDocType', nvl(p_cfg.ucm_doc_type, 'Document'));
        add_part(l_body, l_boundary, 'dSecurityGroup', p_cfg.ucm_security_group);
        if p_cfg.ucm_doc_account is not null then
            add_part(l_body, l_boundary, 'dDocAccount', p_cfg.ucm_doc_account);
        end if;
        add_part(l_body, l_boundary, 'dDocAuthor', xxfnd_util_pkg.current_user);
        add_part(l_body, l_boundary, 'xComments', substr(p_folder, 1, 255));
        if p_existing_doc_name is not null then
            add_part(l_body, l_boundary, 'dDocName', p_existing_doc_name);   -- new revision
        end if;
        dbms_lob.append(l_body, utl_i18n.string_to_raw(
            '--' || l_boundary || c_crlf
            || 'Content-Disposition: form-data; name="primaryFile"; filename="' || replace(p_filename, '"', '') || '"' || c_crlf
            || 'Content-Type: ' || nvl(p_mime, 'application/octet-stream') || c_crlf || c_crlf, 'AL32UTF8'));
        dbms_lob.append(l_body, p_file);
        dbms_lob.append(l_body, utl_i18n.string_to_raw(c_crlf || '--' || l_boundary || '--' || c_crlf, 'AL32UTF8'));

        l_meta := json_object_t();
        l_meta.put('service', 'CHECKIN_UNIVERSAL');
        l_meta.put('fileName', p_filename);
        l_meta.put('bytes', dbms_lob.getlength(p_file));
        l_meta.put('revisionOf', p_existing_doc_name);
        l_log_id := log_start(p_ep.endpoint_code, p_entity, p_pk1, 'POST', l_url, l_meta.to_clob);

        apex_web_service.clear_request_headers;
        apex_web_service.set_request_headers(
            p_name_01  => 'Content-Type',
            p_value_01 => 'multipart/form-data; boundary=' || l_boundary,
            p_reset    => true);
        begin
            l_resp := apex_web_service.make_rest_request(
                          p_url                  => l_url,
                          p_http_method          => 'POST',
                          p_body_blob            => l_body,
                          p_credential_static_id => p_ep.web_credential_static_id);
        exception
            when others then
                log_end(l_log_id, null, null, sqlerrm);
                raise;
        end;

        if apex_web_service.g_status_code not between 200 and 299 then
            log_end(l_log_id, apex_web_service.g_status_code, l_resp, 'HTTP ' || apex_web_service.g_status_code);
            raise_http('UCM check-in', l_resp);
        end if;

        l_json   := json_object_t.parse(l_resp);
        l_local  := l_json.get_object('LocalData');
        l_status := l_local.get_string('StatusCode');
        if nvl(l_status, '0') <> '0' then
            log_end(l_log_id, apex_web_service.g_status_code, l_resp, l_local.get_string('StatusMessage'));
            raise_application_error(-20311, 'UCM check-in failed: ' || l_local.get_string('StatusMessage'));
        end if;

        l_stored.external_document_id := l_local.get_string('dDocName');
        l_stored.external_version_id  := l_local.get_string('dID');
        l_stored.external_url         := rtrim(p_ep.base_url, '/') || '/cs/idcplg?IdcService=DOC_INFO&dID='
                                         || l_stored.external_version_id;
        log_end(l_log_id, apex_web_service.g_status_code, l_resp, null);
        dbms_lob.freetemporary(l_body);
        return l_stored;
    end ucm_checkin;

    function ucm_get_file(p_ep in xxfnd_integration_endpoints%rowtype, p_dId in varchar2,
                          p_entity in varchar2, p_pk1 in varchar2) return blob is
        l_url    varchar2(2000) := rtrim(p_ep.base_url, '/') || '/cs/idcplg?IdcService=GET_FILE&dID='
                                   || utl_url.escape(p_dId, true);
        l_blob   blob;
        l_log_id number := log_start(p_ep.endpoint_code, p_entity, p_pk1, 'GET', l_url, null);
    begin
        apex_web_service.clear_request_headers;
        l_blob := apex_web_service.make_rest_request_b(
                      p_url                  => l_url,
                      p_http_method          => 'GET',
                      p_credential_static_id => p_ep.web_credential_static_id);
        if apex_web_service.g_status_code not between 200 and 299 then
            log_end(l_log_id, apex_web_service.g_status_code, null, 'HTTP ' || apex_web_service.g_status_code);
            raise_http('UCM download', null);
        end if;
        log_end(l_log_id, apex_web_service.g_status_code, null, null);
        return l_blob;
    end ucm_get_file;

    ----------------------------------------------------------------------------
    -- SharePoint (Microsoft Graph)
    ----------------------------------------------------------------------------
    -- Graph calls pass the Web Credential and token URL; APEX obtains and caches
    -- the OAuth2 client-credentials token itself, using the scope configured on
    -- the Web Credential (XXFND_INTEGRATION_ENDPOINTS.OAUTH_SCOPE records it).
    procedure graph_auth(p_ep in xxfnd_integration_endpoints%rowtype) is
    begin
        if p_ep.oauth_token_url is null then
            raise_application_error(-20318, 'Endpoint ' || p_ep.endpoint_code || ' needs an OAuth token URL.');
        end if;
        apex_web_service.clear_request_headers;
    end graph_auth;

    function graph_item(p_resp in clob, p_url in varchar2) return t_stored is
        l_item   json_object_t := json_object_t.parse(p_resp);
        l_stored t_stored;
    begin
        l_stored.external_document_id := l_item.get_string('id');
        l_stored.external_version_id  := l_item.get_string('eTag');
        l_stored.external_url         := l_item.get_string('webUrl');
        return l_stored;
    end graph_item;

    function sp_upload(p_ep in xxfnd_integration_endpoints%rowtype, p_cfg in xxfnd_storage_config%rowtype,
                       p_entity in varchar2, p_pk1 in varchar2, p_folder in varchar2,
                       p_file in blob, p_filename in varchar2, p_mime in varchar2,
                       p_existing_item_id in varchar2) return t_stored is
        l_base    varchar2(2000) := rtrim(p_ep.base_url, '/') || '/drives/' || p_cfg.sharepoint_drive_id;
        l_target  varchar2(4000);
        l_size    number := dbms_lob.getlength(p_file);
        l_resp    clob;
        l_log_id  number;
        l_session varchar2(4000);
        l_offset  number := 1;
        l_len     number;
        l_chunk   blob;
        l_meta    json_object_t;
        l_stored  t_stored;
    begin
        -- Existing item = new version of the same file; otherwise a path under the folder.
        l_target := case when p_existing_item_id is not null
                         then l_base || '/items/' || p_existing_item_id
                         else l_base || '/root:/' || encode_path(p_folder || '/' || p_filename) || ':' end;

        l_meta := json_object_t();
        l_meta.put('fileName', p_filename);
        l_meta.put('bytes', l_size);
        l_meta.put('folder', p_folder);
        l_meta.put('versionOf', p_existing_item_id);
        l_log_id := log_start(p_ep.endpoint_code, p_entity, p_pk1,
                              case when l_size <= c_simple_max then 'PUT' else 'POST' end, l_target,
                              l_meta.to_clob);
        begin
            graph_auth(p_ep);
            if l_size <= c_simple_max then
                apex_web_service.set_request_headers(
                    p_name_01 => 'Content-Type', p_value_01 => nvl(p_mime, 'application/octet-stream'),
                    p_reset   => false);
                l_resp := apex_web_service.make_rest_request(
                              p_url => l_target || '/content', p_http_method => 'PUT', p_body_blob => p_file,
                              p_credential_static_id => p_ep.web_credential_static_id,
                              p_token_url            => p_ep.oauth_token_url);
                if apex_web_service.g_status_code not in (200, 201) then
                    log_end(l_log_id, apex_web_service.g_status_code, l_resp, 'HTTP ' || apex_web_service.g_status_code);
                    raise_http('SharePoint upload', l_resp);
                end if;
            else
                apex_web_service.set_request_headers(
                    p_name_01 => 'Content-Type', p_value_01 => 'application/json', p_reset => false);
                l_resp := apex_web_service.make_rest_request(
                              p_url         => l_target || '/createUploadSession',
                              p_http_method => 'POST',
                              p_body        => '{"item":{"@microsoft.graph.conflictBehavior":"replace"}}',
                              p_credential_static_id => p_ep.web_credential_static_id,
                              p_token_url            => p_ep.oauth_token_url);
                if apex_web_service.g_status_code not in (200, 201) then
                    log_end(l_log_id, apex_web_service.g_status_code, l_resp, 'HTTP ' || apex_web_service.g_status_code);
                    raise_http('SharePoint upload session', l_resp);
                end if;
                l_session := json_object_t.parse(l_resp).get_string('uploadUrl');

                -- The upload URL is pre-authorised; Graph rejects an Authorization header on it.
                while l_offset <= l_size loop
                    l_len := least(c_chunk, l_size - l_offset + 1);
                    dbms_lob.createtemporary(l_chunk, true);
                    dbms_lob.copy(l_chunk, p_file, l_len, 1, l_offset);
                    apex_web_service.clear_request_headers;
                    apex_web_service.set_request_headers(
                        p_name_01  => 'Content-Range',
                        p_value_01 => 'bytes ' || (l_offset - 1) || '-' || (l_offset + l_len - 2) || '/' || l_size,
                        p_reset    => true);
                    l_resp := apex_web_service.make_rest_request(
                                  p_url => l_session, p_http_method => 'PUT', p_body_blob => l_chunk);
                    dbms_lob.freetemporary(l_chunk);
                    if apex_web_service.g_status_code not in (200, 201, 202) then
                        log_end(l_log_id, apex_web_service.g_status_code, l_resp, 'HTTP ' || apex_web_service.g_status_code);
                        raise_http('SharePoint chunk upload', l_resp);
                    end if;
                    l_offset := l_offset + l_len;
                end loop;
            end if;
        exception
            when others then
                if sqlcode not in (-20310) then
                    log_end(l_log_id, apex_web_service.g_status_code, l_resp, sqlerrm);
                end if;
                raise;
        end;
        log_end(l_log_id, apex_web_service.g_status_code, l_resp, null);
        l_stored := graph_item(l_resp, l_target);

        -- Record the SharePoint version ID so an older version can be downloaded later.
        begin
            graph_auth(p_ep);
            l_resp := apex_web_service.make_rest_request(
                          p_url         => l_base || '/items/' || l_stored.external_document_id
                                           || '/versions?$select=id&$top=1',
                          p_http_method => 'GET',
                          p_credential_static_id => p_ep.web_credential_static_id,
                          p_token_url            => p_ep.oauth_token_url);
            if apex_web_service.g_status_code = 200 then
                l_stored.external_version_id := nvl(
                    treat(json_object_t.parse(l_resp).get_array('value').get(0) as json_object_t).get_string('id'),
                    l_stored.external_version_id);
            end if;
        exception
            when others then
                null;   -- keep the eTag; downloads of the current version do not need the version ID
        end;
        return l_stored;
    end sp_upload;

    function sp_download(p_ep in xxfnd_integration_endpoints%rowtype, p_cfg in xxfnd_storage_config%rowtype,
                         p_item_id in varchar2, p_version_id in varchar2, p_is_current in boolean,
                         p_entity in varchar2, p_pk1 in varchar2) return blob is
        l_url    varchar2(2000) := rtrim(p_ep.base_url, '/') || '/drives/' || p_cfg.sharepoint_drive_id
                                   || '/items/' || p_item_id || '?$select=id,@microsoft.graph.downloadUrl';
        l_resp   clob;
        l_dl     varchar2(4000);
        l_blob   blob;
        l_log_id number;
    begin
        if not p_is_current and p_version_id is not null and p_version_id not like '"%' then
            -- Older version: Graph redirects /versions/{id}/content to the file.
            l_url := rtrim(p_ep.base_url, '/') || '/drives/' || p_cfg.sharepoint_drive_id
                  || '/items/' || p_item_id || '/versions/' || utl_url.escape(p_version_id, true) || '/content';
            l_log_id := log_start(p_ep.endpoint_code, p_entity, p_pk1, 'GET', l_url, null);
            graph_auth(p_ep);
            l_blob := apex_web_service.make_rest_request_b(p_url => l_url, p_http_method => 'GET',
                          p_credential_static_id => p_ep.web_credential_static_id,
                          p_token_url            => p_ep.oauth_token_url);
            log_end(l_log_id, apex_web_service.g_status_code, null,
                    case when apex_web_service.g_status_code <> 200 then 'HTTP ' || apex_web_service.g_status_code end);
            if apex_web_service.g_status_code <> 200 then
                raise_http('SharePoint version download', null);
            end if;
            return l_blob;
        end if;

        l_log_id := log_start(p_ep.endpoint_code, p_entity, p_pk1, 'GET', l_url, null);
        graph_auth(p_ep);
        l_resp := apex_web_service.make_rest_request(p_url => l_url, p_http_method => 'GET',
                      p_credential_static_id => p_ep.web_credential_static_id,
                      p_token_url            => p_ep.oauth_token_url);
        if apex_web_service.g_status_code <> 200 then
            log_end(l_log_id, apex_web_service.g_status_code, l_resp, 'HTTP ' || apex_web_service.g_status_code);
            raise_http('SharePoint download', l_resp);
        end if;
        l_dl := json_object_t.parse(l_resp).get_string('@microsoft.graph.downloadUrl');
        apex_web_service.clear_request_headers;     -- short-lived pre-authorised URL
        l_blob := apex_web_service.make_rest_request_b(p_url => l_dl, p_http_method => 'GET');
        log_end(l_log_id, apex_web_service.g_status_code, null,
                case when apex_web_service.g_status_code <> 200 then 'HTTP ' || apex_web_service.g_status_code end);
        if apex_web_service.g_status_code <> 200 then
            raise_http('SharePoint download', null);
        end if;
        return l_blob;
    end sp_download;

    ----------------------------------------------------------------------------
    -- public
    ----------------------------------------------------------------------------
    function database_config return xxfnd_storage_config%rowtype is
        l_cfg xxfnd_storage_config%rowtype;
    begin
        l_cfg.storage_type := c_database;
        return l_cfg;
    end database_config;

    function upload(p_cfg                  in xxfnd_storage_config%rowtype,
                    p_entity               in varchar2,
                    p_pk1                  in varchar2,
                    p_folder               in varchar2,
                    p_file                 in blob,
                    p_filename             in varchar2,
                    p_mime                 in varchar2,
                    p_title                in varchar2,
                    p_previous_external_id in varchar2) return t_stored is
        l_ep     xxfnd_integration_endpoints%rowtype;
        l_stored t_stored;
    begin
        if p_cfg.storage_type = c_database then
            insert into xxfnd_document_files (file_content) values (p_file)
            returning to_char(file_id) into l_stored.external_document_id;
            l_stored.external_version_id := l_stored.external_document_id;
            return l_stored;
        end if;
        l_ep := get_endpoint(p_cfg.endpoint_code);
        if p_cfg.storage_type = 'UCM' then
            return ucm_checkin(l_ep, p_cfg, p_entity, p_pk1, p_folder, p_file, p_filename, p_mime,
                               p_title, p_previous_external_id);
        end if;
        return sp_upload(l_ep, p_cfg, p_entity, p_pk1, p_folder, p_file, p_filename, p_mime,
                         p_previous_external_id);
    end upload;

    function fetch_file(p_doc        in xxfnd_documents%rowtype,
                        p_is_current in boolean,
                        p_entity     in varchar2,
                        p_pk1        in varchar2) return blob is
        l_cfg xxfnd_storage_config%rowtype;
        l_ep  xxfnd_integration_endpoints%rowtype;
        l_blob blob;
    begin
        if p_doc.storage_type = c_database then
            select file_content into l_blob from xxfnd_document_files where file_id = to_number(p_doc.external_version_id);
            return l_blob;
        end if;
        select * into l_cfg from xxfnd_storage_config where storage_config_id = p_doc.storage_config_id;
        select * into l_ep  from xxfnd_integration_endpoints where endpoint_code = l_cfg.endpoint_code;
        if p_doc.storage_type = 'UCM' then
            return ucm_get_file(l_ep, p_doc.external_version_id, p_entity, p_pk1);
        end if;
        return sp_download(l_ep, l_cfg, p_doc.external_document_id, p_doc.external_version_id,
                           p_is_current, p_entity, p_pk1);
    end fetch_file;

    ----------------------------------------------------------------------------
    -- configuration lookups
    ----------------------------------------------------------------------------
    function resolve_storage(p_entity_name in varchar2, p_category_code in varchar2)
        return xxfnd_storage_config%rowtype is
        l_cfg xxfnd_storage_config%rowtype;
    begin
        select * into l_cfg
          from (select s.*
                  from xxfnd_storage_config s
                 where s.enabled_flag = 'Y'
                   and (s.entity_name   = p_entity_name   or s.entity_name   is null)
                   and (s.category_code = p_category_code or s.category_code is null)
                 order by case when s.entity_name   is not null then 0 else 1 end,
                          case when s.category_code is not null then 0 else 1 end,
                          s.priority)
         where rownum = 1;
        return l_cfg;
    exception
        when no_data_found then
            -- nothing configured: keep the file in the database
            return database_config;
    end resolve_storage;

    function block_permission(p_app_alias        in varchar2,
                              p_page_id          in number,
                              p_region_static_id in varchar2,
                              p_entity_name      in varchar2,
                              p_action           in varchar2) return varchar2 is
        l_flag varchar2(1);
    begin
        select case upper(p_action)
                 when 'INSERT' then be.insert_allowed_flag
                 when 'UPDATE' then be.update_allowed_flag
                 when 'DELETE' then be.delete_allowed_flag
               end
          into l_flag
          from xxfnd_attachment_functions f
          join xxfnd_attachment_blocks b      on b.function_code = f.function_code
          join xxfnd_attachment_blk_entities be
            on be.function_code = b.function_code and be.block_code = b.block_code
         where upper(f.apex_app_alias) = upper(p_app_alias)
           and f.apex_page_id = p_page_id
           and f.enabled_flag = 'Y'
           and lower(b.region_static_id) = lower(p_region_static_id)
           and be.entity_name = p_entity_name;
        return nvl(l_flag, 'N');
    exception
        when no_data_found then
            return 'N';
    end block_permission;

    function category_allowed(p_app_alias in varchar2, p_page_id in number,
                              p_category_code in varchar2) return varchar2 is
        l_usages  pls_integer;
        l_allowed pls_integer;
    begin
        select count(*), count(case when u.category_code = p_category_code and u.enabled_flag = 'Y' then 1 end)
          into l_usages, l_allowed
          from xxfnd_attachment_functions f
          join xxfnd_doc_category_usages u on u.function_code = f.function_code
         where upper(f.apex_app_alias) = upper(p_app_alias)
           and f.apex_page_id = p_page_id;
        return case when l_usages = 0 or l_allowed > 0 then 'Y' else 'N' end;
    end category_allowed;

    ----------------------------------------------------------------------------
    -- helpers
    ----------------------------------------------------------------------------
    function folder_path(p_cfg in xxfnd_storage_config%rowtype, p_entity in varchar2,
                         p_pk1 in varchar2, p_pk2 in varchar2, p_pk3 in varchar2,
                         p_pk4 in varchar2, p_pk5 in varchar2, p_category in varchar2) return varchar2 is
        l_path varchar2(2000) := p_cfg.folder_path_template;
    begin
        l_path := replace(l_path, '#ENTITY_NAME#',   p_entity);
        l_path := replace(l_path, '#PK1_VALUE#',     p_pk1);
        l_path := replace(l_path, '#PK2_VALUE#',     p_pk2);
        l_path := replace(l_path, '#PK3_VALUE#',     p_pk3);
        l_path := replace(l_path, '#PK4_VALUE#',     p_pk4);
        l_path := replace(l_path, '#PK5_VALUE#',     p_pk5);
        l_path := replace(l_path, '#CATEGORY_CODE#', p_category);
        l_path := replace(l_path, '#YYYY#',          to_char(sysdate, 'YYYY'));
        l_path := regexp_replace(l_path, '/+', '/');
        return rtrim(ltrim(l_path, '/'), '/');
    end folder_path;

    procedure get_temp_file(p_name in varchar2, p_blob out blob, p_filename out varchar2, p_mime out varchar2) is
    begin
        select blob_content, filename, mime_type
          into p_blob, p_filename, p_mime
          from apex_application_temp_files
         where name = p_name;
    exception
        when no_data_found then
            raise_application_error(-20302, 'The uploaded file was not found. Select the file again.');
    end get_temp_file;

    procedure check_category_rules(p_category in varchar2, p_document_date in date, p_expiry_date in date) is
        l_cat xxfnd_document_categories%rowtype;
    begin
        select * into l_cat from xxfnd_document_categories where category_code = p_category;
        if l_cat.enabled_flag <> 'Y'
           or trunc(sysdate) not between l_cat.start_date_active and nvl(l_cat.end_date_active, trunc(sysdate)) then
            raise_application_error(-20303, 'Document category ' || p_category || ' is not active.');
        end if;
        if l_cat.has_expiry_flag = 'Y' and p_expiry_date is null then
            raise_application_error(-20304, 'Enter the expiry date for ' || l_cat.category_name || '.');
        end if;
        if p_expiry_date is not null and p_expiry_date < trunc(sysdate) then
            raise_application_error(-20305, 'This document has already expired.');
        end if;
        if l_cat.max_age_days is not null then
            if p_document_date is null then
                raise_application_error(-20306, 'Enter the issue date for ' || l_cat.category_name || '.');
            elsif p_document_date < trunc(sysdate) - l_cat.max_age_days then
                raise_application_error(-20307, l_cat.category_name || ' must be issued within the last '
                    || l_cat.max_age_days || ' days.');
            end if;
        end if;
    end check_category_rules;

    procedure check_entity(p_entity in varchar2) is
        l_count pls_integer;
    begin
        select count(*) into l_count from xxfnd_document_entities where entity_name = p_entity and enabled_flag = 'Y';
        if l_count = 0 then
            raise_application_error(-20308, 'Entity ' || p_entity || ' is not enabled for attachments.');
        end if;
    end check_entity;

    ----------------------------------------------------------------------------
    -- upload limits: category, else attachment page, else application setting
    ----------------------------------------------------------------------------

    -- ' .PDF, Jpg ' -> 'pdf,jpg'
    function normalise_types(p_types in varchar2) return varchar2 is
    begin
        return nullif(trim(both ',' from regexp_replace(lower(regexp_replace(p_types, '[[:space:].]', '')), ',+', ',')), '');
    end normalise_types;

    function app_setting(p_name in varchar2) return varchar2 is
    begin
        return apex_app_setting.get_value(p_name);
    exception
        when others then
            return null;   -- no APEX session (scripts, jobs outside APEX)
    end app_setting;

    procedure page_limits(p_page_id in number, p_size out number, p_types out varchar2) is
    begin
        select max(case when f.max_file_size_mb > 0 then f.max_file_size_mb end), max(f.allowed_file_types)
          into p_size, p_types
          from xxfnd_attachment_functions f
         where f.apex_app_alias = nvl(v('APP_ALIAS'), 'KYC')
           and f.apex_page_id   = p_page_id
           and f.enabled_flag   = 'Y';
    end page_limits;

    function max_file_size_mb(p_page_id in number, p_category_code in varchar2) return number is
        l_cat   number;
        l_page  number;
        l_types varchar2(500);
    begin
        select max(case when max_file_size_mb > 0 then max_file_size_mb end) into l_cat
          from xxfnd_document_categories where category_code = p_category_code;
        page_limits(p_page_id, l_page, l_types);
        return coalesce(l_cat, l_page,
                        to_number(app_setting('ATTACH_MAX_FILE_SIZE_MB') default null on conversion error),
                        c_default_size_mb);
    end max_file_size_mb;

    function allowed_file_types(p_page_id in number, p_category_code in varchar2) return varchar2 is
        l_cat   varchar2(500);
        l_size  number;
        l_page  varchar2(500);
    begin
        select max(allowed_file_types) into l_cat from xxfnd_document_categories where category_code = p_category_code;
        page_limits(p_page_id, l_size, l_page);
        return coalesce(normalise_types(l_cat), normalise_types(l_page),
                        normalise_types(app_setting('ATTACH_ALLOWED_FILE_TYPES')), c_default_types);
    end allowed_file_types;

    function upload_rules_text(p_page_id in number, p_category_code in varchar2) return varchar2 is
        l_types varchar2(500) := allowed_file_types(p_page_id, p_category_code);
    begin
        return case when l_types = '*' then 'Any file type' else upper(replace(l_types, ',', ', ')) end
               || ' up to ' || max_file_size_mb(p_page_id, p_category_code) || ' MB';
    end upload_rules_text;

    procedure check_upload(p_page_id in number, p_category in varchar2, p_filename in varchar2, p_blob in blob) is
        l_max   number        := max_file_size_mb(p_page_id, p_category);
        l_types varchar2(500) := allowed_file_types(p_page_id, p_category);
        l_ext   varchar2(100) := lower(regexp_substr(p_filename, '\.([^.]+)$', 1, 1, null, 1));
        l_bytes number        := dbms_lob.getlength(p_blob);
    begin
        if l_bytes > l_max * 1024 * 1024 then
            raise_application_error(-20321, 'The file is ' || round(l_bytes / 1024 / 1024, 1)
                || ' MB; the limit for this document is ' || l_max || ' MB.');
        end if;
        if l_types <> '*' and (l_ext is null
                               or instr(',' || l_types || ',', ',' || l_ext || ',') = 0) then
            raise_application_error(-20322, 'Files of type ' || nvl(upper(l_ext), '(none)')
                || ' are not accepted here. Accepted: ' || upper(replace(l_types, ',', ', ')) || '.');
        end if;
    end check_upload;

    ----------------------------------------------------------------------------
    -- store a file for a document row
    ----------------------------------------------------------------------------
    function store_file(p_cfg in xxfnd_storage_config%rowtype, p_entity in varchar2,
                        p_pk1 in varchar2, p_pk2 in varchar2, p_pk3 in varchar2, p_pk4 in varchar2, p_pk5 in varchar2,
                        p_category in varchar2, p_file in blob, p_filename in varchar2, p_mime in varchar2,
                        p_title in varchar2, p_previous_external_id in varchar2) return t_stored is
        l_folder varchar2(2000) := folder_path(p_cfg, p_entity, p_pk1, p_pk2, p_pk3, p_pk4, p_pk5, p_category);
        l_stored t_stored;
    begin
        l_stored := upload(p_cfg, p_entity, p_pk1, l_folder, p_file, p_filename, p_mime,
                                                  p_title, p_previous_external_id);

        if p_cfg.storage_type = c_database then
            return l_stored;    -- no external folder
        end if;
        -- Remember the record's folder so later files land in the same place.
        merge into xxfnd_entity_containers c
        using (select p_entity e, p_pk1 k, p_cfg.storage_config_id s from dual) x
           on (c.entity_name = x.e and c.pk1_value = x.k and c.storage_config_id = x.s)
         when not matched then
            insert (entity_name, pk1_value, storage_config_id, external_folder_path)
            values (x.e, x.k, x.s, nvl(l_folder, '/'));
        return l_stored;
    end store_file;

    procedure set_tl(p_document_id in number, p_title in varchar2, p_description in varchar2) is
    begin
        merge into xxfnd_documents_tl t
        using (select p_document_id d, xxfnd_util_pkg.current_lang l from dual) x
           on (t.document_id = x.d and t.language_code = x.l)
         when matched then update set t.title = p_title, t.description = p_description
         when not matched then insert (document_id, language_code, title, description)
                               values (x.d, x.l, p_title, p_description);
    end set_tl;

    function next_seq(p_entity in varchar2, p_pk1 in varchar2) return number is
        l_seq number;
    begin
        select nvl(max(seq_num), 0) + 10 into l_seq
          from xxfnd_attached_documents
         where entity_name = p_entity and pk1_value = p_pk1;
        return l_seq;
    end next_seq;

    ----------------------------------------------------------------------------
    -- public API
    ----------------------------------------------------------------------------
    function add_file(p_entity_name    in varchar2,
                      p_pk1_value      in varchar2,
                      p_category_code  in varchar2,
                      p_temp_file_name in varchar2,
                      p_title          in varchar2 default null,
                      p_description    in varchar2 default null,
                      p_document_date  in date     default null,
                      p_expiry_date    in date     default null,
                      p_pk2_value      in varchar2 default null,
                      p_pk3_value      in varchar2 default null,
                      p_pk4_value      in varchar2 default null,
                      p_pk5_value      in varchar2 default null,
                      p_page_id        in number   default null) return number is
        l_cfg      xxfnd_storage_config%rowtype;
        l_blob     blob;
        l_filename varchar2(400);
        l_mime     varchar2(255);
        l_stored   t_stored;
        l_doc_id   number;
        l_att_id   number;
        l_seq      number;
    begin
        check_entity(p_entity_name);
        check_category_rules(p_category_code, p_document_date, p_expiry_date);
        get_temp_file(p_temp_file_name, l_blob, l_filename, l_mime);
        check_upload(p_page_id, p_category_code, l_filename, l_blob);
        l_cfg := resolve_storage(p_entity_name, p_category_code);

        l_stored := store_file(l_cfg, p_entity_name, p_pk1_value, p_pk2_value, p_pk3_value, p_pk4_value,
                               p_pk5_value, p_category_code, l_blob, l_filename, l_mime,
                               nvl(p_title, l_filename), null);

        insert into xxfnd_documents (category_code, datatype_code, version_number, storage_config_id,
                                     storage_type, external_document_id, external_version_id, external_url,
                                     file_name, mime_type, file_size_bytes, document_date, expiry_date,
                                     upload_status)
        values (p_category_code, 'FILE', 1, l_cfg.storage_config_id, l_cfg.storage_type,
                l_stored.external_document_id, l_stored.external_version_id, l_stored.external_url,
                l_filename, l_mime, dbms_lob.getlength(l_blob), p_document_date, p_expiry_date, 'STORED')
        returning document_id into l_doc_id;
        set_tl(l_doc_id, nvl(p_title, l_filename), p_description);

        -- NEXT_SEQ is private to the package body, so it cannot be called inside SQL (PLS-00231).
        l_seq := next_seq(p_entity_name, p_pk1_value);
        insert into xxfnd_attached_documents (document_id, entity_name, pk1_value, pk2_value, pk3_value,
                                              pk4_value, pk5_value, category_code, seq_num)
        values (l_doc_id, p_entity_name, p_pk1_value, p_pk2_value, p_pk3_value, p_pk4_value, p_pk5_value,
                p_category_code, l_seq)
        returning attached_document_id into l_att_id;
        return l_att_id;
    end add_file;

    function add_text(p_entity_name   in varchar2,
                      p_pk1_value     in varchar2,
                      p_category_code in varchar2,
                      p_datatype_code in varchar2,
                      p_title         in varchar2,
                      p_text          in clob     default null,
                      p_url           in varchar2 default null,
                      p_description   in varchar2 default null,
                      p_pk2_value     in varchar2 default null,
                      p_pk3_value     in varchar2 default null,
                      p_pk4_value     in varchar2 default null,
                      p_pk5_value     in varchar2 default null) return number is
        l_doc_id number;
        l_att_id number;
        l_seq    number;
    begin
        check_entity(p_entity_name);
        check_category_rules(p_category_code, null, null);
        if p_datatype_code not in ('SHORT_TEXT','LONG_TEXT','WEB_PAGE') then
            raise_application_error(-20312, 'Use ADD_FILE for files.');
        end if;
        if p_datatype_code = 'WEB_PAGE' and not regexp_like(p_url, '^https?://', 'i') then
            raise_application_error(-20313, 'Enter a web address starting with http:// or https://.');
        end if;
        if p_datatype_code = 'SHORT_TEXT' and dbms_lob.getlength(p_text) > 4000 then
            raise_application_error(-20314, 'Short text is limited to 4000 characters; use long text.');
        end if;

        insert into xxfnd_documents (category_code, datatype_code, version_number, text_content, url, upload_status)
        values (p_category_code, p_datatype_code, 1,
                case when p_datatype_code <> 'WEB_PAGE' then p_text end,
                case when p_datatype_code =  'WEB_PAGE' then p_url end,
                'NOT_APPLICABLE')
        returning document_id into l_doc_id;
        set_tl(l_doc_id, p_title, p_description);

        -- NEXT_SEQ is private to the package body, so it cannot be called inside SQL (PLS-00231).
        l_seq := next_seq(p_entity_name, p_pk1_value);
        insert into xxfnd_attached_documents (document_id, entity_name, pk1_value, pk2_value, pk3_value,
                                              pk4_value, pk5_value, category_code, seq_num)
        values (l_doc_id, p_entity_name, p_pk1_value, p_pk2_value, p_pk3_value, p_pk4_value, p_pk5_value,
                p_category_code, l_seq)
        returning attached_document_id into l_att_id;
        return l_att_id;
    end add_text;

    procedure add_version(p_attached_document_id in number,
                          p_temp_file_name       in varchar2,
                          p_document_date        in date default null,
                          p_expiry_date          in date default null,
                          p_page_id              in number   default null) is
        l_ad       xxfnd_attached_documents%rowtype;
        l_old      xxfnd_documents%rowtype;
        l_cfg      xxfnd_storage_config%rowtype;
        l_blob     blob;
        l_filename varchar2(400);
        l_mime     varchar2(255);
        l_stored   t_stored;
        l_doc_id   number;
        l_title    varchar2(400);
        l_desc     varchar2(2000);
    begin
        select * into l_ad from xxfnd_attached_documents
         where attached_document_id = p_attached_document_id and expiration_date is null
           for update;
        select * into l_old from xxfnd_documents where document_id = l_ad.document_id;
        if l_old.datatype_code <> 'FILE' then
            raise_application_error(-20315, 'Only file attachments have versions.');
        end if;
        check_category_rules(l_ad.category_code, p_document_date, p_expiry_date);
        get_temp_file(p_temp_file_name, l_blob, l_filename, l_mime);
        check_upload(p_page_id, l_ad.category_code, l_filename, l_blob);

        -- Same store as the first version so the external history stays together.
        if l_old.storage_type = c_database then
            l_cfg := database_config;
        else
            select * into l_cfg from xxfnd_storage_config where storage_config_id = l_old.storage_config_id;
        end if;
        begin
            select title, description into l_title, l_desc
              from xxfnd_documents_tl
             where document_id = l_old.document_id and language_code = xxfnd_util_pkg.current_lang;
        exception
            when no_data_found then null;
        end;

        l_stored := store_file(l_cfg, l_ad.entity_name, l_ad.pk1_value, l_ad.pk2_value, l_ad.pk3_value,
                               l_ad.pk4_value, l_ad.pk5_value, l_ad.category_code, l_blob, l_filename, l_mime,
                               nvl(l_title, l_filename), l_old.external_document_id);

        insert into xxfnd_documents (category_code, datatype_code, base_document_id, version_number,
                                     storage_config_id, storage_type, external_document_id, external_version_id,
                                     external_url, file_name, mime_type, file_size_bytes, document_date,
                                     expiry_date, upload_status)
        values (l_old.category_code, 'FILE', nvl(l_old.base_document_id, l_old.document_id), l_old.version_number + 1,
                l_cfg.storage_config_id, l_cfg.storage_type, l_stored.external_document_id,
                l_stored.external_version_id, l_stored.external_url, l_filename, l_mime,
                dbms_lob.getlength(l_blob), p_document_date, p_expiry_date, 'STORED')
        returning document_id into l_doc_id;
        set_tl(l_doc_id, nvl(l_title, l_filename), l_desc);

        update xxfnd_attached_documents set document_id = l_doc_id
         where attached_document_id = p_attached_document_id;
    end add_version;

    procedure update_details(p_attached_document_id in number,
                             p_title                in varchar2,
                             p_description          in varchar2,
                             p_document_date        in date,
                             p_expiry_date          in date,
                             p_seq_num              in number default null) is
        l_ad xxfnd_attached_documents%rowtype;
    begin
        select * into l_ad from xxfnd_attached_documents
         where attached_document_id = p_attached_document_id and expiration_date is null
           for update;
        check_category_rules(l_ad.category_code, p_document_date, p_expiry_date);
        update xxfnd_documents
           set document_date = p_document_date, expiry_date = p_expiry_date
         where document_id = l_ad.document_id;
        set_tl(l_ad.document_id, p_title, p_description);
        if p_seq_num is not null then
            update xxfnd_attached_documents set seq_num = p_seq_num
             where attached_document_id = p_attached_document_id;
        end if;
    end update_details;

    procedure remove(p_attached_document_id in number) is
    begin
        update xxfnd_attached_documents
           set expiration_date = systimestamp
         where attached_document_id = p_attached_document_id
           and expiration_date is null;
        if sql%rowcount = 0 then
            raise_application_error(-20316, 'This attachment has already been removed.');
        end if;
    end remove;

    procedure download(p_document_id in number, p_inline in varchar2 default 'N') is
        l_doc  xxfnd_documents%rowtype;
        l_blob blob;
        l_pk1  varchar2(150);
        l_ent  varchar2(60);
        l_newer pls_integer;
    begin
        select * into l_doc from xxfnd_documents where document_id = p_document_id;
        if l_doc.datatype_code <> 'FILE' then
            raise_application_error(-20317, 'This attachment is not a file.');
        end if;
        select max(entity_name), max(pk1_value) into l_ent, l_pk1
          from xxfnd_attached_documents
         where document_id = p_document_id
            or document_id in (select document_id from xxfnd_documents
                                where base_document_id = nvl(l_doc.base_document_id, l_doc.document_id));
        select count(*) into l_newer
          from xxfnd_documents n
         where n.base_document_id = nvl(l_doc.base_document_id, l_doc.document_id)
           and n.version_number > l_doc.version_number;

        l_blob := fetch_file(l_doc, l_newer = 0, l_ent, l_pk1);

        apex_http.download(
            p_blob         => l_blob,
            p_content_type => nvl(l_doc.mime_type, 'application/octet-stream'),
            p_filename     => l_doc.file_name,
            p_is_inline    => p_inline = 'Y');
    end download;

    procedure copy_attachments(p_from_entity in varchar2, p_from_pk1 in varchar2,
                               p_to_entity   in varchar2, p_to_pk1   in varchar2,
                               p_category_code in varchar2 default null) is
    begin
        check_entity(p_to_entity);
        insert into xxfnd_attached_documents (document_id, entity_name, pk1_value, category_code, seq_num,
                                              primary_category_flag)
        select ad.document_id, p_to_entity, p_to_pk1, ad.category_code, ad.seq_num, ad.primary_category_flag
          from xxfnd_attached_documents ad
         where ad.entity_name = p_from_entity
           and ad.pk1_value   = p_from_pk1
           and ad.expiration_date is null
           and (p_category_code is null or ad.category_code = p_category_code)
           and not exists (select 1 from xxfnd_attached_documents x
                            where x.entity_name = p_to_entity and x.pk1_value = p_to_pk1
                              and x.document_id = ad.document_id and x.expiration_date is null);
    end copy_attachments;

    procedure save_entity_display_name(p_entity_name in varchar2, p_display_name in varchar2) is
    begin
        merge into xxfnd_document_entities_tl t
        using (select p_entity_name entity_name, 'en' language_code from dual) s
           on (t.entity_name = s.entity_name and t.language_code = s.language_code)
         when matched then update set t.user_entity_name = p_display_name
         when not matched then insert (entity_name, language_code, user_entity_name)
                               values (s.entity_name, 'en', p_display_name);
    end save_entity_display_name;

end xxfnd_attach_pkg;
/

-- release 81: the store transport merged into this package (old callers break on purpose: no wrappers)
begin
    xxfnd_ddl_pkg.drop_object('XXFND_ATTACH_STORE_PKG', 'PACKAGE');
end;
/
