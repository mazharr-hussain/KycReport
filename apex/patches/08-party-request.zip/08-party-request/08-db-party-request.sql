-- Patch 08 - Party and Request redesign (release 23): database changes. Run as the parsing schema.
-- Order: 16d party columns, 16 KYC rules, 16b requests (package), 16c monitoring, 16e party package, 16f data moves
-- and dropped columns, 18e lookups. Idempotent: safe to run again.


-- ==== 16d-parties.sql
--------------------------------------------------------------------------------
-- 16d Parties (party feature: pages 20-23)
--   Party-level contact details (email, phone, website, fax) on XXCMP_PARTIES.
--   Contact persons on XXCMP_PARTY_CONTACTS (name, job title, email, phone).
--   Party status (Pending from a request, Approved, Rejected, Cancelled) and the next KYC date.
--   (The one-off moves of older data and the dropped columns are in 16f.)
--   (XXCMP_PARTY_PKG is in 16e: it uses the request and case tables created in 16b.)
-- Idempotent: safe on install and on every upgrade.
--------------------------------------------------------------------------------
begin
    xxfnd_ddl_pkg.add_column('XXCMP_PARTIES',        'EMAIL',                'varchar2(320)');
    xxfnd_ddl_pkg.add_column('XXCMP_PARTIES',        'PHONE',                'varchar2(50)');
    xxfnd_ddl_pkg.add_column('XXCMP_PARTIES',        'WEBSITE',              'varchar2(500)');
    xxfnd_ddl_pkg.add_column('XXCMP_PARTIES',        'FAX',                  'varchar2(50)');
    xxfnd_ddl_pkg.add_column('XXCMP_PARTIES',        'MERGED_INTO_PARTY_ID', 'number');
    xxfnd_ddl_pkg.add_column('XXCMP_PARTIES',        'MERGE_NOTE',           'varchar2(1000)');
    xxfnd_ddl_pkg.add_column('XXCMP_PARTY_CONTACTS', 'JOB_TITLE',            'varchar2(240)');
    xxfnd_ddl_pkg.add_column('XXCMP_PARTY_CONTACTS', 'EMAIL',                'varchar2(320)');
    xxfnd_ddl_pkg.add_column('XXCMP_PARTY_CONTACTS', 'PHONE',                'varchar2(50)');
    xxfnd_ddl_pkg.add_column('XXCMP_PARTIES',        'PARTY_STATUS',         q'[varchar2(30) default 'APPROVED' not null]');
    xxfnd_ddl_pkg.add_column('XXCMP_PARTIES',        'NEXT_KYC_DATE',        'date');
end;
/
comment on column xxcmp_parties.email is 'Main email of the party (contact persons are in XXCMP_PARTY_CONTACTS).';
comment on column xxcmp_parties.merged_into_party_id is 'Set when Compliance merged this duplicate into another party; the party is then disabled.';
comment on column xxcmp_parties.party_status is 'PENDING: created from a KYC request, not yet approved; APPROVED; REJECTED / CANCELLED with its request.';
comment on column xxcmp_parties.next_kyc_date is 'When the party''s KYC is due again: set when a KYC case is approved (risk tier review months, PEP cap).';

-- ==== 16-kyc-rules.sql
--------------------------------------------------------------------------------
-- 09_xxcmp_rules.sql
-- Business rules that sit on the tables:
--   * maker-checker triggers on the three controlled configuration tables
--   * party / RFI numbering
--   * ownership-cycle check on party relationships
--   * XXCMP_KYC_PKG: mandatory-document resolution, party match check, RFI
-- Depends on 03 (approval, security), 07 (attachments), 08 (workflow).
-- Needs: grant execute on dbms_crypto to <parsing schema>  (RFI tokens).
--------------------------------------------------------------------------------

--==============================================================================
-- Maker-checker (XXFND_APPROVAL_PKG.APPLY_RULES)
--==============================================================================
create or replace trigger xxcmp_answer_options_mc
    before insert or update on xxcmp_answer_options
    for each row
begin
    xxfnd_approval_pkg.apply_rules(inserting, :old.approval_status, :new.approval_status,
                                   :old.last_updated_by, :new.approved_by, :new.approved_date);
end;
/

create or replace trigger xxcmp_attachment_rules_mc
    before insert or update on xxcmp_attachment_rules
    for each row
begin
    xxfnd_approval_pkg.apply_rules(inserting, :old.approval_status, :new.approval_status,
                                   :old.last_updated_by, :new.approved_by, :new.approved_date);
end;
/

create or replace trigger xxfnd_int_purposes_mc
    before insert or update on xxfnd_integration_purposes
    for each row
begin
    xxfnd_approval_pkg.apply_rules(inserting, :old.approval_status, :new.approval_status,
                                   :old.last_updated_by, :new.approved_by, :new.approved_date);
end;
/

-- An approved scoring change raises the questionnaire version, so responses
-- record which version they were scored against.
create or replace trigger xxcmp_answer_options_ver
    after update of approval_status on xxcmp_answer_options
    for each row
    when (new.approval_status = 'APPROVED' and old.approval_status <> 'APPROVED')
begin
    update xxcmp_questionnaires q
       set q.current_version_number = q.current_version_number + 1
     where q.questionnaire_code = (select questionnaire_code from xxcmp_questions where question_id = :new.question_id);
end;
/

--==============================================================================
-- Numbering
--==============================================================================
create or replace trigger xxcmp_parties_num
    before insert on xxcmp_parties
    for each row
    when (new.party_number is null)
begin
    :new.party_number := 'P-' || lpad(xxcmp_party_number_s.nextval, 6, '0');
end;
/

-- RFIs are looked up by recipient (requesters' data security, their document downloads, the home page).
create index if not exists xxcmp_rfis_n2 on xxcmp_rfis (upper(recipient_user_name));

create or replace trigger xxcmp_rfis_num
    before insert on xxcmp_rfis
    for each row
    when (new.rfi_number is null)
begin
    :new.rfi_number := 'RFI-' || lpad(xxcmp_rfi_number_s.nextval, 6, '0');
end;
/

--==============================================================================
-- Ownership cycles (A owns B owns C owns A) are rejected. Checked after the
-- statement because the check reads the table being changed.
--==============================================================================
create or replace trigger xxcmp_party_rel_cycle
    for insert or update of subject_party_id, object_party_id, end_date on xxcmp_party_relationships
    compound trigger

    type t_pair is record (subject_id number, object_id number);
    type t_pairs is table of t_pair index by pls_integer;
    g_pairs t_pairs;

    after each row is
        l_pair t_pair;
    begin
        l_pair.subject_id := :new.subject_party_id;
        l_pair.object_id  := :new.object_party_id;
        g_pairs(g_pairs.count + 1) := l_pair;
    end after each row;

    after statement is
        l_count pls_integer;
    begin
        for i in 1 .. g_pairs.count loop
            select count(*) into l_count
              from (select r.object_party_id
                      from xxcmp_party_relationships r
                     where r.end_date is null or r.end_date >= trunc(sysdate)
                     start with r.subject_party_id = g_pairs(i).object_id
                   connect by nocycle prior r.object_party_id = r.subject_party_id
                          and (r.end_date is null or r.end_date >= trunc(sysdate)))
             where object_party_id = g_pairs(i).subject_id;
            if l_count > 0 then
                g_pairs.delete;
                raise_application_error(-20500, 'This relationship would create an ownership loop.');
            end if;
        end loop;
        g_pairs.delete;
    end after statement;
end xxcmp_party_rel_cycle;
/

--==============================================================================
-- XXCMP_KYC_PKG
--==============================================================================
create or replace package xxcmp_kyc_pkg authid definer as

    -- Document categories required for a record, from approved rules; the most
    -- specific rule per category wins (jurisdiction + entity type, then either,
    -- then the general rule), PRIORITY breaks ties.
    function mandatory_categories(p_entity_name  in varchar2,
                                  p_jurisdiction in varchar2,
                                  p_entity_type  in varchar2) return apex_t_varchar2;

    -- Mandatory categories with no current, unexpired attachment on the record.
    function missing_categories(p_entity_name  in varchar2,
                                p_pk1_value    in varchar2,
                                p_jurisdiction in varchar2,
                                p_entity_type  in varchar2) return apex_t_varchar2;

    -- Existing party that is certainly the same one (registration number +
    -- jurisdiction for organisations; name + date of birth for persons), or null.
    function exact_party_match(p_party_type          in varchar2,
                               p_party_name          in varchar2,
                               p_registration_number in varchar2 default null,
                               p_jurisdiction        in varchar2 default null,
                               p_date_of_birth       in date     default null) return number;

    -- 0-100 similarity of two names after normalisation (case, punctuation,
    -- common legal suffixes). Used by the Possible Matches region.
    function name_similarity(p_name_1 in varchar2, p_name_2 in varchar2) return number deterministic;

    -- Raise an RFI. For an external party a one-time token is generated; its
    -- hash is stored and the token itself is returned for the email link only.
    procedure create_rfi(p_entity_name         in varchar2,
                         p_pk1_value           in varchar2,
                         p_recipient_type      in varchar2,
                         p_rfi_category        in varchar2,
                         p_description         in varchar2,
                         p_continue_other_work in varchar2,
                         p_due_date            in date,
                         p_recipient_user_name in varchar2 default null,
                         p_party_contact_id    in number   default null,
                         p_rfi_id              out number,
                         p_token               out varchar2);

    -- Participant of the RFI_RESPONSE task: the internal recipient.
    function rfi_recipient(p_rfi_id in number) return varchar2;

    -- Response from the requesting department (signed-in user).
    procedure respond(p_rfi_id in number, p_response_text in clob);
    -- Response from an external party through the public response page.
    function respond_by_token(p_token in varchar2, p_response_text in clob) return number;
    -- Officer closes the RFI.
    procedure resolve(p_rfi_id in number, p_status in varchar2, p_notes in varchar2);

    -- Emails the recipient using template RFI_RAISED_INTERNAL or RFI_RAISED_EXTERNAL
    -- (APEX_MAIL queue). P_RESPONSE_URL is the public response page link with the token.
    procedure send_rfi_email(p_rfi_id in number, p_response_url in varchar2 default null);

end xxcmp_kyc_pkg;
/

create or replace package body xxcmp_kyc_pkg as

    function mandatory_categories(p_entity_name  in varchar2,
                                  p_jurisdiction in varchar2,
                                  p_entity_type  in varchar2) return apex_t_varchar2 is
        l_result apex_t_varchar2;
    begin
        select category_code bulk collect into l_result
          from (select r.category_code, r.mandatory_flag,
                       row_number() over (partition by r.category_code
                                          order by case when r.jurisdiction is not null then 0 else 1 end
                                                 + case when r.entity_type  is not null then 0 else 1 end,
                                                   case when r.jurisdiction is not null then 0 else 1 end,
                                                   r.priority) rn
                  from xxcmp_attachment_rules r
                 where r.entity_name = p_entity_name
                   and r.enabled_flag = 'Y'
                   and r.approval_status = 'APPROVED'
                   and (r.jurisdiction is null or r.jurisdiction = p_jurisdiction)
                   and (r.entity_type  is null or r.entity_type  = p_entity_type))
         where rn = 1 and mandatory_flag = 'Y'
         order by category_code;
        return l_result;
    end mandatory_categories;

    function missing_categories(p_entity_name  in varchar2,
                                p_pk1_value    in varchar2,
                                p_jurisdiction in varchar2,
                                p_entity_type  in varchar2) return apex_t_varchar2 is
        l_required apex_t_varchar2 := mandatory_categories(p_entity_name, p_jurisdiction, p_entity_type);
        l_missing  apex_t_varchar2 := apex_t_varchar2();
        l_count    pls_integer;
    begin
        for i in 1 .. l_required.count loop
            select count(*) into l_count
              from xxfnd_attached_documents_v v
             where v.entity_name = p_entity_name
               and v.pk1_value   = p_pk1_value
               and v.category_code = l_required(i)
               and v.expired_flag = 'N'
               and (v.upload_status in ('STORED','NOT_APPLICABLE'));
            if l_count = 0 then
                l_missing.extend;
                l_missing(l_missing.count) := l_required(i);
            end if;
        end loop;
        return l_missing;
    end missing_categories;

    function normalise(p_name in varchar2) return varchar2 is
        l_name varchar2(4000) := ' ' || upper(p_name) || ' ';
    begin
        l_name := regexp_replace(l_name, '[^A-Z0-9 ]', ' ');
        l_name := regexp_replace(l_name, ' (LTD|LIMITED|LLC|INC|INCORPORATED|CORP|CORPORATION|CO|COMPANY|PLC|SA|AG|GMBH|WLL|FZE|FZCO|FZ LLC|BV|NV) ', ' ');
        return trim(regexp_replace(l_name, ' +', ' '));
    end normalise;

    function name_similarity(p_name_1 in varchar2, p_name_2 in varchar2) return number deterministic is
    begin
        if p_name_1 is null or p_name_2 is null then
            return 0;
        end if;
        return utl_match.jaro_winkler_similarity(normalise(p_name_1), normalise(p_name_2));
    end name_similarity;

    function exact_party_match(p_party_type          in varchar2,
                               p_party_name          in varchar2,
                               p_registration_number in varchar2 default null,
                               p_jurisdiction        in varchar2 default null,
                               p_date_of_birth       in date     default null) return number is
        l_id number;
    begin
        if p_party_type = 'ORGANIZATION' and p_registration_number is not null then
            select min(party_id) into l_id
              from xxcmp_parties
             where party_type = 'ORGANIZATION'
               and upper(replace(registration_number, ' ')) = upper(replace(p_registration_number, ' '))
               and nvl(jurisdiction, '#') = nvl(p_jurisdiction, '#')
               and enabled_flag = 'Y';
        elsif p_party_type = 'PERSON' and p_date_of_birth is not null then
            select min(party_id) into l_id
              from xxcmp_parties
             where party_type = 'PERSON'
               and incorporation_date = p_date_of_birth      -- an individual's date of birth
               and upper(party_name) = upper(p_party_name)
               and enabled_flag = 'Y';
        end if;
        return l_id;
    end exact_party_match;

    function hash_token(p_token in varchar2) return varchar2 is
    begin
        return rawtohex(dbms_crypto.hash(utl_i18n.string_to_raw(p_token, 'AL32UTF8'), dbms_crypto.hash_sh256));
    end hash_token;

    procedure create_rfi(p_entity_name         in varchar2,
                         p_pk1_value           in varchar2,
                         p_recipient_type      in varchar2,
                         p_rfi_category        in varchar2,
                         p_description         in varchar2,
                         p_continue_other_work in varchar2,
                         p_due_date            in date,
                         p_recipient_user_name in varchar2 default null,
                         p_party_contact_id    in number   default null,
                         p_rfi_id              out number,
                         p_token               out varchar2) is
        l_hash    varchar2(128);
        l_task_id number;
    begin
        xxfnd_util_pkg.assert_lookup('RFI_CATEGORY', p_rfi_category, 'RFI category');
        if p_due_date is not null and p_due_date < trunc(sysdate) then
            raise_application_error(-20501, 'The due date cannot be in the past.');
        end if;
        if p_recipient_type = 'EXTERNAL_PARTY' then
            p_token := lower(rawtohex(dbms_crypto.randombytes(32)));
            l_hash  := hash_token(p_token);
        end if;
        insert into xxcmp_rfis (entity_name, pk1_value, recipient_type, recipient_user_name,
                                recipient_party_contact_id, rfi_category, description, continue_other_work_flag,
                                rfi_status, due_date, response_token_hash, token_expiry_date)
        values (p_entity_name, p_pk1_value, p_recipient_type, upper(p_recipient_user_name),
                p_party_contact_id, p_rfi_category, p_description, p_continue_other_work,
                case when p_continue_other_work = 'Y' then 'WAITING_FOR_INFORMATION' else 'ON_HOLD_PENDING' end,
                p_due_date, l_hash,
                case when l_hash is not null
                     then cast(nvl(p_due_date, trunc(sysdate) + 14) + 1 as timestamp) end)
        returning rfi_id into p_rfi_id;
        -- An internal recipient answers through an APEX action task in My Tasks; an external
        -- party answers through the emailed link (no task: it has no application account).
        if p_recipient_type = 'REQUESTING_DEPARTMENT' then
            l_task_id := xxfnd_task_pkg.create_task('RFI_RESPONSE', to_char(p_rfi_id));
            update xxcmp_rfis set response_task_id = l_task_id where rfi_id = p_rfi_id;
        end if;
    end create_rfi;

    function rfi_recipient(p_rfi_id in number) return varchar2 is
        l_user xxcmp_rfis.recipient_user_name%type;
    begin
        select recipient_user_name into l_user from xxcmp_rfis where rfi_id = p_rfi_id;
        return l_user;
    end rfi_recipient;

    -- A response has arrived: the Compliance team reviews it (RFI_REVIEW action task).
    procedure start_review(p_rfi_id in number) is
        l_task_id number;
    begin
        l_task_id := xxfnd_task_pkg.create_task('RFI_REVIEW', to_char(p_rfi_id));
        update xxcmp_rfis set review_task_id = l_task_id where rfi_id = p_rfi_id;
    end start_review;

    procedure respond(p_rfi_id in number, p_response_text in clob) is
        l_rfi xxcmp_rfis%rowtype;
    begin
        select * into l_rfi from xxcmp_rfis where rfi_id = p_rfi_id for update;
        if l_rfi.recipient_type <> 'REQUESTING_DEPARTMENT'
           or upper(l_rfi.recipient_user_name) <> upper(xxfnd_util_pkg.current_user) then
            raise_application_error(-20502, 'This request for information is not addressed to you.');
        end if;
        if l_rfi.rfi_status not in ('WAITING_FOR_INFORMATION','ON_HOLD_PENDING') then
            raise_application_error(-20503, 'This request for information is closed.');
        end if;
        update xxcmp_rfis set response_text = p_response_text, responded_date = systimestamp
         where rfi_id = p_rfi_id;
        xxfnd_task_pkg.complete_open('RFI_RESPONSE', to_char(p_rfi_id));
        xxfnd_task_pkg.cancel_open('RFI_REVIEW', to_char(p_rfi_id));   -- a newer answer replaces the older one
        start_review(p_rfi_id);
    end respond;

    function respond_by_token(p_token in varchar2, p_response_text in clob) return number is
        l_rfi  xxcmp_rfis%rowtype;
        l_hash varchar2(128) := hash_token(p_token);   -- private function: not callable from SQL
    begin
        -- The caller is an anonymous party (APP_USER nobody); the token is the authorisation,
        -- so row-level data security is bypassed for this call only.
        xxfnd_vpd_pkg.begin_trusted;
        begin
            select * into l_rfi from xxcmp_rfis
             where response_token_hash = l_hash
               for update;
        exception
            when no_data_found then
                raise_application_error(-20504, 'This link is not valid.');
        end;
        if l_rfi.token_expiry_date < systimestamp
           or l_rfi.rfi_status not in ('WAITING_FOR_INFORMATION','ON_HOLD_PENDING') then
            raise_application_error(-20505, 'This link has expired or the request is closed.');
        end if;
        -- One-time: the hash is cleared once the party has answered.
        update xxcmp_rfis
           set response_text = p_response_text, responded_date = systimestamp,
               response_token_hash = null, token_expiry_date = null
         where rfi_id = l_rfi.rfi_id;
        start_review(l_rfi.rfi_id);
        xxfnd_vpd_pkg.end_trusted;
        return l_rfi.rfi_id;
    exception
        when others then
            xxfnd_vpd_pkg.end_trusted;
            raise;
    end respond_by_token;

    procedure resolve(p_rfi_id in number, p_status in varchar2, p_notes in varchar2) is
    begin
        if p_status not in ('RESOLVED','REJECTED_RETURNED','CANCELLED','ON_HOLD_INVESTIGATION') then
            raise_application_error(-20506, 'Status ' || p_status || ' cannot be set here.');
        end if;
        update xxcmp_rfis
           set rfi_status = p_status,
               resolution_notes = p_notes,
               resolved_date = case when p_status in ('RESOLVED','REJECTED_RETURNED','CANCELLED') then systimestamp end,
               response_token_hash = case when p_status in ('RESOLVED','REJECTED_RETURNED','CANCELLED') then null
                                          else response_token_hash end
         where rfi_id = p_rfi_id;
        if sql%rowcount = 0 then
            raise_application_error(-20507, 'Request for information ' || p_rfi_id || ' does not exist.');
        end if;
        if p_status in ('RESOLVED','REJECTED_RETURNED') then
            xxfnd_task_pkg.complete_open('RFI_REVIEW', to_char(p_rfi_id));
        elsif p_status = 'CANCELLED' then
            xxfnd_task_pkg.cancel_open('RFI_RESPONSE', to_char(p_rfi_id));
            xxfnd_task_pkg.cancel_open('RFI_REVIEW', to_char(p_rfi_id));
        end if;
    end resolve;

    procedure send_rfi_email(p_rfi_id in number, p_response_url in varchar2 default null) is
        l_rfi      xxcmp_rfis%rowtype;
        l_to       varchar2(320);
        l_name     varchar2(240);
        l_template varchar2(50);
        l_subject  varchar2(500);
        l_body     clob;
        l_tokens   clob;
        l_json     json_object_t;
        l_mail_id  number;
    begin
        select * into l_rfi from xxcmp_rfis where rfi_id = p_rfi_id;
        if l_rfi.recipient_type = 'REQUESTING_DEPARTMENT' then
            select email_address, full_name into l_to, l_name
              from xxfnd_employees where user_name = upper(l_rfi.recipient_user_name);
            l_template := 'RFI_RAISED_INTERNAL';
        else
            select email, contact_name into l_to, l_name
              from xxcmp_party_contacts where party_contact_id = l_rfi.recipient_party_contact_id;
            l_template := 'RFI_RAISED_EXTERNAL';
        end if;

        select nvl(t.subject, n.subject), nvl(t.body_html, n.body_html)
          into l_subject, l_body
          from xxfnd_notification_templates n
          left join xxfnd_notification_templates_tl t
            on t.template_code = n.template_code and t.language_code = xxfnd_util_pkg.current_lang
         where n.template_code = l_template;

        l_json := json_object_t();
        l_json.put('RFI_NUMBER',   l_rfi.rfi_number);
        l_json.put('DESCRIPTION',  apex_escape.html(l_rfi.description));
        l_json.put('DUE_DATE',     to_char(l_rfi.due_date, 'DD-Mon-YYYY'));
        l_json.put('CONTACT_NAME', apex_escape.html(nvl(l_name, 'Sir/Madam')));
        l_json.put('RESPONSE_URL', p_response_url);
        l_tokens := l_json.to_clob;
        l_mail_id := apex_mail.send(
                         p_to        => l_to,
                         p_from      => apex_app_setting.get_value('MAIL_FROM'),
                         p_subj      => dbms_lob.substr(xxfnd_util_pkg.replace_tokens(l_subject, l_tokens), 500, 1),
                         p_body      => to_clob(l_rfi.description),
                         p_body_html => xxfnd_util_pkg.replace_tokens(l_body, l_tokens));
    end send_rfi_email;

end xxcmp_kyc_pkg;
/

-- ==== 16b-kyc-requests-cases.sql
--------------------------------------------------------------------------------
-- 16b KYC requests and cases  (release R13)
-- Module 1 (intake) and Module 2 (investigation, decision) data and logic.
--   XXCMP_REQUESTS            a KYC request (new onboarding, periodic or event-triggered review)
--   XXCMP_REQUEST_ANSWERS     questionnaire answers (requester at intake, officer in the case)
--   XXCMP_CASES               the compliance case opened from a request
--   XXCMP_CASE_DECISIONS      approval history per level
--   XXCMP_SCREENINGS          registry / sanctions / PEP / adverse-media checks
--   XXCMP_DOC_VERIFICATIONS   genuine-and-current check per attached document
--   XXCMP_UBO_DETERMINATIONS  the officer's beneficial-owner decisions
--   XXCMP_CASE_NOTES          investigation notes
--   XXCMP_REQUEST_PKG / XXCMP_CASE_PKG  logic behind the screens and the KYC_REQUEST /
--                             KYC_CASE APEX workflows
-- Idempotent: safe on install and on every upgrade.
--------------------------------------------------------------------------------
create sequence if not exists xxcmp_request_number_s start with 1 nocache;
create sequence if not exists xxcmp_case_number_s start with 1 nocache;

create table if not exists xxcmp_requests (
    request_id             number generated by default on null as identity,
    request_number         varchar2(30)   not null,
    request_type           varchar2(30)   default 'NEW_ONBOARDING' not null,
    trigger_source         varchar2(30)   default 'MANUAL' not null,
    parent_request_id      number,
    parent_case_id         number,
    party_id               number,
    party_type             varchar2(30)   not null,
    party_name             varchar2(360)  not null,
    registration_number    varchar2(100),
    jurisdiction           varchar2(30),
    entity_type            varchar2(30),
    requesting_department  varchar2(240),
    requester_user_name    varchar2(255)  not null,
    questionnaire_code     varchar2(30),
    intake_score           number,
    intake_critical_flag   varchar2(1),
    intake_outcome         varchar2(30),
    request_status         varchar2(30)   default 'DRAFT' not null,
    justification          varchar2(4000),
    submitted_date         timestamp,
    completed_date         timestamp,
    workflow_id            number,
    -- standard WHO columns
    created_by               varchar2(255)  not null,
    creation_date            timestamp      not null,
    last_updated_by          varchar2(255)  not null,
    last_update_date         timestamp      not null,
    last_update_login        varchar2(255),
    object_version_number    number         default 1 not null,
    constraint xxcmp_requests_pk primary key (request_id),
    constraint xxcmp_requests_uk1 unique (request_number),
    constraint xxcmp_requests_fk1 foreign key (party_id) references xxcmp_parties (party_id),
    constraint xxcmp_requests_fk2 foreign key (parent_request_id) references xxcmp_requests (request_id),
    constraint xxcmp_requests_fk3 foreign key (questionnaire_code) references xxcmp_questionnaires (questionnaire_code),
    constraint xxcmp_requests_ck1 check (request_type in ('NEW_ONBOARDING','PERIODIC_REVIEW','EVENT_TRIGGERED_REVIEW')),
    constraint xxcmp_requests_ck2 check (trigger_source in ('MANUAL','SCHEDULED','EVENT_DRIVEN')),
    constraint xxcmp_requests_ck3 check (request_status in ('DRAFT','IN_PROGRESS','INFO_NEEDED','APPROVED','REJECTED','CANCELLED')),
    constraint xxcmp_requests_ck4 check (intake_outcome in ('NOT_REQUIRED','AUTO_APPROVED','ASSIGNED')),
    constraint xxcmp_requests_ck5 check (party_type in ('ORGANIZATION','PERSON')),
    constraint xxcmp_requests_ck6 check (intake_critical_flag in ('Y','N'))
);
create index if not exists xxcmp_requests_n1 on xxcmp_requests (requester_user_name, request_status);

-- Counterparty selection (an existing party chosen by the requester, or a new one created with the request).
-- The counterparty columns are shared by organisations and individuals (16f): JURISDICTION = country /
-- nationality, REGISTRATION_NUMBER = registration / ID number, ENTITY_TYPE = entity / ID type,
-- INCORPORATION_DATE = incorporation / birth date.
begin
    xxfnd_ddl_pkg.add_column('XXCMP_REQUESTS', 'PARTY_SELECTION',     q'[varchar2(10) default 'NEW']');
    xxfnd_ddl_pkg.add_column('XXCMP_REQUESTS', 'INCORPORATION_DATE',  'date');
    xxfnd_ddl_pkg.add_column('XXCMP_REQUESTS', 'MATCH_ACK_FLAG',      q'[varchar2(1) default 'N']');
    xxfnd_ddl_pkg.add_column('XXCMP_REQUESTS', 'MATCH_STATUS',        'varchar2(20)');
    xxfnd_ddl_pkg.add_column('XXCMP_REQUESTS', 'MATCH_RESOLVED_BY',   'varchar2(255)');
    xxfnd_ddl_pkg.add_column('XXCMP_REQUESTS', 'MATCH_RESOLVED_DATE', 'timestamp');
    xxfnd_ddl_pkg.add_column('XXCMP_REQUESTS', 'MATCH_NOTE',          'varchar2(1000)');
    xxfnd_ddl_pkg.add_column('XXCMP_REQUESTS', 'CONTACT_NAME',        'varchar2(240)');
    xxfnd_ddl_pkg.add_column('XXCMP_REQUESTS', 'CONTACT_EMAIL',       'varchar2(320)');
    xxfnd_ddl_pkg.add_column('XXCMP_REQUESTS', 'CONTACT_PHONE',       'varchar2(50)');
    xxfnd_ddl_pkg.add_column('XXCMP_REQUESTS', 'LAST_ACTION_DATE',    'date');
end;
/
comment on column xxcmp_requests.party_selection is 'EXISTING: the requester chose a party from the party list; NEW: a counterparty created with the request (party status Pending until the request is approved).';
comment on column xxcmp_requests.match_status is 'SELECTED (existing party chosen), NEW (party created with the request), MERGED (Compliance merged it into an existing party). Older values: PENDING, CONFIRMED_NEW.';
create index if not exists xxcmp_parties_n4 on xxcmp_parties (upper(replace(registration_number, ' ')));
create index if not exists xxcmp_requests_n2 on xxcmp_requests (party_id);
comment on table xxcmp_requests is 'KYC request from a requesting department, or a periodic / event-triggered review. A new counterparty is created as a party (Pending) with the request.';

create table if not exists xxcmp_cases (
    case_id                number generated by default on null as identity,
    case_number            varchar2(30)   not null,
    request_id             number         not null,
    party_id               number         not null,
    parent_case_id         number,
    case_status            varchar2(30)   default 'INVESTIGATION' not null,
    assigned_to            varchar2(255),
    risk_tier              varchar2(30),
    enhanced_kyc_flag      varchar2(1)    default 'N' not null,
    pep_flag               varchar2(1)    default 'N' not null,
    sla_due_date           date,
    investigation_completed_date timestamp,
    current_level          number,
    decision               varchar2(30),
    decision_date          timestamp,
    conditions             varchar2(4000),
    next_review_date       date,
    next_review_reason     varchar2(1000),
    sar_required_flag      varchar2(1),
    sar_notes              varchar2(4000),
    closed_date            timestamp,
    workflow_id            number,
    -- standard WHO columns
    created_by               varchar2(255)  not null,
    creation_date            timestamp      not null,
    last_updated_by          varchar2(255)  not null,
    last_update_date         timestamp      not null,
    last_update_login        varchar2(255),
    object_version_number    number         default 1 not null,
    constraint xxcmp_cases_pk primary key (case_id),
    constraint xxcmp_cases_uk1 unique (case_number),
    constraint xxcmp_cases_fk1 foreign key (request_id) references xxcmp_requests (request_id),
    constraint xxcmp_cases_fk2 foreign key (party_id) references xxcmp_parties (party_id),
    constraint xxcmp_cases_fk3 foreign key (parent_case_id) references xxcmp_cases (case_id),
    constraint xxcmp_cases_ck1 check (case_status in ('INVESTIGATION','PENDING_APPROVAL','APPROVED','REJECTED','CANCELLED')),
    constraint xxcmp_cases_ck2 check (enhanced_kyc_flag in ('Y','N')),
    constraint xxcmp_cases_ck3 check (pep_flag in ('Y','N')),
    constraint xxcmp_cases_ck4 check (decision in ('APPROVED','REJECTED')),
    constraint xxcmp_cases_ck5 check (sar_required_flag in ('Y','N'))
);
create index if not exists xxcmp_cases_n1 on xxcmp_cases (case_status, assigned_to);
create index if not exists xxcmp_cases_n2 on xxcmp_cases (party_id);
create index if not exists xxcmp_cases_n3 on xxcmp_cases (next_review_date);
comment on table xxcmp_cases is 'Compliance case: investigation, risk classification, approval and closure. A decided case is closed (CLOSED_DATE) and locked.';

create table if not exists xxcmp_request_answers (
    answer_id              number generated by default on null as identity,
    request_id             number         not null,
    case_id                number,
    respondent_type        varchar2(30)   not null,
    question_id            number         not null,
    answer_option_id       number,
    answer_text            varchar2(4000),
    risk_points            number,
    -- standard WHO columns
    created_by               varchar2(255)  not null,
    creation_date            timestamp      not null,
    last_updated_by          varchar2(255)  not null,
    last_update_date         timestamp      not null,
    last_update_login        varchar2(255),
    object_version_number    number         default 1 not null,
    constraint xxcmp_request_answers_pk primary key (answer_id),
    constraint xxcmp_request_answers_uk1 unique (request_id, respondent_type, question_id),
    constraint xxcmp_request_answers_fk1 foreign key (request_id) references xxcmp_requests (request_id) on delete cascade,
    constraint xxcmp_request_answers_fk2 foreign key (case_id) references xxcmp_cases (case_id),
    constraint xxcmp_request_answers_fk3 foreign key (question_id) references xxcmp_questions (question_id),
    constraint xxcmp_request_answers_fk4 foreign key (answer_option_id) references xxcmp_answer_options (answer_option_id),
    constraint xxcmp_request_answers_ck1 check (respondent_type in ('REQUESTER','OFFICER'))
);
comment on table xxcmp_request_answers is 'Questionnaire answers: the requester''s at intake (scored) and the officer''s in the case (findings).';

create table if not exists xxcmp_case_decisions (
    decision_id            number generated by default on null as identity,
    case_id                number         not null,
    level_no               number         not null,
    role_code              varchar2(30),
    decided_by             varchar2(255)  not null,
    outcome                varchar2(30)   not null,
    decision_date          timestamp      default systimestamp not null,
    comments               varchar2(4000),
    task_id                number,
    -- standard WHO columns
    created_by               varchar2(255)  not null,
    creation_date            timestamp      not null,
    last_updated_by          varchar2(255)  not null,
    last_update_date         timestamp      not null,
    last_update_login        varchar2(255),
    object_version_number    number         default 1 not null,
    constraint xxcmp_case_decisions_pk primary key (decision_id),
    constraint xxcmp_case_decisions_fk1 foreign key (case_id) references xxcmp_cases (case_id),
    constraint xxcmp_case_decisions_ck1 check (outcome in ('APPROVED','REJECTED'))
);
comment on table xxcmp_case_decisions is 'Every approval-level decision on a case: who, under which role, when, outcome and comments.';

create table if not exists xxcmp_screenings (
    screening_id           number generated by default on null as identity,
    case_id                number         not null,
    party_id               number         not null,
    screening_type         varchar2(30)   not null,
    match_status           varchar2(30)   default 'NO_MATCH' not null,
    pep_flag               varchar2(1)    default 'N' not null,
    sanctions_flag         varchar2(1)    default 'N' not null,
    adverse_media_flag     varchar2(1)    default 'N' not null,
    capture_method         varchar2(30)   default 'MANUAL' not null,
    source_reference       varchar2(1000),
    result_notes           varchar2(4000),
    screened_date          date           default trunc(sysdate) not null,
    -- standard WHO columns
    created_by               varchar2(255)  not null,
    creation_date            timestamp      not null,
    last_updated_by          varchar2(255)  not null,
    last_update_date         timestamp      not null,
    last_update_login        varchar2(255),
    object_version_number    number         default 1 not null,
    constraint xxcmp_screenings_pk primary key (screening_id),
    constraint xxcmp_screenings_fk1 foreign key (case_id) references xxcmp_cases (case_id),
    constraint xxcmp_screenings_fk2 foreign key (party_id) references xxcmp_parties (party_id),
    constraint xxcmp_screenings_ck1 check (screening_type in ('REGISTRY','SANCTIONS','PEP','ADVERSE_MEDIA')),
    constraint xxcmp_screenings_ck2 check (match_status in ('NO_MATCH','POTENTIAL_MATCH','CONFIRMED_MATCH','FALSE_POSITIVE')),
    constraint xxcmp_screenings_ck3 check (pep_flag in ('Y','N') and sanctions_flag in ('Y','N') and adverse_media_flag in ('Y','N')),
    constraint xxcmp_screenings_ck4 check (capture_method in ('MANUAL','API'))
);
comment on table xxcmp_screenings is 'One screening event per check, with all its flags. A confirmed match or a PEP flag forces the case into Enhanced KYC.';

create table if not exists xxcmp_doc_verifications (
    verification_id        number generated by default on null as identity,
    case_id                number         not null,
    attached_document_id   number         not null,
    verification_status    varchar2(30)   not null,
    notes                  varchar2(4000),
    -- standard WHO columns
    created_by               varchar2(255)  not null,
    creation_date            timestamp      not null,
    last_updated_by          varchar2(255)  not null,
    last_update_date         timestamp      not null,
    last_update_login        varchar2(255),
    object_version_number    number         default 1 not null,
    constraint xxcmp_doc_verifications_pk primary key (verification_id),
    constraint xxcmp_doc_verifications_uk1 unique (case_id, attached_document_id),
    constraint xxcmp_doc_verifications_fk1 foreign key (case_id) references xxcmp_cases (case_id),
    constraint xxcmp_doc_verifications_fk2 foreign key (attached_document_id) references xxfnd_attached_documents (attached_document_id),
    constraint xxcmp_doc_verifications_ck1 check (verification_status in ('VERIFIED','REJECTED','EXPIRED'))
);
comment on table xxcmp_doc_verifications is 'Whether each document attached to the party is genuine and current, as checked for this case.';

create table if not exists xxcmp_ubo_determinations (
    ubo_id                 number generated by default on null as identity,
    case_id                number         not null,
    owner_party_id         number         not null,
    basis                  varchar2(30)   not null,
    ownership_percentage   number,
    notes                  varchar2(4000),
    -- standard WHO columns
    created_by               varchar2(255)  not null,
    creation_date            timestamp      not null,
    last_updated_by          varchar2(255)  not null,
    last_update_date         timestamp      not null,
    last_update_login        varchar2(255),
    object_version_number    number         default 1 not null,
    constraint xxcmp_ubo_determinations_pk primary key (ubo_id),
    constraint xxcmp_ubo_determinations_uk1 unique (case_id, owner_party_id),
    constraint xxcmp_ubo_determinations_fk1 foreign key (case_id) references xxcmp_cases (case_id),
    constraint xxcmp_ubo_determinations_fk2 foreign key (owner_party_id) references xxcmp_parties (party_id),
    constraint xxcmp_ubo_determinations_ck1 check (basis in ('OWNERSHIP','CONTROL','FALLBACK')),
    constraint xxcmp_ubo_determinations_ck2 check (ownership_percentage between 0 and 100)
);
comment on table xxcmp_ubo_determinations is 'The officer''s decision on who the beneficial owners are, for this case (a later review never overwrites it).';

create table if not exists xxcmp_case_notes (
    note_id                number generated by default on null as identity,
    case_id                number         not null,
    related_party_id       number,
    note_text              varchar2(4000) not null,
    -- standard WHO columns
    created_by               varchar2(255)  not null,
    creation_date            timestamp      not null,
    last_updated_by          varchar2(255)  not null,
    last_update_date         timestamp      not null,
    last_update_login        varchar2(255),
    object_version_number    number         default 1 not null,
    constraint xxcmp_case_notes_pk primary key (note_id),
    constraint xxcmp_case_notes_fk1 foreign key (case_id) references xxcmp_cases (case_id),
    constraint xxcmp_case_notes_fk2 foreign key (related_party_id) references xxcmp_parties (party_id)
);
comment on table xxcmp_case_notes is 'Investigation notes, optionally about one related party.';

begin
    for t in (select column_value table_name from table(apex_t_varchar2(
                 'XXCMP_REQUESTS','XXCMP_CASES','XXCMP_REQUEST_ANSWERS','XXCMP_CASE_DECISIONS','XXCMP_SCREENINGS',
                 'XXCMP_DOC_VERIFICATIONS','XXCMP_UBO_DETERMINATIONS','XXCMP_CASE_NOTES'))) loop
        xxfnd_util_pkg.create_who_trigger(t.table_name);
    end loop;
end;
/

--------------------------------------------------------------------------------
-- Requests
--------------------------------------------------------------------------------
create or replace package xxcmp_request_pkg authid definer as

    -- Requester questionnaire for a party type (PERSON -> INDIVIDUAL, ORGANIZATION -> CORPORATE).
    function questionnaire_for(p_party_type in varchar2) return varchar2;

    -- New DRAFT request with one empty answer row per question of its questionnaire. The counterparty columns
    -- are shared by organisations and individuals (see XXCMP_PARTY_PKG).
    function create_request(p_party_type            in varchar2,
                            p_party_name            in varchar2,
                            p_registration_number   in varchar2 default null,
                            p_jurisdiction          in varchar2 default null,
                            p_entity_type           in varchar2 default null,
                            p_incorporation_date    in date     default null,
                            p_requesting_department in varchar2 default null,
                            p_justification         in varchar2 default null,
                            p_request_type          in varchar2 default 'NEW_ONBOARDING',
                            p_trigger_source        in varchar2 default 'MANUAL',
                            p_parent_request_id     in number   default null,
                            p_parent_case_id        in number   default null,
                            p_party_id              in number   default null) return number;

    -- Requesting department of the signed-in user: the department of the employee profile (matched to the
    -- REQUESTING_DEPARTMENT lookup by code or meaning), or null.
    function default_department return varchar2;
    -- Y: the user may raise requests for any department (Compliance staff: privilege CASES.VIEW); N: only for the
    -- department of the employee profile (when the profile has one).
    function can_choose_department return varchar2;

    -- The rules of Create Request step 1 (null = acceptable): EXISTING needs an approved party; NEW follows the
    -- common party form (XXCMP_PARTY_PKG.PARTY_ERROR); the business justification is required.
    -- P_DRAFT = Y checks only what a draft needs (type and name, or the party).
    function request_error(p_request_id          in number,
                           p_party_selection     in varchar2,
                           p_party_id            in number,
                           p_party_type          in varchar2,
                           p_party_name          in varchar2,
                           p_jurisdiction        in varchar2,
                           p_registration_number in varchar2,
                           p_entity_type         in varchar2,
                           p_incorporation_date  in date,
                           p_email               in varchar2,
                           p_phone               in varchar2,
                           p_justification       in varchar2,
                           p_draft               in varchar2 default 'N') return varchar2;

    -- Create Request step 1: creates the DRAFT request (p_request_id null) or updates it (Draft or Information
    -- Needed, by its requester). NEW creates the counterparty as a party with status Pending (or updates the
    -- request's own Pending party); EXISTING links an approved party. A change of type replaces the questionnaire.
    -- The contact person (hidden by the build option REQUEST_CONTACT) becomes the new party's primary contact.
    procedure save_request(p_request_id            in out number,
                           p_party_selection       in varchar2,
                           p_party_id              in number,
                           p_party_type            in varchar2,
                           p_party_name            in varchar2,
                           p_jurisdiction          in varchar2,
                           p_registration_number   in varchar2,
                           p_entity_type           in varchar2,
                           p_incorporation_date    in date,
                           p_email                 in varchar2,
                           p_phone                 in varchar2,
                           p_website               in varchar2,
                           p_fax                   in varchar2,
                           p_requesting_department in varchar2,
                           p_justification         in varchar2,
                           p_draft                 in varchar2 default 'N',
                           p_contact_name          in varchar2 default null,
                           p_contact_email         in varchar2 default null,
                           p_contact_phone         in varchar2 default null);

    -- Y when the signed-in user may change the request (its requester, while Draft or Information Needed).
    function is_editable(p_request_id in number) return varchar2;
    -- Y when the requester may change the counterparty's party (editable request, new counterparty, party Pending).
    function party_editable(p_request_id in number) return varchar2;

    -- Parties a requester may choose from (requesters cannot read the party master itself): approved, enabled
    -- parties of the type (null = both types) with number, name and country only. JSON array [{"party_id","party_number","party_name","country"}].
    function party_directory_json(p_party_type in varchar2) return clob;

    -- Possible existing parties for a counterparty, strongest first (at most 10). Matching: same registration / ID
    -- number; name similarity; same incorporation / birth date; same country. 100 = same number and country.
    -- JSON array [{"party_id","party_number","registration_number","party_name","country","score","reg_match",
    --              "reasons","exact","status"}]; reg_match = 0-100 similarity of the numbers.
    function party_candidates_json(p_party_type          in varchar2,
                                   p_party_name          in varchar2,
                                   p_registration_number in varchar2,
                                   p_date                in date,
                                   p_country             in varchar2,
                                   p_exclude_party_id    in number default null) return clob;
    function party_candidate_count(p_party_type          in varchar2,
                                   p_party_name          in varchar2,
                                   p_registration_number in varchar2,
                                   p_date                in date,
                                   p_country             in varchar2,
                                   p_exclude_party_id    in number default null) return number;
    -- The same for a saved request, without its own party (Compliance merges a duplicate from the request page).
    function request_candidates_json(p_request_id in number) return clob;
    -- Y while an older request (workflow 1.1) still waits for Compliance's match decision.
    function match_pending(p_request_id in number) return varchar2;

    -- Create Request step 2: the questionnaire as a form. Questions grouped by section (translated), each with its
    -- answer control (Yes/No and single choice: radio buttons; text, number, date: an input) and the saved answer.
    -- kyc-app.js (kycQuestionnaire.bind) copies the answers into a JSON item before submit:
    --   [{"q": question_id, "o": answer_option_id, "t": "text answer"}, ...]
    function questionnaire_html(p_request_id in number, p_respondent in varchar2 default 'REQUESTER') return clob;
    -- Required questions without an answer in P_ANSWERS (null = all answered).
    function answers_error(p_request_id in number, p_answers in clob) return varchar2;
    -- Saves the answers of a Draft or Information Needed request; only its own questions and approved options.
    procedure save_answers(p_request_id in number, p_answers in clob);

    -- Why the request cannot be submitted yet (null = it can).
    function submit_error(p_request_id in number) return varchar2;
    -- Submits the request (In Progress) and starts the KYC_REQUEST workflow.
    procedure submit(p_request_id in number);

    -- Why the signed-in user cannot cancel the request (null = can): its requester, while Draft, In Progress or
    -- Information Needed.
    function cancel_error(p_request_id in number) return varchar2;
    -- Cancels the request: ends its workflow and tasks; a Pending party only this request uses is Cancelled.
    procedure cancel(p_request_id in number, p_reason in varchar2 default null);

    -- Document checklist task events: Compliance asked the requester for information / the requester answered.
    procedure info_requested(p_request_id in number);
    procedure info_submitted(p_request_id in number);

    -- Workflow steps (KYC_REQUEST). Run as system steps, not limited by data security.
    procedure evaluate(p_request_id in number);
    function outcome(p_request_id in number) return varchar2;
    procedure close_without_case(p_request_id in number);
    procedure create_case(p_request_id in number);
    procedure reject(p_request_id in number);

    -- Status as shown to users (lookup KYC_REQUEST_STATUS).
    function stage(p_request_id in number) return varchar2;
    -- KYC Required: Yes when the approval workflow runs (Compliance review), No when approved automatically.
    function kyc_required(p_request_id in number) return varchar2;
    -- Who must act now: the requester (Draft, Information Needed), the Compliance user holding the task or
    -- 'Compliance' (In Progress); null once closed.
    function pending_with(p_request_id in number) return varchar2;

    -- New review request for the party of a case (monitoring): submitted at once, always to Compliance.
    function start_review(p_case_id in number, p_request_type in varchar2, p_trigger_source in varchar2,
                          p_justification in varchar2) return number;

end xxcmp_request_pkg;
/

create or replace package xxcmp_case_pkg authid definer as

    -- Opens the case of a request and starts the KYC_CASE workflow.
    function create_case(p_request_id in number, p_assigned_to in varchar2 default null) return number;
    -- A case opened by an officer without an intake request (a request is recorded for the trail).
    function create_manual_case(p_party_id in number, p_justification in varchar2) return number;

    procedure assign(p_case_id in number, p_user_name in varchar2);

    -- Task participants.
    function investigation_owners(p_case_id in number) return varchar2;
    function level_approvers(p_case_id in number) return varchar2;

    -- Approval levels from the approval matrix (risk tier; Enhanced KYC needs two).
    function required_levels(p_case_id in number) return number;
    function level_role(p_case_id in number, p_level in number) return varchar2;
    function sar_gate(p_case_id in number) return varchar2;

    -- Y when the case is under investigation and the user may manage cases (Case page read-only otherwise).
    function is_editable(p_case_id in number) return varchar2;

    -- Investigation -> approval.
    function submit_error(p_case_id in number) return varchar2;
    procedure submit_for_approval(p_case_id in number);

    -- Approval (CASE_APPROVAL task actions and the decision page).
    function approval_error(p_case_id in number) return varchar2;
    procedure record_decision(p_case_id in number, p_outcome in varchar2, p_comments in varchar2, p_task_id in number);
    function next_review_date(p_case_id in number) return date;

    -- Workflow steps (KYC_CASE).
    procedure start_approval(p_case_id in number);
    function has_next_level(p_case_id in number) return varchar2;
    procedure approve_case(p_case_id in number);
    procedure reject_case(p_case_id in number);

    -- Screening results: a confirmed match or PEP flag forces Enhanced KYC.
    procedure apply_screening(p_case_id in number);

end xxcmp_case_pkg;
/

create or replace package body xxcmp_request_pkg as

    -- Numeric KYC parameter maintained by administrators (lookup KYC_PARAMETER, value in TAG).
    function param(p_code in varchar2, p_default in number) return number is
        l_value number;
    begin
        select max(to_number(tag default null on conversion error)) into l_value from xxfnd_lookup_values
         where lookup_type = 'KYC_PARAMETER' and lookup_code = p_code and enabled_flag = 'Y';
        return nvl(l_value, p_default);
    end param;

    function questionnaire_for(p_party_type in varchar2) return varchar2 is
    begin
        return case p_party_type when 'PERSON' then 'INDIVIDUAL' else 'CORPORATE' end;
    end questionnaire_for;

    procedure add_answer_rows(p_request_id in number, p_case_id in number, p_questionnaire in varchar2,
                              p_respondent in varchar2) is
    begin
        insert into xxcmp_request_answers (request_id, case_id, respondent_type, question_id)
        select p_request_id, p_case_id, p_respondent, q.question_id
          from xxcmp_questions q
         where q.questionnaire_code = p_questionnaire
           and q.enabled_flag = 'Y'
           and not exists (select 1 from xxcmp_request_answers a
                            where a.request_id = p_request_id and a.respondent_type = p_respondent
                              and a.question_id = q.question_id);
    end add_answer_rows;

    function get_request(p_request_id in number) return xxcmp_requests%rowtype is
        l_req xxcmp_requests%rowtype;
    begin
        xxfnd_vpd_pkg.begin_trusted;
        select * into l_req from xxcmp_requests where request_id = p_request_id;
        xxfnd_vpd_pkg.end_trusted;
        return l_req;
    exception
        when others then
            xxfnd_vpd_pkg.end_trusted;
            raise;
    end get_request;

    function get_party(p_party_id in number) return xxcmp_parties%rowtype is
        l_party xxcmp_parties%rowtype;
    begin
        xxfnd_vpd_pkg.begin_trusted;
        select * into l_party from xxcmp_parties where party_id = p_party_id;
        xxfnd_vpd_pkg.end_trusted;
        return l_party;
    exception
        when others then
            xxfnd_vpd_pkg.end_trusted;
            raise;
    end get_party;

    function party_status(p_party_id in number) return varchar2 is
        l_status xxcmp_parties.party_status%type;
    begin
        xxfnd_vpd_pkg.begin_trusted;
        select max(party_status) into l_status from xxcmp_parties where party_id = p_party_id;
        xxfnd_vpd_pkg.end_trusted;
        return l_status;
    exception
        when others then
            xxfnd_vpd_pkg.end_trusted;
            raise;
    end party_status;

    -- a Pending party created with a request that no other open or approved request uses gets P_STATUS
    procedure release_party(p_party_id in number, p_request_id in number, p_status in varchar2) is
        l_other pls_integer;
    begin
        if p_party_id is null or party_status(p_party_id) <> 'PENDING' then
            return;
        end if;
        xxfnd_vpd_pkg.begin_trusted;
        select count(*) into l_other from xxcmp_requests
         where party_id = p_party_id and request_id <> p_request_id
           and request_status not in ('CANCELLED', 'REJECTED');
        xxfnd_vpd_pkg.end_trusted;
        if l_other = 0 then
            xxcmp_party_pkg.set_status(p_party_id, p_status);
        end if;
    exception
        when others then
            xxfnd_vpd_pkg.end_trusted;
            raise;
    end release_party;

    function create_request(p_party_type            in varchar2,
                            p_party_name            in varchar2,
                            p_registration_number   in varchar2 default null,
                            p_jurisdiction          in varchar2 default null,
                            p_entity_type           in varchar2 default null,
                            p_incorporation_date    in date     default null,
                            p_requesting_department in varchar2 default null,
                            p_justification         in varchar2 default null,
                            p_request_type          in varchar2 default 'NEW_ONBOARDING',
                            p_trigger_source        in varchar2 default 'MANUAL',
                            p_parent_request_id     in number   default null,
                            p_parent_case_id        in number   default null,
                            p_party_id              in number   default null) return number is
        l_id  number;
        l_qnr varchar2(30) := case when p_request_type = 'NEW_ONBOARDING' then questionnaire_for(p_party_type) end;
    begin
        insert into xxcmp_requests (request_number, request_type, trigger_source, parent_request_id, parent_case_id,
                                    party_id, party_type, party_name, registration_number, jurisdiction, entity_type,
                                    incorporation_date, requesting_department, requester_user_name,
                                    questionnaire_code, justification, last_action_date)
        values ('REQ-' || lpad(xxcmp_request_number_s.nextval, 6, '0'), p_request_type, p_trigger_source,
                p_parent_request_id, p_parent_case_id, p_party_id, p_party_type, p_party_name, p_registration_number,
                p_jurisdiction, p_entity_type, p_incorporation_date, p_requesting_department,
                xxfnd_util_pkg.current_user, l_qnr, p_justification, sysdate)
        returning request_id into l_id;
        if l_qnr is not null then
            add_answer_rows(l_id, null, l_qnr, 'REQUESTER');
        end if;
        return l_id;
    end create_request;

    function default_department return varchar2 is
        l_code xxfnd_lookup_values.lookup_code%type;
    begin
        select max(v.lookup_code) keep (dense_rank first order by v.display_sequence) into l_code
          from xxfnd_employees e
          join xxfnd_lookup_values v
            on v.lookup_type = 'REQUESTING_DEPARTMENT' and v.enabled_flag = 'Y'
           and (upper(v.lookup_code) = upper(trim(e.department_name)) or upper(v.meaning) = upper(trim(e.department_name)))
         where e.user_name = upper(xxfnd_util_pkg.current_user) and e.enabled_flag = 'Y';
        return l_code;
    end default_department;

    function can_choose_department return varchar2 is
    begin
        return case when xxfnd_privilege_pkg.has_privilege('CASES', 'VIEW') then 'Y' else 'N' end;
    end can_choose_department;

    function request_error(p_request_id          in number,
                           p_party_selection     in varchar2,
                           p_party_id            in number,
                           p_party_type          in varchar2,
                           p_party_name          in varchar2,
                           p_jurisdiction        in varchar2,
                           p_registration_number in varchar2,
                           p_entity_type         in varchar2,
                           p_incorporation_date  in date,
                           p_email               in varchar2,
                           p_phone               in varchar2,
                           p_justification       in varchar2,
                           p_draft               in varchar2 default 'N') return varchar2 is
        l_own   number;
        l_error varchar2(4000);
    begin
        if p_party_selection = 'EXISTING' then
            if p_party_id is null then
                return 'Choose the existing counterparty.';
            elsif party_status(p_party_id) <> 'APPROVED' or xxcmp_party_pkg.is_enabled(p_party_id) = 'N' then
                return 'Choose an approved, enabled party.';
            end if;
        else
            -- the request's own party is not a duplicate of itself
            if p_request_id is not null then
                l_own := get_request(p_request_id).party_id;
            end if;
            l_error := xxcmp_party_pkg.party_error(l_own, p_party_type, p_party_name, p_jurisdiction,
                                                   p_registration_number, p_entity_type, p_incorporation_date,
                                                   p_email, p_phone, p_draft);
            if l_error is not null then
                return l_error;
            end if;
        end if;
        if p_draft = 'N' and trim(p_justification) is null then
            return 'Enter the business justification.';
        end if;
        return null;
    end request_error;

    procedure save_request(p_request_id            in out number,
                           p_party_selection       in varchar2,
                           p_party_id              in number,
                           p_party_type            in varchar2,
                           p_party_name            in varchar2,
                           p_jurisdiction          in varchar2,
                           p_registration_number   in varchar2,
                           p_entity_type           in varchar2,
                           p_incorporation_date    in date,
                           p_email                 in varchar2,
                           p_phone                 in varchar2,
                           p_website               in varchar2,
                           p_fax                   in varchar2,
                           p_requesting_department in varchar2,
                           p_justification         in varchar2,
                           p_draft                 in varchar2 default 'N',
                           p_contact_name          in varchar2 default null,
                           p_contact_email         in varchar2 default null,
                           p_contact_phone         in varchar2 default null) is
        l_error    varchar2(4000);
        l_old      xxcmp_requests%rowtype;
        l_party    xxcmp_parties%rowtype;
        l_party_id number;
        l_new      boolean := false;
        l_dept     xxcmp_requests.requesting_department%type := p_requesting_department;
    begin
        if p_request_id is not null then
            l_old := get_request(p_request_id);
            if l_old.request_status not in ('DRAFT', 'INFO_NEEDED')
               or upper(l_old.requester_user_name) <> upper(xxfnd_util_pkg.current_user) then
                raise_application_error(-20612, 'Request ' || l_old.request_number || ' can no longer be changed.');
            elsif l_old.request_status = 'INFO_NEEDED'
                  and (p_party_selection <> l_old.party_selection
                       or (p_party_selection = 'EXISTING' and p_party_id <> l_old.party_id)) then
                raise_application_error(-20617, 'The counterparty of a submitted request cannot be replaced.');
            end if;
        end if;
        l_error := request_error(p_request_id, p_party_selection, p_party_id, p_party_type, p_party_name, p_jurisdiction,
                                 p_registration_number, p_entity_type, p_incorporation_date, p_email, p_phone,
                                 p_justification, p_draft);
        if l_error is not null then
            raise_application_error(-20611, l_error);
        end if;
        -- a requester raises requests for the department of the employee profile; Compliance for any department
        if can_choose_department = 'N' and default_department is not null then
            l_dept := default_department;
        end if;

        if p_party_selection = 'EXISTING' then
            l_party_id := p_party_id;
            -- the Pending party this request created before is no longer needed
            if l_old.party_selection = 'NEW' and l_old.party_id is not null and l_old.party_id <> p_party_id then
                release_party(l_old.party_id, p_request_id, 'CANCELLED');
            end if;
        else
            -- the request's own Pending party is updated; otherwise a new Pending party is created
            if l_old.party_selection = 'NEW' and party_status(l_old.party_id) = 'PENDING' then
                l_party_id := l_old.party_id;
            elsif l_old.party_selection = 'NEW' and l_old.party_id is not null then
                raise_application_error(-20618, 'The party of this request has been approved: Compliance maintains it.');
            end if;
            l_new := l_party_id is null;
            xxcmp_party_pkg.put_party(l_party_id, p_party_type, p_party_name, p_jurisdiction, p_registration_number,
                                      p_entity_type, p_incorporation_date, p_email, p_phone, p_website, p_fax,
                                      p_party_status => 'PENDING');
            if l_new and trim(p_contact_name) is not null then
                xxfnd_vpd_pkg.begin_trusted;
                begin
                    insert into xxcmp_party_contacts (party_id, contact_name, email, phone, primary_flag)
                    values (l_party_id, trim(p_contact_name), trim(p_contact_email), trim(p_contact_phone), 'Y');
                exception
                    when others then
                        xxfnd_vpd_pkg.end_trusted;
                        raise;
                end;
                xxfnd_vpd_pkg.end_trusted;
            end if;
        end if;
        l_party := get_party(l_party_id);

        if p_request_id is null then
            p_request_id := create_request(p_party_type => l_party.party_type, p_party_name => l_party.party_name,
                                           p_requesting_department => l_dept, p_justification => p_justification,
                                           p_party_id => l_party_id);
            l_old := get_request(p_request_id);
        end if;
        update xxcmp_requests
           set party_selection       = p_party_selection,
               party_id              = l_party_id,
               party_type            = l_party.party_type,
               party_name            = l_party.party_name,
               registration_number   = l_party.registration_number,
               entity_type           = l_party.entity_type,
               incorporation_date    = l_party.incorporation_date,
               jurisdiction          = l_party.jurisdiction,
               match_status          = case when p_party_selection = 'EXISTING' then 'SELECTED' else 'NEW' end,
               contact_name          = trim(p_contact_name),
               contact_email         = trim(p_contact_email),
               contact_phone         = trim(p_contact_phone),
               requesting_department = case when l_old.request_status = 'DRAFT' then l_dept else requesting_department end,
               justification         = p_justification,
               questionnaire_code    = case when l_old.request_status = 'DRAFT' then questionnaire_for(l_party.party_type)
                                            else questionnaire_code end,
               last_action_date      = sysdate
         where request_id = p_request_id;
        -- another type answers another questionnaire
        if l_old.request_status = 'DRAFT' and nvl(l_old.questionnaire_code, '#') <> questionnaire_for(l_party.party_type) then
            delete from xxcmp_request_answers where request_id = p_request_id and respondent_type = 'REQUESTER';
            add_answer_rows(p_request_id, null, questionnaire_for(l_party.party_type), 'REQUESTER');
        end if;
    end save_request;

    function is_editable(p_request_id in number) return varchar2 is
        l_req xxcmp_requests%rowtype;
    begin
        if p_request_id is null then
            return 'Y';
        end if;
        l_req := get_request(p_request_id);
        return case when l_req.request_status in ('DRAFT', 'INFO_NEEDED')
                     and upper(l_req.requester_user_name) = upper(xxfnd_util_pkg.current_user) then 'Y' else 'N' end;
    exception
        when no_data_found then
            return 'N';
    end is_editable;

    function party_editable(p_request_id in number) return varchar2 is
        l_req xxcmp_requests%rowtype;
    begin
        if p_request_id is null then
            return 'Y';
        end if;
        l_req := get_request(p_request_id);
        return case when is_editable(p_request_id) = 'Y' and nvl(l_req.party_selection, 'NEW') = 'NEW'
                     and (l_req.party_id is null or party_status(l_req.party_id) = 'PENDING') then 'Y' else 'N' end;
    exception
        when no_data_found then
            return 'N';
    end party_editable;

    function party_directory_json(p_party_type in varchar2) return clob is
        l_json clob;
    begin
        xxfnd_vpd_pkg.begin_trusted;
        select json_arrayagg(json_object('party_id' value party_id, 'party_number' value party_number,
                                         'party_name' value party_name,
                                         'country' value xxfnd_util_pkg.lookup_meaning('JURISDICTION', jurisdiction))
                             order by party_name returning clob)
          into l_json
          from xxcmp_parties
         where (party_type = p_party_type or p_party_type is null) and enabled_flag = 'Y' and party_status = 'APPROVED';
        xxfnd_vpd_pkg.end_trusted;
        return nvl(l_json, '[]');
    exception
        when others then
            xxfnd_vpd_pkg.end_trusted;
            raise;
    end party_directory_json;

    function party_candidates_json(p_party_type          in varchar2,
                                   p_party_name          in varchar2,
                                   p_registration_number in varchar2,
                                   p_date                in date,
                                   p_country             in varchar2,
                                   p_exclude_party_id    in number default null) return clob is
        l_json clob;
        l_id   varchar2(100) := upper(regexp_replace(p_registration_number, '[^[:alnum:]]', ''));
    begin
        if trim(p_party_name) is null and l_id is null then
            return '[]';
        end if;
        xxfnd_vpd_pkg.begin_trusted;    -- the whole party master, but only safe columns leave this function
        select json_arrayagg(json_object('party_id' value party_id, 'party_number' value party_number,
                                         'registration_number' value registration_number,
                                         'party_name' value party_name, 'country' value country,
                                         'score' value score, 'reg_match' value reg_match, 'reasons' value reasons,
                                         'exact' value case when id_hit = 'Y' and country_hit = 'Y' then 'Y' else 'N' end,
                                         'status' value status)
                             order by score desc, party_name returning clob)
          into l_json
          from (select m.*,
                       case when id_hit = 'Y' and country_hit = 'Y' then 100
                            when id_hit = 'Y' then 90
                            else least(89, round(similarity * 0.7 + case when date_hit = 'Y' then 20 else 0 end
                                                                + case when country_hit = 'Y' then 10 else 0 end)) end as score,
                       case when l_id is not null and party_id_number is not null
                            then round(utl_match.edit_distance_similarity(party_id_number, l_id)) end as reg_match,
                       rtrim(case when id_hit = 'Y' then 'Same ' || lower(xxcmp_party_pkg.field_label(p_party_type, 'REGISTRATION_NUMBER')) || '; ' end
                             || case when similarity >= 70 then 'Name ' || round(similarity) || '% similar; ' end
                             || case when date_hit = 'Y' then 'Same ' || lower(xxcmp_party_pkg.field_label(p_party_type, 'INCORPORATION_DATE')) || '; ' end
                             || case when country_hit = 'Y' then 'Same ' || lower(xxcmp_party_pkg.field_label(p_party_type, 'JURISDICTION')) || '; ' end,
                             '; ') as reasons
                  from (select p.party_id, p.party_number, p.party_name, p.registration_number,
                               xxfnd_util_pkg.lookup_meaning('PARTY_STATUS', p.party_status) as status,
                               upper(regexp_replace(p.registration_number, '[^[:alnum:]]', '')) as party_id_number,
                               xxfnd_util_pkg.lookup_meaning('JURISDICTION', p.jurisdiction) as country,
                               case when l_id is not null
                                     and upper(regexp_replace(p.registration_number, '[^[:alnum:]]', '')) = l_id
                                    then 'Y' else 'N' end as id_hit,
                               case when trim(p_party_name) is not null
                                    then xxcmp_kyc_pkg.name_similarity(p.party_name, p_party_name) else 0 end as similarity,
                               case when p_date is not null and p_date = p.incorporation_date then 'Y' else 'N' end as date_hit,
                               case when p_country is not null and p.jurisdiction = p_country then 'Y' else 'N' end as country_hit
                          from xxcmp_parties p
                         where p.party_type = p_party_type
                           and p.enabled_flag = 'Y'
                           and p.party_status not in ('REJECTED', 'CANCELLED')
                           and p.party_id <> nvl(p_exclude_party_id, -1)) m
                 where id_hit = 'Y'
                    or similarity >= 85
                    or (similarity >= 70 and date_hit = 'Y')
                 order by score desc
                 fetch first 10 rows only);
        xxfnd_vpd_pkg.end_trusted;
        return nvl(l_json, '[]');
    exception
        when others then
            xxfnd_vpd_pkg.end_trusted;
            raise;
    end party_candidates_json;

    function party_candidate_count(p_party_type          in varchar2,
                                   p_party_name          in varchar2,
                                   p_registration_number in varchar2,
                                   p_date                in date,
                                   p_country             in varchar2,
                                   p_exclude_party_id    in number default null) return number is
    begin
        return json_array_t.parse(party_candidates_json(p_party_type, p_party_name, p_registration_number,
                                                        p_date, p_country, p_exclude_party_id)).get_size;
    end party_candidate_count;

    function request_candidates_json(p_request_id in number) return clob is
        l_req xxcmp_requests%rowtype := get_request(p_request_id);
    begin
        return party_candidates_json(l_req.party_type, l_req.party_name, l_req.registration_number,
                                     l_req.incorporation_date, l_req.jurisdiction, l_req.party_id);
    end request_candidates_json;

    function match_pending(p_request_id in number) return varchar2 is
    begin
        return case when get_request(p_request_id).match_status = 'PENDING' then 'Y' else 'N' end;
    exception
        when no_data_found then
            return 'N';
    end match_pending;

    function questionnaire_html(p_request_id in number, p_respondent in varchar2 default 'REQUESTER') return clob is
        l_html    clob;
        l_section varchar2(240) := chr(0);
        l_lang    varchar2(10) := xxfnd_util_pkg.current_lang;
        l_id      varchar2(100);

        procedure add(p_text in varchar2) is
        begin
            dbms_lob.writeappend(l_html, length(p_text), p_text);
        end add;
    begin
        dbms_lob.createtemporary(l_html, true);
        add('<div class="kyc-questionnaire">');
        for q in (select a.question_id, a.answer_option_id, a.answer_text, qu.answer_type, qu.required_flag,
                         nvl(tl.question_text, qu.question_text) as question_text,
                         nvl(nvl(tl.section_name, qu.section_name), 'General') as section_name
                    from xxcmp_request_answers a
                    join xxcmp_questions qu on qu.question_id = a.question_id
                    left join xxcmp_questions_tl tl on tl.question_id = qu.question_id and tl.language_code = l_lang
                   where a.request_id = p_request_id
                     and a.respondent_type = p_respondent
                   -- a section's questions stay together, in the order of its first question
                   order by min(qu.display_sequence) over (partition by nvl(nvl(tl.section_name, qu.section_name), 'General')),
                            qu.display_sequence, qu.question_id) loop
            if q.section_name <> l_section then
                if l_section <> chr(0) then
                    add('</div>');
                end if;
                l_section := q.section_name;
                add('<div class="kyc-section"><h3 class="kyc-section-title">' || apex_escape.html(q.section_name) || '</h3>');
            end if;
            l_id := 'kycq_' || q.question_id;
            add('<fieldset class="kyc-q" data-kyc-q="' || q.question_id || '" data-kyc-type="' || q.answer_type || '">'
                || '<legend class="kyc-q-text">' || apex_escape.html(q.question_text)
                || case when q.required_flag = 'Y' then ' <span class="kyc-q-required" title="Required">*</span>' end
                || '</legend>');
            if q.answer_type in ('YES_NO', 'SINGLE_SELECT', 'MULTI_SELECT') then
                add('<div class="kyc-q-options" role="radiogroup">');
                for o in (select answer_option_id, answer_label
                            from xxcmp_answer_options
                           where question_id = q.question_id and approval_status = 'APPROVED' and enabled_flag = 'Y'
                           order by display_sequence, answer_option_id) loop
                    add('<label class="kyc-q-option"><input type="radio" name="' || l_id || '" value="' || o.answer_option_id || '"'
                        || case when o.answer_option_id = q.answer_option_id then ' checked' end
                        || '> <span>' || apex_escape.html(o.answer_label) || '</span></label>');
                end loop;
                add('</div>');
            elsif q.answer_type = 'TEXT' then
                add('<textarea class="textarea apex-item-textarea kyc-q-input" rows="3" maxlength="4000" aria-label="'
                    || apex_escape.html_attribute(q.question_text) || '">' || apex_escape.html(q.answer_text) || '</textarea>');
            else
                add('<input class="text_field apex-item-text kyc-q-input" type="'
                    || case q.answer_type when 'DATE' then 'date' else 'text" inputmode="decimal' end
                    || '" value="' || apex_escape.html_attribute(q.answer_text) || '" aria-label="'
                    || apex_escape.html_attribute(q.question_text) || '">');
            end if;
            add('</fieldset>');
        end loop;
        if l_section <> chr(0) then
            add('</div>');
        else
            add('<p class="kyc-q-empty">No questions are configured for this counterparty type.</p>');
        end if;
        add('</div>');
        return l_html;
    end questionnaire_html;

    function answers_error(p_request_id in number, p_answers in clob) return varchar2 is
        l_missing varchar2(4000);
    begin
        select listagg(qu.question_text, '; ') within group (order by qu.display_sequence)
          into l_missing
          from xxcmp_request_answers a
          join xxcmp_questions qu on qu.question_id = a.question_id
         where a.request_id = p_request_id
           and a.respondent_type = 'REQUESTER'
           and qu.required_flag = 'Y'
           and not exists (select 1 from json_table(nvl(p_answers, '[]'), '$[*]'
                                            columns (q number path '$.q', o number path '$.o', t varchar2(4000) path '$.t')) j
                            where j.q = a.question_id and (j.o is not null or trim(j.t) is not null));
        return case when l_missing is not null then 'Answer the required questions: ' || l_missing end;
    end answers_error;

    procedure save_answers(p_request_id in number, p_answers in clob) is
        l_status xxcmp_requests.request_status%type;
        l_type   xxcmp_questions.answer_type%type;
        l_option number;
        l_text   varchar2(4000);
    begin
        select request_status into l_status from xxcmp_requests where request_id = p_request_id;
        if l_status not in ('DRAFT', 'INFO_NEEDED') then
            raise_application_error(-20613, 'The request has been submitted; its answers can no longer be changed.');
        end if;
        for j in (select q, o, t from json_table(nvl(p_answers, '[]'), '$[*]'
                          columns (q number path '$.q', o number path '$.o', t varchar2(4000) path '$.t'))) loop
            begin
                select qu.answer_type into l_type
                  from xxcmp_request_answers a join xxcmp_questions qu on qu.question_id = a.question_id
                 where a.request_id = p_request_id and a.respondent_type = 'REQUESTER' and a.question_id = j.q;
            exception
                when no_data_found then
                    raise_application_error(-20614, 'Question ' || j.q || ' does not belong to this request.');
            end;
            l_option := null;
            l_text   := null;
            if l_type in ('YES_NO', 'SINGLE_SELECT', 'MULTI_SELECT') then
                if j.o is not null then
                    select max(answer_option_id) into l_option
                      from xxcmp_answer_options
                     where answer_option_id = j.o and question_id = j.q and approval_status = 'APPROVED' and enabled_flag = 'Y';
                    if l_option is null then
                        raise_application_error(-20615, 'Answer ' || j.o || ' is not an option of question ' || j.q || '.');
                    end if;
                end if;
            elsif l_type = 'NUMBER' and trim(j.t) is not null
                  and validate_conversion(trim(j.t) as number) = 0 then
                raise_application_error(-20616, 'Enter a number for: ' || j.t);
            else
                l_text := trim(j.t);
            end if;
            update xxcmp_request_answers
               set answer_option_id = l_option,
                   answer_text      = case when l_type in ('YES_NO', 'SINGLE_SELECT', 'MULTI_SELECT') then answer_text else l_text end
             where request_id = p_request_id and respondent_type = 'REQUESTER' and question_id = j.q;
        end loop;
    end save_answers;

    function submit_error(p_request_id in number) return varchar2 is
        l_req     xxcmp_requests%rowtype := get_request(p_request_id);
        l_party   xxcmp_parties%rowtype;
        l_missing pls_integer;
        l_error   varchar2(4000);
        l_docs    varchar2(4000);
    begin
        if l_req.request_status <> 'DRAFT' then
            return 'This request has already been submitted.';
        end if;
        select count(*) into l_missing
          from xxcmp_request_answers a
          join xxcmp_questions q on q.question_id = a.question_id
         where a.request_id = p_request_id and a.respondent_type = 'REQUESTER'
           and q.required_flag = 'Y' and a.answer_option_id is null and a.answer_text is null;
        if l_missing > 0 then
            return l_missing || ' required question(s) are not answered.';
        end if;
        -- reviews of an existing case (monitoring) come with their party: only a requester's counterparty is checked
        if l_req.parent_case_id is not null then
            return null;
        end if;
        if l_req.party_id is null then
            return 'Choose or enter the counterparty.';
        end if;
        if l_req.party_selection = 'NEW' then
            l_party := get_party(l_req.party_id);
            l_error := request_error(p_request_id, 'NEW', null, l_party.party_type, l_party.party_name, l_party.jurisdiction,
                                     l_party.registration_number, l_party.entity_type, l_party.incorporation_date,
                                     l_party.email, l_party.phone, l_req.justification);
        else
            l_error := request_error(p_request_id, 'EXISTING', l_req.party_id, null, null, null, null, null, null, null,
                                     null, l_req.justification);
        end if;
        if l_error is not null then
            return l_error;
        end if;
        -- mandatory documents of the entity / ID type and country (Mandatory Document Rules), attached to the
        -- request or to the party
        for c in (select c.column_value as category_code,
                         nvl((select max(tl.category_name) from xxfnd_document_categories_tl tl
                               where tl.category_code = c.column_value and tl.language_code = xxfnd_util_pkg.current_lang),
                             (select max(dc.category_name) from xxfnd_document_categories dc
                               where dc.category_code = c.column_value)) as category_name
                    from table(xxcmp_kyc_pkg.mandatory_categories('XXCMP_PARTIES', l_req.jurisdiction, l_req.entity_type)) c
                   where not exists (select 1 from xxfnd_attached_documents_v a
                                      where a.category_code = c.column_value and nvl(a.expired_flag, 'N') = 'N'
                                        and ((a.entity_name = 'XXCMP_REQUESTS' and a.pk1_value = to_char(p_request_id))
                                          or (a.entity_name = 'XXCMP_PARTIES' and a.pk1_value = to_char(l_req.party_id))))) loop
            l_docs := l_docs || case when l_docs is not null then ', ' end || c.category_name;
        end loop;
        if l_docs is not null then
            return 'Attach the mandatory documents: ' || l_docs || '.';
        end if;
        return null;
    end submit_error;

    procedure submit(p_request_id in number) is
        l_error varchar2(4000) := submit_error(p_request_id);
        l_wf    number;
    begin
        if l_error is not null then
            raise_application_error(-20601, l_error);
        end if;
        update xxcmp_requests
           set request_status = 'IN_PROGRESS', submitted_date = systimestamp, last_action_date = sysdate
         where request_id = p_request_id;
        l_wf := apex_workflow.start_workflow(
                    p_application_id => v('APP_ID'),
                    p_static_id      => 'KYC_REQUEST',
                    p_detail_pk      => to_char(p_request_id));
        update xxcmp_requests set workflow_id = l_wf where request_id = p_request_id;
    end submit;

    function cancel_error(p_request_id in number) return varchar2 is
        l_req   xxcmp_requests%rowtype := get_request(p_request_id);
        l_cases pls_integer;
    begin
        if upper(l_req.requester_user_name) <> upper(xxfnd_util_pkg.current_user) then
            return 'Only the requester can cancel request ' || l_req.request_number || '.';
        elsif l_req.request_status not in ('DRAFT', 'IN_PROGRESS', 'INFO_NEEDED') then
            return 'Request ' || l_req.request_number || ' is closed and cannot be cancelled.';
        end if;
        select count(*) into l_cases from xxcmp_cases where request_id = p_request_id;
        if l_cases > 0 then
            return 'A case has been opened for request ' || l_req.request_number || ': it cannot be cancelled.';
        end if;
        return null;
    end cancel_error;

    procedure cancel(p_request_id in number, p_reason in varchar2 default null) is
        l_error varchar2(4000) := cancel_error(p_request_id);
        l_req   xxcmp_requests%rowtype := get_request(p_request_id);
        l_state varchar2(30);
    begin
        if l_error is not null then
            raise_application_error(-20623, l_error);
        end if;
        -- the running workflow and its open task end with the request
        if l_req.workflow_id is not null then
            select max(state_code) into l_state from apex_workflows where workflow_id = l_req.workflow_id;
            if l_state in ('ACTIVE', 'SUSPENDED', 'FAULTED') then
                xxfnd_vpd_pkg.begin_trusted;
                begin
                    apex_workflow.terminate(p_instance_id => l_req.workflow_id);
                exception
                    when others then
                        xxfnd_vpd_pkg.end_trusted;
                        raise;
                end;
                xxfnd_vpd_pkg.end_trusted;
            end if;
        end if;
        update xxcmp_requests
           set request_status = 'CANCELLED', completed_date = systimestamp, last_action_date = sysdate,
               match_note = nvl(substr(p_reason, 1, 1000), match_note)
         where request_id = p_request_id;
        release_party(l_req.party_id, p_request_id, 'CANCELLED');
    end cancel;

    procedure set_status(p_request_id in number, p_from in varchar2, p_to in varchar2) is
    begin
        xxfnd_vpd_pkg.begin_trusted;
        update xxcmp_requests set request_status = p_to, last_action_date = sysdate
         where request_id = p_request_id and request_status = p_from;
        xxfnd_vpd_pkg.end_trusted;
    exception
        when others then
            xxfnd_vpd_pkg.end_trusted;
            raise;
    end set_status;

    procedure info_requested(p_request_id in number) is
    begin
        set_status(p_request_id, 'IN_PROGRESS', 'INFO_NEEDED');
    end info_requested;

    procedure info_submitted(p_request_id in number) is
    begin
        set_status(p_request_id, 'INFO_NEEDED', 'IN_PROGRESS');
    end info_submitted;

    -- The request's party: the one chosen or created with the request. Requests saved before release 23 may
    -- still have none: a Pending party is created from what was typed.
    procedure link_party(p_req in out xxcmp_requests%rowtype) is
    begin
        if p_req.party_id is null then
            xxcmp_party_pkg.put_party(p_req.party_id, p_req.party_type, p_req.party_name, p_req.jurisdiction,
                                      p_req.registration_number, p_req.entity_type, p_req.incorporation_date,
                                      p_req.contact_email, p_req.contact_phone, null, null, p_party_status => 'PENDING');
            update xxcmp_requests set party_id = p_req.party_id, match_status = 'NEW' where request_id = p_req.request_id;
        end if;
    end link_party;

    procedure evaluate(p_request_id in number) is
        l_req      xxcmp_requests%rowtype;
        l_score    number;
        l_critical pls_integer;
        l_waiver   pls_integer;
        l_low      number;
        l_outcome  varchar2(30);
    begin
        xxfnd_vpd_pkg.begin_trusted;
        select * into l_req from xxcmp_requests where request_id = p_request_id for update;
        link_party(l_req);
        if l_req.request_type <> 'NEW_ONBOARDING' or l_req.questionnaire_code is null then
            l_outcome := 'ASSIGNED';                          -- reviews always go to Compliance
        else
            update xxcmp_request_answers a
               set risk_points = (select o.risk_points from xxcmp_answer_options o where o.answer_option_id = a.answer_option_id)
             where a.request_id = p_request_id and a.respondent_type = 'REQUESTER';
            select nvl(sum(a.risk_points), 0),
                   count(case when o.critical_flag = 'Y' then 1 end),
                   count(case when q.gate_question_flag = 'Y' and o.waiver_qualifying_flag = 'Y' then 1 end)
              into l_score, l_critical, l_waiver
              from xxcmp_request_answers a
              join xxcmp_questions q on q.question_id = a.question_id
              left join xxcmp_answer_options o on o.answer_option_id = a.answer_option_id
             where a.request_id = p_request_id and a.respondent_type = 'REQUESTER';
            select low_risk_max_score into l_low from xxcmp_questionnaires where questionnaire_code = l_req.questionnaire_code;
            l_outcome := case when l_critical > 0 then 'ASSIGNED'
                              when l_waiver > 0 then 'NOT_REQUIRED'
                              when l_low is not null and l_score <= l_low then 'AUTO_APPROVED'
                              else 'ASSIGNED' end;
            update xxcmp_requests set intake_score = l_score, intake_critical_flag = case when l_critical > 0 then 'Y' else 'N' end
             where request_id = p_request_id;
        end if;
        update xxcmp_requests
           set intake_outcome = l_outcome, request_status = 'IN_PROGRESS', last_action_date = sysdate
         where request_id = p_request_id;
        xxfnd_vpd_pkg.end_trusted;
    exception
        when others then
            xxfnd_vpd_pkg.end_trusted;
            raise;
    end evaluate;

    function outcome(p_request_id in number) return varchar2 is
    begin
        return get_request(p_request_id).intake_outcome;
    end outcome;

    procedure close_without_case(p_request_id in number) is
        l_party number;
    begin
        xxfnd_vpd_pkg.begin_trusted;
        update xxcmp_requests
           set request_status = 'APPROVED', completed_date = systimestamp, last_action_date = sysdate
         where request_id = p_request_id
        returning party_id into l_party;
        xxfnd_vpd_pkg.end_trusted;
        if party_status(l_party) = 'PENDING' then
            xxcmp_party_pkg.set_status(l_party, 'APPROVED');
        end if;
    exception
        when others then
            xxfnd_vpd_pkg.end_trusted;
            raise;
    end close_without_case;

    procedure create_case(p_request_id in number) is
        l_case number;
    begin
        l_case := xxcmp_case_pkg.create_case(p_request_id);
    end create_case;

    procedure reject(p_request_id in number) is
        l_party number;
    begin
        xxfnd_vpd_pkg.begin_trusted;
        update xxcmp_requests
           set request_status = 'REJECTED', completed_date = systimestamp, last_action_date = sysdate
         where request_id = p_request_id
        returning party_id into l_party;
        xxfnd_vpd_pkg.end_trusted;
        release_party(l_party, p_request_id, 'REJECTED');
    exception
        when others then
            xxfnd_vpd_pkg.end_trusted;
            raise;
    end reject;

    function stage(p_request_id in number) return varchar2 is
    begin
        return xxfnd_util_pkg.lookup_meaning('KYC_REQUEST_STATUS', get_request(p_request_id).request_status);
    exception
        when no_data_found then
            return null;
    end stage;

    function kyc_required(p_request_id in number) return varchar2 is
        l_outcome xxcmp_requests.intake_outcome%type;
    begin
        l_outcome := get_request(p_request_id).intake_outcome;
        return case when l_outcome = 'ASSIGNED' then 'Yes'
                    when l_outcome in ('NOT_REQUIRED', 'AUTO_APPROVED') then 'No' end;
    exception
        when no_data_found then
            return null;
    end kyc_required;

    function pending_with(p_request_id in number) return varchar2 is
        l_req   xxcmp_requests%rowtype;
        l_owner varchar2(255);
        l_open  pls_integer;
    begin
        l_req := get_request(p_request_id);
        if l_req.request_status in ('DRAFT', 'INFO_NEEDED') then
            return l_req.requester_user_name;
        elsif l_req.request_status = 'IN_PROGRESS' then
            select max(actual_owner), count(*) into l_owner, l_open
              from apex_tasks
             where detail_pk = to_char(p_request_id)
               and task_def_static_id in ('DOC_CHECKLIST_REVIEW', 'COUNTERPARTY_MATCH')
               and state_code in ('UNASSIGNED', 'ASSIGNED', 'INFO_REQUESTED');
            return case when l_owner is not null then l_owner
                        when l_open > 0 then 'Compliance'
                        else 'System' end;
        end if;
        return null;
    exception
        when no_data_found then
            return null;
    end pending_with;

    function start_review(p_case_id in number, p_request_type in varchar2, p_trigger_source in varchar2,
                          p_justification in varchar2) return number is
        l_id    number;
        l_party xxcmp_parties%rowtype;
        l_case  xxcmp_cases%rowtype;
    begin
        xxfnd_vpd_pkg.begin_trusted;
        select * into l_case from xxcmp_cases where case_id = p_case_id;
        select * into l_party from xxcmp_parties where party_id = l_case.party_id;
        l_id := create_request(p_party_type          => l_party.party_type,
                               p_party_name          => l_party.party_name,
                               p_registration_number => l_party.registration_number,
                               p_jurisdiction        => l_party.jurisdiction,
                               p_entity_type         => l_party.entity_type,
                               p_incorporation_date  => l_party.incorporation_date,
                               p_justification       => p_justification,
                               p_request_type        => p_request_type,
                               p_trigger_source      => p_trigger_source,
                               p_parent_request_id   => l_case.request_id,
                               p_parent_case_id      => p_case_id,
                               p_party_id            => l_case.party_id);
        update xxcmp_requests set party_selection = 'EXISTING', match_status = 'SELECTED' where request_id = l_id;
        submit(l_id);
        xxfnd_vpd_pkg.end_trusted;
        return l_id;
    exception
        when others then
            xxfnd_vpd_pkg.end_trusted;
            raise;
    end start_review;

end xxcmp_request_pkg;
/

--------------------------------------------------------------------------------
-- Cases
--------------------------------------------------------------------------------
create or replace package body xxcmp_case_pkg as

    -- Numeric KYC parameter maintained by administrators (lookup KYC_PARAMETER, value in TAG).
    function param(p_code in varchar2, p_default in number) return number is
        l_value number;
    begin
        select max(to_number(tag default null on conversion error)) into l_value from xxfnd_lookup_values
         where lookup_type = 'KYC_PARAMETER' and lookup_code = p_code and enabled_flag = 'Y';
        return nvl(l_value, p_default);
    end param;

    function get_case(p_case_id in number) return xxcmp_cases%rowtype is
        l_case xxcmp_cases%rowtype;
    begin
        select * into l_case from xxcmp_cases where case_id = p_case_id;
        return l_case;
    end get_case;

    function create_case(p_request_id in number, p_assigned_to in varchar2 default null) return number is
        l_req  xxcmp_requests%rowtype;
        l_id   number;
        l_wf   number;
        l_sla  number := param('CASE_SLA_DAYS', 10);   -- private function: not callable inside SQL
    begin
        xxfnd_vpd_pkg.begin_trusted;
        select * into l_req from xxcmp_requests where request_id = p_request_id;
        insert into xxcmp_cases (case_number, request_id, party_id, parent_case_id, assigned_to, sla_due_date)
        values ('CASE-' || lpad(xxcmp_case_number_s.nextval, 6, '0'), p_request_id, l_req.party_id, l_req.parent_case_id,
                upper(p_assigned_to), trunc(sysdate) + l_sla)
        returning case_id into l_id;
        -- the officer's investigation questionnaire
        insert into xxcmp_request_answers (request_id, case_id, respondent_type, question_id)
        select p_request_id, l_id, 'OFFICER', q.question_id
          from xxcmp_questions q
          join xxcmp_questionnaires qn on qn.questionnaire_code = q.questionnaire_code
         where qn.audience = 'OFFICER' and qn.enabled_flag = 'Y' and q.enabled_flag = 'Y'
           and not exists (select 1 from xxcmp_request_answers a
                            where a.request_id = p_request_id and a.respondent_type = 'OFFICER' and a.question_id = q.question_id);
        -- Compliance approved the request: the request is Approved and its party too
        update xxcmp_requests set request_status = 'APPROVED', completed_date = systimestamp, last_action_date = sysdate
         where request_id = p_request_id;
        update xxcmp_parties set party_status = 'APPROVED' where party_id = l_req.party_id and party_status = 'PENDING';
        l_wf := apex_workflow.start_workflow(
                    p_application_id => v('APP_ID'),
                    p_static_id      => 'KYC_CASE',
                    -- the requester (or whoever opened a manual case) initiates; separation of duties excludes them
                    p_initiator      => coalesce(l_req.requester_user_name, nullif(v('APP_USER'), 'nobody')),
                    p_detail_pk      => to_char(l_id));
        update xxcmp_cases set workflow_id = l_wf where case_id = l_id;
        xxfnd_vpd_pkg.end_trusted;
        return l_id;
    exception
        when others then
            xxfnd_vpd_pkg.end_trusted;
            raise;
    end create_case;

    function create_manual_case(p_party_id in number, p_justification in varchar2) return number is
        l_party xxcmp_parties%rowtype;
        l_req   number;
    begin
        select * into l_party from xxcmp_parties where party_id = p_party_id;
        l_req := xxcmp_request_pkg.create_request(
                     p_party_type          => l_party.party_type,
                     p_party_name          => l_party.party_name,
                     p_registration_number => l_party.registration_number,
                     p_jurisdiction        => l_party.jurisdiction,
                     p_entity_type         => l_party.entity_type,
                     p_incorporation_date  => l_party.incorporation_date,
                     p_justification       => p_justification,
                     p_request_type        => 'EVENT_TRIGGERED_REVIEW',
                     p_trigger_source      => 'MANUAL',
                     p_party_id            => p_party_id);
        update xxcmp_requests set request_status = 'IN_PROGRESS', intake_outcome = 'ASSIGNED', submitted_date = systimestamp,
                                  party_selection = 'EXISTING', match_status = 'SELECTED', last_action_date = sysdate
         where request_id = l_req;
        return create_case(l_req, xxfnd_util_pkg.current_user);
    end create_manual_case;

    procedure assign(p_case_id in number, p_user_name in varchar2) is
    begin
        update xxcmp_cases set assigned_to = upper(p_user_name) where case_id = p_case_id and case_status = 'INVESTIGATION';
        if sql%rowcount = 0 then
            raise_application_error(-20611, 'Only a case under investigation can be reassigned.');
        end if;
    end assign;

    function investigation_owners(p_case_id in number) return varchar2 is
        l_case xxcmp_cases%rowtype;
    begin
        xxfnd_vpd_pkg.begin_trusted;
        l_case := get_case(p_case_id);
        xxfnd_vpd_pkg.end_trusted;
        return nvl(l_case.assigned_to, xxfnd_task_pkg.users_with_privilege('CASES', 'MANAGE'));
    exception
        when others then
            xxfnd_vpd_pkg.end_trusted;
            raise;
    end investigation_owners;

    function matrix(p_case in xxcmp_cases%rowtype) return xxcmp_approval_matrix%rowtype is
        l_row xxcmp_approval_matrix%rowtype;
    begin
        select * into l_row from xxcmp_approval_matrix where risk_tier = p_case.risk_tier;
        return l_row;
    exception
        when no_data_found then
            raise_application_error(-20612, 'The approval matrix has no row for risk tier ' || p_case.risk_tier || '.');
    end matrix;

    function required_levels(p_case_id in number) return number is
        l_case xxcmp_cases%rowtype := get_case(p_case_id);
        l_m    xxcmp_approval_matrix%rowtype := matrix(l_case);
    begin
        return case when l_case.enhanced_kyc_flag = 'Y' then greatest(l_m.required_levels, 2) else l_m.required_levels end;
    end required_levels;

    function level_role(p_case_id in number, p_level in number) return varchar2 is
        l_m xxcmp_approval_matrix%rowtype := matrix(get_case(p_case_id));
    begin
        return case p_level when 1 then l_m.level1_role_code
                            else nvl(l_m.level2_role_code, 'HEAD_OF_COMPLIANCE') end;
    end level_role;

    function sar_gate(p_case_id in number) return varchar2 is
        l_case xxcmp_cases%rowtype := get_case(p_case_id);
    begin
        return case when l_case.enhanced_kyc_flag = 'Y' then 'Y' else nvl(matrix(l_case).sar_gate_flag, 'N') end;
    end sar_gate;

    function is_editable(p_case_id in number) return varchar2 is
        l_status xxcmp_cases.case_status%type;
    begin
        select max(case_status) into l_status from xxcmp_cases where case_id = p_case_id;
        return case when l_status = 'INVESTIGATION' and xxfnd_privilege_pkg.has_privilege('CASES', 'MANAGE')
                    then 'Y' else 'N' end;
    end is_editable;

    -- Users who investigated or already decided this case, with the roles they acted under.
    function prior_actors(p_case_id in number) return apex_t_varchar2 is
        l_list apex_t_varchar2;
    begin
        select upper(u) bulk collect into l_list from (
            select assigned_to u from xxcmp_cases where case_id = p_case_id and assigned_to is not null
            union
            select actual_owner from apex_tasks
             where task_def_static_id = 'CASE_INVESTIGATION' and detail_pk = to_char(p_case_id) and actual_owner is not null
            union
            select decided_by from xxcmp_case_decisions where case_id = p_case_id);
        return l_list;
    end prior_actors;

    function level_approvers(p_case_id in number) return varchar2 is
        l_case  xxcmp_cases%rowtype;
        l_role  varchar2(30);
        l_prior apex_t_varchar2;
        l_out   varchar2(32767);
        l_roles apex_t_varchar2;
    begin
        xxfnd_vpd_pkg.begin_trusted;
        l_case  := get_case(p_case_id);
        l_role  := level_role(p_case_id, l_case.current_level);
        l_prior := prior_actors(p_case_id);
        for u in (select distinct ur.user_name from xxfnd_user_roles_v ur
                   where ur.role_code = l_role and ur.active_flag = 'Y'
                   order by ur.user_name) loop
            -- four eyes: nobody decides a case they investigated or already decided,
            -- nor while holding a role that may never be combined with this one
            select role_code bulk collect into l_roles from xxcmp_case_decisions
             where case_id = p_case_id and decided_by = u.user_name and role_code is not null;
            if u.user_name not member of l_prior
               and not xxfnd_security_pkg.sod_conflict(l_role, l_roles, u.user_name) then
                l_out := l_out || case when l_out is not null then ',' end || u.user_name;
            end if;
        end loop;
        xxfnd_vpd_pkg.end_trusted;
        return l_out;
    exception
        when others then
            xxfnd_vpd_pkg.end_trusted;
            raise;
    end level_approvers;

    function submit_error(p_case_id in number) return varchar2 is
        l_case  xxcmp_cases%rowtype := get_case(p_case_id);
        l_count pls_integer;
    begin
        if l_case.case_status <> 'INVESTIGATION' then
            return 'The case is not under investigation.';
        end if;
        if l_case.risk_tier is null then
            return 'Set the risk classification.';
        end if;
        select count(*) into l_count from xxcmp_screenings where case_id = p_case_id;
        if l_count = 0 then
            return 'Record at least one screening.';
        end if;
        select count(*) into l_count from xxcmp_rfis
         where entity_name = 'XXCMP_CASES' and pk1_value = to_char(p_case_id)
           and continue_other_work_flag = 'N' and rfi_status in ('WAITING_FOR_INFORMATION','ON_HOLD_PENDING');
        if l_count > 0 then
            return 'A request for information that pauses the case is still open.';
        end if;
        if l_case.enhanced_kyc_flag = 'Y' then
            select count(*) into l_count
              from xxcmp_request_answers a
              join xxcmp_questions q on q.question_id = a.question_id
             where a.case_id = p_case_id and a.respondent_type = 'OFFICER'
               and q.section_name = 'Enhanced Due Diligence'
               and a.answer_option_id is null and a.answer_text is null;
            if l_count > 0 then
                return 'Enhanced KYC: answer the source of funds and source of wealth questions.';
            end if;
        end if;
        return null;
    end submit_error;

    procedure submit_for_approval(p_case_id in number) is
        l_error varchar2(4000) := submit_error(p_case_id);
    begin
        if l_error is not null then
            raise_application_error(-20613, l_error);
        end if;
        -- completing the investigation task moves the KYC_CASE workflow on
        xxfnd_task_pkg.complete_open('CASE_INVESTIGATION', to_char(p_case_id));
    end submit_for_approval;

    function approval_error(p_case_id in number) return varchar2 is
        l_case    xxcmp_cases%rowtype := get_case(p_case_id);
        l_missing pls_integer;
    begin
        if l_case.case_status <> 'PENDING_APPROVAL' then
            return 'The case is not waiting for approval.';
        end if;
        if sar_gate(p_case_id) = 'Y' and l_case.sar_required_flag is null then
            return 'Record whether a Suspicious Activity Report is required.';
        end if;
        if xxfnd_util_pkg.current_user member of prior_actors(p_case_id) then
            return 'You investigated or already decided this case.';
        end if;
        -- every mandatory document of the party must be verified in this case
        select count(*) into l_missing
          from table(xxcmp_kyc_pkg.mandatory_categories('XXCMP_PARTIES',
                         (select jurisdiction from xxcmp_parties where party_id = l_case.party_id),
                         (select entity_type from xxcmp_parties where party_id = l_case.party_id))) m
         where not exists (
                 select 1
                   from xxfnd_attached_documents ad
                   join xxcmp_doc_verifications v on v.attached_document_id = ad.attached_document_id
                  where ad.entity_name = 'XXCMP_PARTIES' and ad.pk1_value = to_char(l_case.party_id)
                    and ad.category_code = m.column_value
                    and v.case_id = p_case_id and v.verification_status = 'VERIFIED');
        if l_missing > 0 then
            return l_missing || ' mandatory document(s) are not verified for this case.';
        end if;
        return null;
    end approval_error;

    procedure record_decision(p_case_id in number, p_outcome in varchar2, p_comments in varchar2, p_task_id in number) is
        l_case xxcmp_cases%rowtype;
    begin
        xxfnd_vpd_pkg.begin_trusted;
        l_case := get_case(p_case_id);
        insert into xxcmp_case_decisions (case_id, level_no, role_code, decided_by, outcome, comments, task_id)
        values (p_case_id, l_case.current_level, level_role(p_case_id, l_case.current_level),
                xxfnd_util_pkg.current_user, p_outcome, p_comments, p_task_id);
        if p_outcome = 'APPROVED' then
            update xxcmp_cases set current_level = current_level + 1 where case_id = p_case_id;
        end if;
        xxfnd_vpd_pkg.end_trusted;
    exception
        when others then
            xxfnd_vpd_pkg.end_trusted;
            raise;
    end record_decision;

    function next_review_date(p_case_id in number) return date is
        l_case   xxcmp_cases%rowtype := get_case(p_case_id);
        l_months number;
    begin
        select max(to_number(tag default null on conversion error)) into l_months
          from xxfnd_lookup_values where lookup_type = 'RISK_TIER' and lookup_code = l_case.risk_tier;
        if l_case.pep_flag = 'Y' then
            l_months := least(nvl(l_months, 12), param('PEP_REVIEW_MONTHS', 12));
        end if;
        return add_months(trunc(sysdate), nvl(l_months, 12));
    end next_review_date;

    procedure start_approval(p_case_id in number) is
    begin
        xxfnd_vpd_pkg.begin_trusted;
        update xxcmp_cases
           set case_status = 'PENDING_APPROVAL', current_level = 1, investigation_completed_date = systimestamp
         where case_id = p_case_id;
        xxfnd_vpd_pkg.end_trusted;
    exception
        when others then
            xxfnd_vpd_pkg.end_trusted;
            raise;
    end start_approval;

    function has_next_level(p_case_id in number) return varchar2 is
        l_result varchar2(1);
    begin
        xxfnd_vpd_pkg.begin_trusted;
        l_result := case when get_case(p_case_id).current_level <= required_levels(p_case_id) then 'Y' else 'N' end;
        xxfnd_vpd_pkg.end_trusted;
        return l_result;
    exception
        when others then
            xxfnd_vpd_pkg.end_trusted;
            raise;
    end has_next_level;

    procedure close_case(p_case_id in number, p_decision in varchar2) is
        l_case xxcmp_cases%rowtype := get_case(p_case_id);
        -- computed first: the function reads XXCMP_CASES, which would be mutating inside the UPDATE
        l_next date := case when p_decision = 'APPROVED' then nvl(l_case.next_review_date, next_review_date(p_case_id)) end;
    begin
        update xxcmp_cases
           set case_status      = p_decision,
               decision         = p_decision,
               decision_date    = systimestamp,
               next_review_date = l_next,
               closed_date      = systimestamp
         where case_id = p_case_id;
        -- the party's next KYC date follows its latest decided case (cleared when the KYC is rejected)
        update xxcmp_parties set next_kyc_date = l_next where party_id = l_case.party_id;
    end close_case;

    procedure approve_case(p_case_id in number) is
    begin
        xxfnd_vpd_pkg.begin_trusted;
        close_case(p_case_id, 'APPROVED');
        xxfnd_vpd_pkg.end_trusted;
    exception
        when others then
            xxfnd_vpd_pkg.end_trusted;
            raise;
    end approve_case;

    procedure reject_case(p_case_id in number) is
    begin
        xxfnd_vpd_pkg.begin_trusted;
        close_case(p_case_id, 'REJECTED');
        xxfnd_vpd_pkg.end_trusted;
    exception
        when others then
            xxfnd_vpd_pkg.end_trusted;
            raise;
    end reject_case;

    procedure apply_screening(p_case_id in number) is
        l_pep pls_integer;
        l_hit pls_integer;
    begin
        select count(case when pep_flag = 'Y' then 1 end), count(case when match_status = 'CONFIRMED_MATCH' then 1 end)
          into l_pep, l_hit
          from xxcmp_screenings where case_id = p_case_id;
        update xxcmp_cases
           set pep_flag          = case when l_pep > 0 then 'Y' else pep_flag end,
               enhanced_kyc_flag = case when l_pep > 0 or l_hit > 0 then 'Y' else enhanced_kyc_flag end
         where case_id = p_case_id and case_status = 'INVESTIGATION';
    end apply_screening;

end xxcmp_case_pkg;
/

-- A closed case cannot change any more (case closure locks it).
create or replace trigger xxcmp_cases_lock
before update on xxcmp_cases
for each row
when (old.closed_date is not null)
begin
    -- a party merge (XXCMP_PARTY_PKG.MERGE_PARTIES) only re-points the case to the party that is kept
    if updating('PARTY_ID') and not (updating('CASE_STATUS') or updating('DECISION') or updating('RISK_TIER')
                                     or updating('CLOSED_DATE') or updating('CONDITIONS') or updating('NEXT_REVIEW_DATE')
                                     or updating('ASSIGNED_TO') or updating('SAR_REQUIRED_FLAG') or updating('REQUEST_ID')) then
        return;
    end if;
    raise_application_error(-20614, 'Case ' || :old.case_number || ' is closed and cannot be changed.');
end;
/

-- ==== 16c-monitoring.sql
--------------------------------------------------------------------------------
-- 16c Monitoring  (release R14)
-- Ongoing monitoring of approved parties.
--   XXCMP_ALERT_RULES   what to watch (review due/overdue, case SLA, expiring documents, adverse screening),
--                       who is told, and whether a review starts on its own
--   XXCMP_ALERTS        the alerts raised by the rules (one per rule and subject), acknowledged or closed
--   XXCMP_WATCHLIST_V   each approved party with its latest approved case and where its review stands
--   XXCMP_MONITOR_PKG   daily run (periodic reviews, alerts), early reassessment, acknowledgement
-- Idempotent: safe on install and on every upgrade.
--------------------------------------------------------------------------------
create table if not exists xxcmp_alert_rules (
    alert_rule_id          number generated by default on null as identity,
    rule_code              varchar2(30)   not null,
    rule_name              varchar2(240)  not null,
    alert_type             varchar2(30)   not null,
    days_before            number         default 0 not null,
    risk_tier              varchar2(30),
    recipient_role_code    varchar2(30),
    notify_flag            varchar2(1)    default 'Y' not null,
    start_review_flag      varchar2(1)    default 'N' not null,
    enabled_flag           varchar2(1)    default 'Y' not null,
    description            varchar2(1000),
    -- standard WHO columns
    created_by               varchar2(255)  not null,
    creation_date            timestamp      not null,
    last_updated_by          varchar2(255)  not null,
    last_update_date         timestamp      not null,
    last_update_login        varchar2(255),
    object_version_number    number         default 1 not null,
    constraint xxcmp_alert_rules_pk primary key (alert_rule_id),
    constraint xxcmp_alert_rules_uk1 unique (rule_code),
    constraint xxcmp_alert_rules_ck1 check (alert_type in ('REVIEW_DUE','REVIEW_OVERDUE','SLA_BREACH','DOCUMENT_EXPIRY','ADVERSE_SCREENING')),
    constraint xxcmp_alert_rules_ck2 check (notify_flag in ('Y','N')),
    constraint xxcmp_alert_rules_ck3 check (start_review_flag in ('Y','N')),
    constraint xxcmp_alert_rules_ck4 check (enabled_flag in ('Y','N')),
    constraint xxcmp_alert_rules_ck5 check (days_before >= 0)
);
comment on table xxcmp_alert_rules is 'Monitoring rules: what raises an alert, how many days ahead (or of grace), for which risk tier, who is notified and whether an early review starts automatically.';
comment on column xxcmp_alert_rules.days_before is 'REVIEW_DUE / DOCUMENT_EXPIRY: days ahead; REVIEW_OVERDUE / SLA_BREACH: days of grace; ADVERSE_SCREENING: not used.';
comment on column xxcmp_alert_rules.start_review_flag is 'Y: the daily run also starts an event-triggered review (DOCUMENT_EXPIRY once expired, ADVERSE_SCREENING).';

create table if not exists xxcmp_alerts (
    alert_id               number generated by default on null as identity,
    alert_rule_id          number         not null,
    alert_key              varchar2(200)  not null,
    party_id               number,
    case_id                number,
    alert_message          varchar2(1000) not null,
    due_date               date,
    alert_status           varchar2(30)   default 'OPEN' not null,
    acknowledged_by        varchar2(255),
    acknowledged_date      timestamp,
    review_request_id      number,
    -- standard WHO columns
    created_by               varchar2(255)  not null,
    creation_date            timestamp      not null,
    last_updated_by          varchar2(255)  not null,
    last_update_date         timestamp      not null,
    last_update_login        varchar2(255),
    object_version_number    number         default 1 not null,
    constraint xxcmp_alerts_pk primary key (alert_id),
    constraint xxcmp_alerts_uk1 unique (alert_rule_id, alert_key),
    constraint xxcmp_alerts_fk1 foreign key (alert_rule_id) references xxcmp_alert_rules (alert_rule_id),
    constraint xxcmp_alerts_fk2 foreign key (party_id) references xxcmp_parties (party_id),
    constraint xxcmp_alerts_fk3 foreign key (case_id) references xxcmp_cases (case_id),
    constraint xxcmp_alerts_fk4 foreign key (review_request_id) references xxcmp_requests (request_id),
    constraint xxcmp_alerts_ck1 check (alert_status in ('OPEN','ACKNOWLEDGED','CLOSED'))
);
comment on table xxcmp_alerts is 'Alerts raised by the monitoring rules; the key (per rule) keeps one alert per subject, e.g. per case and review date.';
create index if not exists xxcmp_alerts_n1 on xxcmp_alerts (party_id, alert_status);
create index if not exists xxcmp_alerts_n2 on xxcmp_alerts (case_id);

begin
    for t in (select column_value table_name from table(apex_t_varchar2('XXCMP_ALERT_RULES','XXCMP_ALERTS'))) loop
        xxfnd_util_pkg.create_who_trigger(t.table_name);
    end loop;
end;
/

-- Every party with an approved case, as of its latest approved case.
create or replace view xxcmp_watchlist_v as
with latest as (
    select c.*,
           row_number() over (partition by c.party_id order by c.closed_date desc nulls last, c.case_id desc) as rn
      from xxcmp_cases c
     where c.case_status = 'APPROVED'
), lead_days as (
    select nvl(max(to_number(tag default null on conversion error)), 30) as days
      from xxfnd_lookup_values
     where lookup_type = 'KYC_PARAMETER' and lookup_code = 'REVIEW_LEAD_DAYS' and enabled_flag = 'Y'
), open_review as (
    select r.party_id, max(r.request_id) as request_id, max(r.request_number) as request_number
      from xxcmp_requests r
     where r.request_type <> 'NEW_ONBOARDING'
       and r.request_status in ('DRAFT','IN_PROGRESS','INFO_NEEDED')
     group by r.party_id
)
select p.party_id,
       p.party_number,
       p.party_name,
       p.party_type,
       p.jurisdiction,
       l.case_id,
       l.case_number,
       l.risk_tier,
       l.pep_flag,
       l.enhanced_kyc_flag,
       cast(l.closed_date as date) as approved_date,
       l.next_review_date,
       l.next_review_date - trunc(sysdate) as days_to_review,
       case when l.next_review_date < trunc(sysdate)                  then 'OVERDUE'
            when o.request_id is not null                             then 'IN_REVIEW'
            when l.next_review_date - trunc(sysdate) <= d.days        then 'DUE'
            else 'CURRENT' end as review_status,
       o.request_id as review_request_id,
       o.request_number as review_request_number,
       (select count(*) from xxcmp_alerts a where a.party_id = p.party_id and a.alert_status = 'OPEN') as open_alerts
  from latest l
  join xxcmp_parties p on p.party_id = l.party_id
  left join open_review o on o.party_id = l.party_id
 cross join lead_days d
 where l.rn = 1;
comment on table xxcmp_watchlist_v is 'Monitoring watchlist: approved parties, their latest approved case, next review date and status (CURRENT, DUE, IN_REVIEW, OVERDUE), open review request and open alerts.';

create or replace package xxcmp_monitor_pkg authid definer as

    -- Daily run (APEX Automation "KYC monitoring"): periodic reviews, then the alert rules.
    procedure run_daily;
    -- Starts a periodic review for every party whose review falls due within the lead days. Returns how many.
    function start_periodic_reviews return number;
    -- Evaluates every enabled alert rule. Returns the number of new alerts.
    function run_alerts return number;

    -- Early reassessment of an approved case (Monitoring Watchlist); null when allowed.
    function early_review_error(p_case_id in number) return varchar2;
    function trigger_early_review(p_case_id in number, p_reason in varchar2, p_alert_id in number default null,
                                  p_source in varchar2 default 'MANUAL') return number;

    procedure acknowledge(p_alert_id in number);

end xxcmp_monitor_pkg;
/

create or replace package body xxcmp_monitor_pkg as

    function open_review(p_party_id in number) return varchar2 is
        l_number xxcmp_requests.request_number%type;
    begin
        select max(request_number) into l_number
          from xxcmp_requests
         where party_id = p_party_id
           and request_status in ('DRAFT','IN_PROGRESS','INFO_NEEDED');
        return l_number;
    end open_review;

    -- Closes the party's open alerts, linking them to the review that answers them.
    procedure close_alerts(p_party_id in number, p_request_id in number) is
    begin
        update xxcmp_alerts
           set alert_status = 'CLOSED', review_request_id = nvl(review_request_id, p_request_id)
         where party_id = p_party_id and alert_status in ('OPEN','ACKNOWLEDGED');
    end close_alerts;

    function early_review_error(p_case_id in number) return varchar2 is
        l_case  xxcmp_cases%rowtype;
        l_open  varchar2(30);
    begin
        select * into l_case from xxcmp_cases where case_id = p_case_id;
        if l_case.case_status <> 'APPROVED' then
            return 'Only an approved case can be reassessed.';
        end if;
        l_open := open_review(l_case.party_id);
        if l_open is not null then
            return 'Request ' || l_open || ' for this party is already in progress.';
        end if;
        return null;
    exception
        when no_data_found then
            return 'Case not found.';
    end early_review_error;

    function trigger_early_review(p_case_id in number, p_reason in varchar2, p_alert_id in number default null,
                                  p_source in varchar2 default 'MANUAL') return number is
        l_error varchar2(4000) := early_review_error(p_case_id);
        l_req   number;
        l_party number;
    begin
        if l_error is not null then
            raise_application_error(-20701, l_error);
        end if;
        if trim(p_reason) is null then
            raise_application_error(-20702, 'Give the reason for the early reassessment.');
        end if;
        xxfnd_vpd_pkg.begin_trusted;
        select party_id into l_party from xxcmp_cases where case_id = p_case_id;
        l_req := xxcmp_request_pkg.start_review(p_case_id, 'EVENT_TRIGGERED_REVIEW', p_source, p_reason);
        if p_alert_id is not null then
            update xxcmp_alerts set review_request_id = l_req where alert_id = p_alert_id;
        end if;
        close_alerts(l_party, l_req);
        xxfnd_vpd_pkg.end_trusted;
        return l_req;
    exception
        when others then
            xxfnd_vpd_pkg.end_trusted;
            raise;
    end trigger_early_review;

    procedure acknowledge(p_alert_id in number) is
    begin
        update xxcmp_alerts
           set alert_status = 'ACKNOWLEDGED', acknowledged_by = xxfnd_util_pkg.current_user,
               acknowledged_date = systimestamp
         where alert_id = p_alert_id and alert_status = 'OPEN';
    end acknowledge;

    function start_periodic_reviews return number is
        l_count pls_integer := 0;
        l_req   number;
    begin
        for w in (select case_id, party_id, next_review_date from xxcmp_watchlist_v
                   where review_status in ('DUE','OVERDUE') and review_request_id is null) loop
            begin
                l_req := xxcmp_request_pkg.start_review(w.case_id, 'PERIODIC_REVIEW', 'SCHEDULED',
                             'Periodic review due ' || to_char(w.next_review_date, 'DD-Mon-YYYY') || '.');
                close_alerts(w.party_id, l_req);
                l_count := l_count + 1;
            exception
                when others then
                    -- one party must not stop the others; the error is kept in the APEX debug log
                    apex_debug.error('Periodic review for case %s failed: %s', w.case_id, sqlerrm);
            end;
        end loop;
        return l_count;
    end start_periodic_reviews;

    function run_alerts return number is
        l_new   pls_integer := 0;
        l_id    number;
        l_req   number;

        procedure raise_alert(p_rule in xxcmp_alert_rules%rowtype, p_key in varchar2, p_party in number,
                              p_case in number, p_message in varchar2, p_due in date, p_review in boolean) is
            l_tokens json_object_t := json_object_t();
            l_url    varchar2(4000);
        begin
            insert into xxcmp_alerts (alert_rule_id, alert_key, party_id, case_id, alert_message, due_date)
            values (p_rule.alert_rule_id, p_key, p_party, p_case, substr(p_message, 1, 1000), p_due)
            returning alert_id into l_id;
            l_new := l_new + 1;
            if p_rule.notify_flag = 'Y' and p_rule.recipient_role_code is not null then
                begin
                    begin
                        l_url := apex_page.get_url(p_page => 221, p_plain_url => true);
                    exception
                        when others then l_url := null;   -- no APEX session
                    end;
                    l_tokens.put('ALERT_NAME', apex_escape.html(p_rule.rule_name));
                    l_tokens.put('ALERT_MESSAGE', apex_escape.html(p_message));
                    l_tokens.put('LINK', l_url);
                    xxfnd_notify_pkg.send_to_users('KYC_ALERT', xxfnd_task_pkg.users_in_role(p_rule.recipient_role_code),
                                                   l_tokens.to_clob);
                exception
                    when others then
                        -- the alert stands even when the e-mail cannot be sent
                        apex_debug.error('Alert %s: e-mail not sent: %s', l_id, sqlerrm);
                end;
            end if;
            if p_review and p_rule.start_review_flag = 'Y' and p_case is not null
               and early_review_error(p_case) is null then
                l_req := trigger_early_review(p_case, 'Automatic: ' || p_message, l_id, 'EVENT_DRIVEN');
            end if;
        exception
            when dup_val_on_index then
                null;   -- already raised for this subject
        end raise_alert;
    begin
        xxfnd_vpd_pkg.begin_trusted;
        -- Alerts whose subject has moved on: superseded case, closed investigation.
        update xxcmp_alerts a
           set a.alert_status = 'CLOSED'
         where a.alert_status in ('OPEN','ACKNOWLEDGED')
           and a.case_id is not null
           and not exists (select 1 from xxcmp_watchlist_v w where w.case_id = a.case_id)
           and not exists (select 1 from xxcmp_cases c where c.case_id = a.case_id
                            and c.case_status in ('INVESTIGATION','PENDING_APPROVAL'));

        for r in (select * from xxcmp_alert_rules where enabled_flag = 'Y' order by rule_code) loop
            begin
                if r.alert_type = 'REVIEW_DUE' then
                    for w in (select * from xxcmp_watchlist_v
                               where next_review_date between trunc(sysdate) and trunc(sysdate) + r.days_before
                                 and review_request_id is null   -- a review is already running
                                 and (r.risk_tier is null or risk_tier = r.risk_tier)) loop
                        raise_alert(r, 'CASE:' || w.case_id || ':' || to_char(w.next_review_date, 'YYYYMMDD'), w.party_id, w.case_id,
                                    w.party_name || ': review due on ' || to_char(w.next_review_date, 'DD-Mon-YYYY')
                                    || ' (' || w.case_number || ').', w.next_review_date, false);
                    end loop;
                elsif r.alert_type = 'REVIEW_OVERDUE' then
                    for w in (select * from xxcmp_watchlist_v
                               where next_review_date + r.days_before < trunc(sysdate)
                                 and (r.risk_tier is null or risk_tier = r.risk_tier)) loop
                        raise_alert(r, 'CASE:' || w.case_id || ':' || to_char(w.next_review_date, 'YYYYMMDD'), w.party_id, w.case_id,
                                    w.party_name || ': review overdue since ' || to_char(w.next_review_date, 'DD-Mon-YYYY')
                                    || nvl2(w.review_request_number, ' (review ' || w.review_request_number || ' in progress).', '.'),
                                    w.next_review_date, false);
                    end loop;
                elsif r.alert_type = 'SLA_BREACH' then
                    for c in (select c.case_id, c.case_number, c.party_id, c.sla_due_date, p.party_name
                                from xxcmp_cases c join xxcmp_parties p on p.party_id = c.party_id
                               where c.case_status = 'INVESTIGATION'
                                 and c.sla_due_date + r.days_before < trunc(sysdate)
                                 and (r.risk_tier is null or c.risk_tier = r.risk_tier)) loop
                        raise_alert(r, 'CASE:' || c.case_id, c.party_id, c.case_id,
                                    c.case_number || ' (' || c.party_name || '): investigation past its SLA of '
                                    || to_char(c.sla_due_date, 'DD-Mon-YYYY') || '.', c.sla_due_date, false);
                    end loop;
                elsif r.alert_type = 'DOCUMENT_EXPIRY' then
                    for d in (select w.party_id, w.case_id, w.party_name, a.attached_document_id, a.title,
                                     a.category_name, a.expiry_date
                                from xxcmp_watchlist_v w
                                join xxfnd_attached_documents_v a
                                  on a.entity_name = 'XXCMP_PARTIES' and a.pk1_value = to_char(w.party_id)
                               where a.expiry_date <= trunc(sysdate) + r.days_before
                                 and (r.risk_tier is null or w.risk_tier = r.risk_tier)) loop
                        raise_alert(r, 'DOC:' || d.attached_document_id || ':' || to_char(d.expiry_date, 'YYYYMMDD'),
                                    d.party_id, d.case_id,
                                    d.party_name || ': ' || nvl(d.category_name, d.title)
                                    || case when d.expiry_date < trunc(sysdate) then ' expired on ' else ' expires on ' end
                                    || to_char(d.expiry_date, 'DD-Mon-YYYY') || '.',
                                    d.expiry_date, d.expiry_date < trunc(sysdate));
                    end loop;
                elsif r.alert_type = 'ADVERSE_SCREENING' then
                    -- a screening recorded after the party was approved that is not clean
                    for s in (select w.party_id, w.case_id, w.party_name, s.screening_id, s.screened_date,
                                     xxfnd_util_pkg.lookup_meaning('SCREENING_TYPE', s.screening_type) as check_type,
                                     xxfnd_util_pkg.lookup_meaning('SCREENING_MATCH_STATUS', s.match_status) as result
                                from xxcmp_watchlist_v w
                                join xxcmp_screenings s on s.party_id = w.party_id
                               where s.creation_date > w.approved_date
                                 and (s.match_status in ('POTENTIAL_MATCH','CONFIRMED_MATCH')
                                      or 'Y' in (s.pep_flag, s.sanctions_flag, s.adverse_media_flag))
                                 and (r.risk_tier is null or w.risk_tier = r.risk_tier)) loop
                        raise_alert(r, 'SCREENING:' || s.screening_id, s.party_id, s.case_id,
                                    s.party_name || ': ' || s.check_type || ' - ' || s.result || ' on '
                                    || to_char(s.screened_date, 'DD-Mon-YYYY') || '.', s.screened_date, true);
                    end loop;
                end if;
            exception
                when others then
                    apex_debug.error('Alert rule %s failed: %s', r.rule_code, sqlerrm);
            end;
        end loop;
        xxfnd_vpd_pkg.end_trusted;
        return l_new;
    exception
        when others then
            xxfnd_vpd_pkg.end_trusted;
            raise;
    end run_alerts;

    procedure run_daily is
        l_reviews number;
        l_alerts  number;
    begin
        xxfnd_vpd_pkg.begin_trusted;
        l_reviews := start_periodic_reviews;
        l_alerts  := run_alerts;
        xxfnd_vpd_pkg.end_trusted;
        apex_debug.info('KYC monitoring: %s periodic review(s) started, %s new alert(s).', l_reviews, l_alerts);
    exception
        when others then
            xxfnd_vpd_pkg.end_trusted;
            raise;
    end run_daily;

end xxcmp_monitor_pkg;
/

-- ==== 16e-party-pkg.sql
--------------------------------------------------------------------------------
-- 16e Party logic (party feature: pages 20-24, and the common party region on the Global Page)
--   XXCMP_PARTY_PKG: the rules and save of the common party form (Party dialog 24, Create Request
--   step 1 on 201, new owner / officer on 23), party status, owner / officer rules, the merge of a
--   duplicate party (Compliance) and the common party card. Runs after 16b/16c: the merge re-points
--   requests, cases, screenings, alerts, notes and beneficial-owner decisions.
-- Organisation / individual share one column per pair: JURISDICTION = country / nationality,
-- REGISTRATION_NUMBER = registration / ID number, ENTITY_TYPE = entity / ID type (lookup
-- ENTITY_TYPE / ID_DOCUMENT_TYPE), INCORPORATION_DATE = incorporation / birth date.
-- Idempotent: safe on install and on every upgrade.
--------------------------------------------------------------------------------
create or replace package xxcmp_party_pkg authid definer as

    -- Label of a shared party field for the party type: JURISDICTION, REGISTRATION_NUMBER, ENTITY_TYPE,
    -- INCORPORATION_DATE (for example Registration No. / ID Number).
    function field_label(p_party_type in varchar2, p_field in varchar2) return varchar2;
    -- Lookup type of ENTITY_TYPE for the party type (ENTITY_TYPE / ID_DOCUMENT_TYPE).
    function entity_lookup(p_party_type in varchar2) return varchar2;

    -- Party number of another enabled party with the same type, registration / ID number (ignoring spaces and
    -- punctuation) and country, or null. Reads the whole party master (trusted); returns only the number.
    function exact_party_number(p_party_type          in varchar2,
                                p_registration_number in varchar2,
                                p_jurisdiction        in varchar2,
                                p_exclude_party_id    in number default null) return varchar2;

    -- The rules of the common party form (null = acceptable). Type, name and country required;
    -- organisation: registration number and entity type required; individual: ID type required when an
    -- ID number is given; email or phone required (email must be valid); the date not in the future;
    -- no other party with the same number and country. P_DRAFT = Y checks only the type and the name.
    function party_error(p_party_id            in number,
                         p_party_type          in varchar2,
                         p_party_name          in varchar2,
                         p_jurisdiction        in varchar2,
                         p_registration_number in varchar2,
                         p_entity_type         in varchar2,
                         p_incorporation_date  in date,
                         p_email               in varchar2,
                         p_phone               in varchar2,
                         p_draft               in varchar2 default 'N') return varchar2;

    -- Inserts (P_PARTY_ID null) or updates the party's form fields, without a privilege check (the request
    -- package creates the Pending party of a request through it). A new party is APPROVED unless
    -- P_PARTY_STATUS says otherwise. Null P_DATA_PROVENANCE / P_ENABLED_FLAG keep the current values.
    procedure put_party(p_party_id            in out number,
                        p_party_type          in varchar2,
                        p_party_name          in varchar2,
                        p_jurisdiction        in varchar2,
                        p_registration_number in varchar2,
                        p_entity_type         in varchar2,
                        p_incorporation_date  in date,
                        p_email               in varchar2,
                        p_phone               in varchar2,
                        p_website             in varchar2,
                        p_fax                 in varchar2,
                        p_party_status        in varchar2 default null,
                        p_data_provenance     in varchar2 default null,
                        p_enabled_flag        in varchar2 default null);

    -- Compliance saves the common party form (Party dialog, new owner / officer): Parties - Create for a new
    -- party, Parties - Manage to change one; the form rules apply. A party created here is Approved.
    procedure save_party(p_party_id            in out number,
                         p_party_type          in varchar2,
                         p_party_name          in varchar2,
                         p_jurisdiction        in varchar2,
                         p_registration_number in varchar2,
                         p_entity_type         in varchar2,
                         p_incorporation_date  in date,
                         p_email               in varchar2,
                         p_phone               in varchar2,
                         p_website             in varchar2 default null,
                         p_fax                 in varchar2 default null,
                         p_data_provenance     in varchar2 default null,
                         p_enabled_flag        in varchar2 default null);

    -- Party status: PENDING, APPROVED, REJECTED, CANCELLED.
    procedure set_status(p_party_id in number, p_status in varchar2);

    -- Fills the items of the common party region (P0_PARTY_*) with the party, or empties them for a new party.
    -- Compliance (Parties - View) reads any party; a requester only a party of one of their own requests.
    -- P_READ_ONLY = Y shows the region read only.
    procedure load_items(p_party_id in number, p_read_only in varchar2 default 'N');

    -- Owner / officer rules (null = acceptable): Ownership % required for Shareholder, Beneficial Owner and
    -- Parent Company and empty for the other types; the active owners of a party hold at most 100%.
    function relationship_error(p_relationship_id   in number,
                                p_object_party_id   in number,
                                p_relationship_type in varchar2,
                                p_percentage        in number,
                                p_start_date        in date,
                                p_end_date          in date) return varchar2;

    -- Compliance merges the duplicate P_FROM_PARTY_ID into P_INTO_PARTY_ID (Parties - Manage): requests, cases,
    -- screenings, alerts, notes, beneficial-owner decisions, contacts, relationships and documents move to the
    -- kept party; its empty details are completed from the duplicate; the duplicate is disabled and points to it.
    procedure merge_parties(p_from_party_id in number, p_into_party_id in number, p_note in varchar2 default null);

    -- Y when the party exists and is enabled (a merged or disabled party is not edited or merged again).
    function is_enabled(p_party_id in number) return varchar2;

    -- The common Party card (HTML) shown on every screen that shows a party: number, name, type, registration /
    -- identity, country, main contact details, primary contact person, party status and next KYC date. Follows
    -- data security: a user who may not see the party gets a short note instead.
    function card_html(p_party_id in number) return clob;

end xxcmp_party_pkg;
/

create or replace package body xxcmp_party_pkg as

    -- relationship types that are ownership (Ownership % required)
    c_ownership_types constant varchar2(200) := ':SHAREHOLDER:BENEFICIAL_OWNER:PARENT_COMPANY:';

    function field_label(p_party_type in varchar2, p_field in varchar2) return varchar2 is
        l_person boolean := p_party_type = 'PERSON';
    begin
        return case p_field
                   when 'JURISDICTION'        then case when l_person then 'Nationality'   else 'Country' end
                   when 'REGISTRATION_NUMBER' then case when l_person then 'ID Number'     else 'Registration No.' end
                   when 'ENTITY_TYPE'         then case when l_person then 'ID Type'       else 'Entity Type' end
                   when 'INCORPORATION_DATE'  then case when l_person then 'Date of Birth' else 'Incorporation Date' end
               end;
    end field_label;

    function entity_lookup(p_party_type in varchar2) return varchar2 is
    begin
        return case when p_party_type = 'PERSON' then 'ID_DOCUMENT_TYPE' else 'ENTITY_TYPE' end;
    end entity_lookup;

    function norm(p_value in varchar2) return varchar2 is
    begin
        return upper(regexp_replace(p_value, '[^[:alnum:]]', ''));
    end norm;

    function exact_party_number(p_party_type          in varchar2,
                                p_registration_number in varchar2,
                                p_jurisdiction        in varchar2,
                                p_exclude_party_id    in number default null) return varchar2 is
        l_id     varchar2(100) := norm(p_registration_number);
        l_number xxcmp_parties.party_number%type;
    begin
        if l_id is null or p_jurisdiction is null then
            return null;
        end if;
        xxfnd_vpd_pkg.begin_trusted;    -- requesters cannot read the party master; only the number leaves
        select min(party_number) into l_number
          from xxcmp_parties p
         where p.party_type = p_party_type and p.enabled_flag = 'Y' and p.jurisdiction = p_jurisdiction
           and p.party_status not in ('REJECTED', 'CANCELLED')
           and p.party_id <> nvl(p_exclude_party_id, -1)
           and upper(regexp_replace(p.registration_number, '[^[:alnum:]]', '')) = l_id;
        xxfnd_vpd_pkg.end_trusted;
        return l_number;
    exception
        when others then
            xxfnd_vpd_pkg.end_trusted;
            raise;
    end exact_party_number;

    function party_error(p_party_id            in number,
                         p_party_type          in varchar2,
                         p_party_name          in varchar2,
                         p_jurisdiction        in varchar2,
                         p_registration_number in varchar2,
                         p_entity_type         in varchar2,
                         p_incorporation_date  in date,
                         p_email               in varchar2,
                         p_phone               in varchar2,
                         p_draft               in varchar2 default 'N') return varchar2 is
        l_exact varchar2(30);
    begin
        if p_party_type is null or p_party_type not in ('ORGANIZATION', 'PERSON') then
            return 'Choose whether the party is an organisation or an individual.';
        elsif trim(p_party_name) is null then
            return 'Enter the name.';
        elsif p_draft = 'Y' then
            return null;
        elsif p_jurisdiction is null then
            return 'Enter the ' || lower(field_label(p_party_type, 'JURISDICTION')) || '.';
        elsif p_party_type = 'ORGANIZATION' and trim(p_registration_number) is null then
            return 'Enter the registration number.';
        elsif p_party_type = 'ORGANIZATION' and p_entity_type is null then
            return 'Choose the entity type.';
        elsif p_party_type = 'PERSON' and trim(p_registration_number) is not null and p_entity_type is null then
            return 'Choose the ID type of the ID number.';
        elsif trim(p_email) is null and trim(p_phone) is null then
            return 'Enter an email or a phone number.';
        elsif trim(p_email) is not null and not regexp_like(trim(p_email), '^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$') then
            return 'Enter a valid email.';
        elsif p_incorporation_date > trunc(sysdate) then
            return 'The ' || lower(field_label(p_party_type, 'INCORPORATION_DATE')) || ' cannot be in the future.';
        end if;
        l_exact := exact_party_number(p_party_type, p_registration_number, p_jurisdiction, p_party_id);
        if l_exact is not null then
            return 'Party ' || l_exact || ' already has this ' || lower(field_label(p_party_type, 'REGISTRATION_NUMBER'))
                   || ' and ' || lower(field_label(p_party_type, 'JURISDICTION')) || ': use that party.';
        end if;
        return null;
    end party_error;

    procedure put_party(p_party_id            in out number,
                        p_party_type          in varchar2,
                        p_party_name          in varchar2,
                        p_jurisdiction        in varchar2,
                        p_registration_number in varchar2,
                        p_entity_type         in varchar2,
                        p_incorporation_date  in date,
                        p_email               in varchar2,
                        p_phone               in varchar2,
                        p_website             in varchar2,
                        p_fax                 in varchar2,
                        p_party_status        in varchar2 default null,
                        p_data_provenance     in varchar2 default null,
                        p_enabled_flag        in varchar2 default null) is
    begin
        xxfnd_vpd_pkg.begin_trusted;
        if p_party_id is null then
            insert into xxcmp_parties (party_type, party_name, jurisdiction, registration_number, entity_type,
                                       incorporation_date, email, phone, website, fax, party_status, data_provenance,
                                       enabled_flag)
            values (p_party_type, trim(p_party_name), p_jurisdiction, trim(p_registration_number), p_entity_type,
                    p_incorporation_date, trim(p_email), trim(p_phone), trim(p_website), trim(p_fax),
                    nvl(p_party_status, 'APPROVED'), nvl(p_data_provenance, 'SELF_DECLARED'), nvl(p_enabled_flag, 'Y'))
            returning party_id into p_party_id;
        else
            update xxcmp_parties
               set party_type          = p_party_type,
                   party_name          = trim(p_party_name),
                   jurisdiction        = p_jurisdiction,
                   registration_number = trim(p_registration_number),
                   entity_type         = p_entity_type,
                   incorporation_date  = p_incorporation_date,
                   email               = trim(p_email),
                   phone               = trim(p_phone),
                   website             = trim(p_website),
                   fax                 = trim(p_fax),
                   party_status        = nvl(p_party_status, party_status),
                   data_provenance     = nvl(p_data_provenance, data_provenance),
                   enabled_flag        = nvl(p_enabled_flag, enabled_flag)
             where party_id = p_party_id;
        end if;
        xxfnd_vpd_pkg.end_trusted;
    exception
        when others then
            xxfnd_vpd_pkg.end_trusted;
            raise;
    end put_party;

    procedure save_party(p_party_id            in out number,
                         p_party_type          in varchar2,
                         p_party_name          in varchar2,
                         p_jurisdiction        in varchar2,
                         p_registration_number in varchar2,
                         p_entity_type         in varchar2,
                         p_incorporation_date  in date,
                         p_email               in varchar2,
                         p_phone               in varchar2,
                         p_website             in varchar2 default null,
                         p_fax                 in varchar2 default null,
                         p_data_provenance     in varchar2 default null,
                         p_enabled_flag        in varchar2 default null) is
        l_error varchar2(4000);
    begin
        if p_party_id is null and not xxfnd_privilege_pkg.has_privilege('PARTIES', 'CREATE') then
            raise_application_error(-20701, 'You are not allowed to create parties.');
        elsif p_party_id is not null and not xxfnd_privilege_pkg.has_privilege('PARTIES', 'MANAGE') then
            raise_application_error(-20706, 'You are not allowed to change parties.');
        elsif p_party_id is not null and is_enabled(p_party_id) = 'N' and nvl(p_enabled_flag, 'N') = 'N' then
            raise_application_error(-20707, 'A disabled or merged party cannot be changed.');
        end if;
        l_error := party_error(p_party_id, p_party_type, p_party_name, p_jurisdiction, p_registration_number,
                               p_entity_type, p_incorporation_date, p_email, p_phone);
        if l_error is not null then
            raise_application_error(-20705, l_error);
        end if;
        put_party(p_party_id, p_party_type, p_party_name, p_jurisdiction, p_registration_number, p_entity_type,
                  p_incorporation_date, p_email, p_phone, p_website, p_fax, null, p_data_provenance, p_enabled_flag);
    end save_party;

    procedure set_status(p_party_id in number, p_status in varchar2) is
    begin
        xxfnd_vpd_pkg.begin_trusted;
        update xxcmp_parties set party_status = p_status where party_id = p_party_id and party_status <> p_status;
        xxfnd_vpd_pkg.end_trusted;
    exception
        when others then
            xxfnd_vpd_pkg.end_trusted;
            raise;
    end set_status;

    procedure load_items(p_party_id in number, p_read_only in varchar2 default 'N') is
        l_p     xxcmp_parties%rowtype;
        l_mine  pls_integer;

        procedure put(p_item in varchar2, p_value in varchar2) is
        begin
            apex_util.set_session_state(p_item, p_value);
        end put;
    begin
        if p_party_id is not null then
            xxfnd_vpd_pkg.begin_trusted;
            select count(*) into l_mine from xxcmp_requests
             where party_id = p_party_id and upper(requester_user_name) = upper(xxfnd_util_pkg.current_user);
            if l_mine > 0 or xxfnd_privilege_pkg.has_privilege('PARTIES', 'VIEW') then
                select * into l_p from xxcmp_parties where party_id = p_party_id;
            end if;
            xxfnd_vpd_pkg.end_trusted;
        end if;
        put('P0_PARTY_ID',                  to_char(l_p.party_id));
        put('P0_PARTY_NUMBER',              l_p.party_number);
        put('P0_PARTY_TYPE',                nvl(l_p.party_type, 'ORGANIZATION'));
        put('P0_PARTY_NAME',                l_p.party_name);
        put('P0_PARTY_JURISDICTION',        l_p.jurisdiction);
        put('P0_PARTY_REGISTRATION_NUMBER', l_p.registration_number);
        put('P0_PARTY_ENTITY_TYPE',         l_p.entity_type);
        put('P0_PARTY_INCORPORATION_DATE',  to_char(l_p.incorporation_date));
        put('P0_PARTY_EMAIL',               l_p.email);
        put('P0_PARTY_PHONE',               l_p.phone);
        put('P0_PARTY_WEBSITE',             l_p.website);
        put('P0_PARTY_FAX',                 l_p.fax);
        put('P0_PARTY_DATA_PROVENANCE',     nvl(l_p.data_provenance, 'SELF_DECLARED'));
        put('P0_PARTY_LAST_VERIFIED_DATE',  to_char(l_p.last_verified_date, 'DD-MON-YYYY'));
        put('P0_PARTY_STATUS',              xxfnd_util_pkg.lookup_meaning('PARTY_STATUS', l_p.party_status));
        put('P0_PARTY_NEXT_KYC_DATE',       to_char(l_p.next_kyc_date, 'DD-MON-YYYY'));
        put('P0_PARTY_ENABLED_FLAG',        nvl(l_p.enabled_flag, 'Y'));
        put('P0_PARTY_READ_ONLY',           case when p_read_only = 'Y' then 'Y' else 'N' end);
    exception
        when others then
            xxfnd_vpd_pkg.end_trusted;
            raise;
    end load_items;

    function relationship_error(p_relationship_id   in number,
                                p_object_party_id   in number,
                                p_relationship_type in varchar2,
                                p_percentage        in number,
                                p_start_date        in date,
                                p_end_date          in date) return varchar2 is
        l_total number;
    begin
        if p_relationship_type is null then
            return 'Choose the relationship.';
        elsif instr(c_ownership_types, ':' || p_relationship_type || ':') > 0 and p_percentage is null then
            return 'Enter the ownership % of a ' || lower(xxfnd_util_pkg.lookup_meaning('RELATIONSHIP_TYPE', p_relationship_type)) || '.';
        elsif instr(c_ownership_types, ':' || p_relationship_type || ':') = 0 and p_percentage is not null then
            return 'Ownership % applies only to shareholders, beneficial owners and parent companies.';
        elsif p_percentage not between 0 and 100 then
            return 'Ownership % is between 0 and 100.';
        elsif p_end_date < p_start_date then
            return 'The end date cannot be before the start date.';
        end if;
        if p_percentage is not null and (p_end_date is null or p_end_date >= trunc(sysdate)) then
            select nvl(sum(ownership_percentage), 0) into l_total
              from xxcmp_party_relationships
             where object_party_id = p_object_party_id
               and party_relationship_id <> nvl(p_relationship_id, -1)
               and instr(c_ownership_types, ':' || relationship_type || ':') > 0
               and (end_date is null or end_date >= trunc(sysdate));
            if l_total + p_percentage > 100 then
                return 'The active owners would hold ' || (l_total + p_percentage) || '%: at most 100% (others hold '
                       || l_total || '%).';
            end if;
        end if;
        return null;
    end relationship_error;

    procedure merge_parties(p_from_party_id in number, p_into_party_id in number, p_note in varchar2 default null) is
        l_from xxcmp_parties%rowtype;
        l_into xxcmp_parties%rowtype;
    begin
        if not xxfnd_privilege_pkg.has_privilege('PARTIES', 'MANAGE') then
            raise_application_error(-20711, 'Only Compliance can merge parties.');
        elsif p_from_party_id is null or p_into_party_id is null or p_from_party_id = p_into_party_id then
            raise_application_error(-20712, 'Choose another party to merge into.');
        end if;
        select * into l_from from xxcmp_parties where party_id = p_from_party_id for update;
        select * into l_into from xxcmp_parties where party_id = p_into_party_id for update;
        if l_from.party_type <> l_into.party_type then
            raise_application_error(-20713, 'An organisation cannot be merged into an individual, or the reverse.');
        elsif l_from.enabled_flag = 'N' or l_into.enabled_flag = 'N' then
            raise_application_error(-20714, 'Both parties must be enabled.');
        end if;

        -- everything recorded against the duplicate now belongs to the kept party
        update xxcmp_requests   set party_id = p_into_party_id,
                                    match_status = case when party_selection = 'NEW' then 'MERGED' else match_status end,
                                    match_resolved_by = xxfnd_util_pkg.current_user, match_resolved_date = systimestamp
         where party_id = p_from_party_id;
        update xxcmp_cases      set party_id = p_into_party_id where party_id = p_from_party_id;
        update xxcmp_screenings set party_id = p_into_party_id where party_id = p_from_party_id;
        update xxcmp_alerts     set party_id = p_into_party_id where party_id = p_from_party_id;
        update xxcmp_case_notes set related_party_id = p_into_party_id where related_party_id = p_from_party_id;
        -- one beneficial-owner decision per case and owner
        delete from xxcmp_ubo_determinations u
         where u.owner_party_id = p_from_party_id
           and exists (select 1 from xxcmp_ubo_determinations k where k.case_id = u.case_id and k.owner_party_id = p_into_party_id);
        update xxcmp_ubo_determinations set owner_party_id = p_into_party_id where owner_party_id = p_from_party_id;
        -- contacts move as non-primary (the kept party keeps its primary contact)
        update xxcmp_party_contacts set party_id = p_into_party_id, primary_flag = 'N' where party_id = p_from_party_id;
        -- relationships: a relationship between the two parties would point to itself
        delete from xxcmp_party_relationships
         where (subject_party_id = p_from_party_id and object_party_id = p_into_party_id)
            or (subject_party_id = p_into_party_id and object_party_id = p_from_party_id);
        update xxcmp_party_relationships set subject_party_id = p_into_party_id where subject_party_id = p_from_party_id;
        update xxcmp_party_relationships set object_party_id  = p_into_party_id where object_party_id  = p_from_party_id;
        -- documents
        update xxfnd_attached_documents set pk1_value = to_char(p_into_party_id)
         where entity_name = 'XXCMP_PARTIES' and pk1_value = to_char(p_from_party_id);

        -- the kept party's empty details are completed from the duplicate
        update xxcmp_parties
           set registration_number = nvl(registration_number, l_from.registration_number),
               entity_type         = nvl(entity_type, l_from.entity_type),
               incorporation_date  = nvl(incorporation_date, l_from.incorporation_date),
               jurisdiction        = nvl(jurisdiction, l_from.jurisdiction),
               email               = nvl(email, l_from.email),
               phone               = nvl(phone, l_from.phone),
               website             = nvl(website, l_from.website),
               fax                 = nvl(fax, l_from.fax)
         where party_id = p_into_party_id;
        update xxcmp_parties
           set enabled_flag = 'N', merged_into_party_id = p_into_party_id, merge_note = substr(p_note, 1, 1000)
         where party_id = p_from_party_id;
    end merge_parties;

    function is_enabled(p_party_id in number) return varchar2 is
        l_flag xxcmp_parties.enabled_flag%type;
    begin
        xxfnd_vpd_pkg.begin_trusted;    -- also asked for a requester's chosen party
        select max(enabled_flag) into l_flag from xxcmp_parties where party_id = p_party_id;
        xxfnd_vpd_pkg.end_trusted;
        return case when l_flag = 'Y' then 'Y' else 'N' end;
    exception
        when others then
            xxfnd_vpd_pkg.end_trusted;
            raise;
    end is_enabled;

    function card_html(p_party_id in number) return clob is
        l_p      xxcmp_parties%rowtype;
        l_into   xxcmp_parties.party_number%type;
        l_html   clob;
        l_found  boolean := false;

        procedure row(p_label in varchar2, p_value in varchar2, p_raw in boolean default false) is
        begin
            if p_value is not null then
                l_html := l_html || '<dt class="t-AVPList-label">' || apex_escape.html(p_label) || '</dt>'
                               || '<dd class="t-AVPList-value">' || case when p_raw then p_value else apex_escape.html(p_value) end
                               || '</dd>';
            end if;
        end row;
    begin
        if p_party_id is null then
            return '<p class="u-color-subtle">No party linked yet.</p>';
        end if;
        for r in (select * from xxcmp_parties where party_id = p_party_id) loop     -- data security applies
            l_p := r;
            l_found := true;
        end loop;
        if not l_found then
            return '<p class="u-color-subtle">The party details are available to Compliance.</p>';
        end if;
        select max(party_number) into l_into from xxcmp_parties where party_id = l_p.merged_into_party_id;

        l_html := '<dl class="t-AVPList t-AVPList--leftAligned">';
        row('Party', case when xxfnd_privilege_pkg.has_privilege('PARTIES', 'VIEW')
                          then '<a href="' || apex_page.get_url(p_page => 21, p_items => 'P21_PARTY_ID',
                                                                 p_values => to_char(l_p.party_id), p_clear_cache => '21')
                               || '">' || apex_escape.html(l_p.party_number) || '</a>'
                          else apex_escape.html(l_p.party_number) end
                     || ' - ' || apex_escape.html(l_p.party_name), true);
        row('Type', xxfnd_util_pkg.lookup_meaning('PARTY_TYPE', l_p.party_type));
        row(field_label(l_p.party_type, 'REGISTRATION_NUMBER'), l_p.registration_number);
        row(field_label(l_p.party_type, 'ENTITY_TYPE'), xxfnd_util_pkg.lookup_meaning(entity_lookup(l_p.party_type), l_p.entity_type));
        row(field_label(l_p.party_type, 'INCORPORATION_DATE'), to_char(l_p.incorporation_date, 'DD-MON-YYYY'));
        row(field_label(l_p.party_type, 'JURISDICTION'), xxfnd_util_pkg.lookup_meaning('JURISDICTION', l_p.jurisdiction));
        row('Email', l_p.email);
        row('Phone', l_p.phone);
        row('Website', l_p.website);
        for c in (select contact_name as name, job_title, email, phone
                    from xxcmp_party_contacts
                   where party_id = p_party_id and enabled_flag = 'Y'
                   order by primary_flag desc, party_contact_id
                   fetch first 1 row only) loop
            row('Contact Person', c.name || nvl2(c.job_title, ' (' || c.job_title || ')', null)
                                  || nvl2(c.email, ', ' || c.email, null) || nvl2(c.phone, ', ' || c.phone, null));
        end loop;
        row('Party Status', case when l_p.merged_into_party_id is not null then 'Merged into ' || l_into
                                 when l_p.enabled_flag = 'N' then 'Disabled'
                                 else xxfnd_util_pkg.lookup_meaning('PARTY_STATUS', l_p.party_status) end
                            || nvl2(l_p.last_verified_date, ' - verified ' || to_char(l_p.last_verified_date, 'DD-MON-YYYY'), null));
        row('Next KYC Date', to_char(l_p.next_kyc_date, 'DD-MON-YYYY'));
        return l_html || '</dl>';
    end card_html;

end xxcmp_party_pkg;
/

-- ==== 16f-party-request-redesign.sql
--------------------------------------------------------------------------------
-- 16f Party and request redesign (release 23)
--   One column per organisation / individual pair (the label changes with the party type):
--     JURISDICTION        Country / Nationality        (NATIONALITY dropped)
--     REGISTRATION_NUMBER Registration No. / ID Number (ID_NUMBER dropped)
--     ENTITY_TYPE         Entity Type / ID Type        (ID_TYPE dropped)
--     INCORPORATION_DATE  Incorporation / Birth date   (DATE_OF_BIRTH dropped)
--   on XXCMP_PARTIES and XXCMP_REQUESTS; contact persons without CONTACT_TYPE / CONTACT_VALUE;
--   relationships without OFFICER_CORRECTED_FLAG / LATEST_UBO_STATUS; request statuses
--   Draft, In Progress, Information Needed, Approved, Rejected, Cancelled; party status.
-- Data is moved before a column is dropped. Every step checks the current state first, so the
-- script is safe on install (04/16b still create the older shape) and on every upgrade.
--------------------------------------------------------------------------------
declare
    function has_col(p_table in varchar2, p_column in varchar2) return boolean is
        l_count pls_integer;
    begin
        select count(*) into l_count from user_tab_columns where table_name = p_table and column_name = p_column;
        return l_count > 0;
    end has_col;

    function has_cons(p_name in varchar2) return boolean is
        l_count pls_integer;
    begin
        select count(*) into l_count from user_constraints where constraint_name = p_name;
        return l_count > 0;
    end has_cons;

    procedure run(p_sql in varchar2) is
    begin
        execute immediate p_sql;
    end run;

    procedure drop_col(p_table in varchar2, p_column in varchar2) is
    begin
        if has_col(p_table, p_column) then
            run('alter table ' || p_table || ' drop column ' || p_column);
        end if;
    end drop_col;

    procedure drop_cons(p_table in varchar2, p_name in varchar2) is
    begin
        if has_cons(p_name) then
            run('alter table ' || p_table || ' drop constraint ' || p_name);
        end if;
    end drop_cons;

    -- an individual's values move into the organisation column of the pair (where still empty)
    procedure merge_pairs(p_table in varchar2) is
    begin
        if has_col(p_table, 'NATIONALITY') then
            run('update ' || p_table || q'[ set jurisdiction = nvl(nationality, jurisdiction) where party_type = 'PERSON']');
        end if;
        if has_col(p_table, 'ID_NUMBER') then
            run('update ' || p_table || q'[ set registration_number = nvl(registration_number, id_number) where party_type = 'PERSON']');
        end if;
        if has_col(p_table, 'ID_TYPE') then
            run('update ' || p_table || q'[ set entity_type = nvl(entity_type, id_type) where party_type = 'PERSON']');
        end if;
        if has_col(p_table, 'DATE_OF_BIRTH') then
            run('update ' || p_table || q'[ set incorporation_date = nvl(incorporation_date, date_of_birth) where party_type = 'PERSON']');
        end if;
        drop_col(p_table, 'NATIONALITY');
        drop_col(p_table, 'ID_NUMBER');
        drop_col(p_table, 'ID_TYPE');
        drop_col(p_table, 'DATE_OF_BIRTH');
    end merge_pairs;
begin
    ---------------------------------------------------------------- parties
    -- identity document numbers are up to 100 characters (the function-based index is rebuilt around it)
    for c in (select 1 from user_tab_columns
               where table_name = 'XXCMP_PARTIES' and column_name = 'REGISTRATION_NUMBER' and data_length < 100) loop
        for i in (select index_name from user_indexes where index_name = 'XXCMP_PARTIES_N4') loop
            run('drop index xxcmp_parties_n4');
        end loop;
        run('alter table xxcmp_parties modify (registration_number varchar2(100))');
    end loop;
    for i in (select 1 from dual where not exists (select 1 from user_indexes where index_name = 'XXCMP_PARTIES_N4')) loop
        run(q'[create index xxcmp_parties_n4 on xxcmp_parties (upper(replace(registration_number, ' ')))]');
    end loop;
    -- the old rule "organisation fields only for organisations" no longer applies: the columns are shared
    drop_cons('XXCMP_PARTIES', 'XXCMP_PARTIES_CK4');
    merge_pairs('XXCMP_PARTIES');
    if not has_cons('XXCMP_PARTIES_CK5') then
        run(q'[alter table xxcmp_parties add constraint xxcmp_parties_ck5
                   check (party_status in ('PENDING','APPROVED','REJECTED','CANCELLED'))]');
    end if;

    ---------------------------------------------------------------- requests (the counterparty typed on the request)
    merge_pairs('XXCMP_REQUESTS');
    -- statuses: Draft, In Progress, Information Needed, Approved, Rejected, Cancelled
    for c in (select constraint_name from user_constraints
               where constraint_name = 'XXCMP_REQUESTS_CK3' and search_condition_vc like '%SUBMITTED%') loop
        run('alter table xxcmp_requests drop constraint xxcmp_requests_ck3');
    end loop;
    run(q'[update xxcmp_requests set request_status = 'IN_PROGRESS' where request_status = 'SUBMITTED']');
    run(q'[update xxcmp_requests set request_status = 'APPROVED'    where request_status = 'COMPLETED']');
    if not has_cons('XXCMP_REQUESTS_CK3') then
        run(q'[alter table xxcmp_requests add constraint xxcmp_requests_ck3
                   check (request_status in ('DRAFT','IN_PROGRESS','INFO_NEEDED','APPROVED','REJECTED','CANCELLED'))]');
    end if;
    run(q'[update xxcmp_requests set last_action_date = cast(coalesce(completed_date, submitted_date, last_update_date) as date)
            where last_action_date is null]');

    ---------------------------------------------------------------- contact persons
    if has_col('XXCMP_PARTY_CONTACTS', 'CONTACT_TYPE') then
        -- the party's main email / phone / website from its older contact rows (only where still empty)
        run(q'[update xxcmp_parties p
                  set email = (select max(c.contact_value) keep (dense_rank first order by c.primary_flag desc, c.party_contact_id)
                                 from xxcmp_party_contacts c
                                where c.party_id = p.party_id and c.contact_type = 'EMAIL' and c.enabled_flag = 'Y')
                where p.email is null]');
        run(q'[update xxcmp_parties p
                  set phone = (select max(c.contact_value) keep (dense_rank first order by c.primary_flag desc, c.party_contact_id)
                                 from xxcmp_party_contacts c
                                where c.party_id = p.party_id and c.contact_type in ('PHONE', 'MOBILE') and c.enabled_flag = 'Y')
                where p.phone is null]');
        run(q'[update xxcmp_parties p
                  set website = (select max(c.contact_value) keep (dense_rank first order by c.primary_flag desc, c.party_contact_id)
                                   from xxcmp_party_contacts c
                                  where c.party_id = p.party_id and c.contact_type = 'WEBSITE' and c.enabled_flag = 'Y')
                where p.website is null]');
        -- every older row becomes a contact person (nothing is lost): its email / phone, and a name
        run(q'[update xxcmp_party_contacts
                  set email = nvl(email, case when contact_type = 'EMAIL' then contact_value end),
                      phone = nvl(phone, case when contact_type in ('PHONE', 'MOBILE') then contact_value end),
                      contact_name = nvl(contact_name, contact_value)
                where contact_type <> 'PERSON']');
        -- one primary contact person per party (before: one per contact type)
        run(q'[update xxcmp_party_contacts c set primary_flag = 'N'
                where primary_flag = 'Y'
                  and party_contact_id <> (select max(k.party_contact_id) keep (dense_rank first
                                                  order by case when k.contact_type = 'PERSON' then 0 else 1 end, k.party_contact_id)
                                             from xxcmp_party_contacts k where k.party_id = c.party_id and k.primary_flag = 'Y')]');
        for i in (select index_name from user_indexes where index_name = 'XXCMP_PARTY_CONTACTS_U1') loop
            run('drop index xxcmp_party_contacts_u1');
        end loop;
        drop_col('XXCMP_PARTY_CONTACTS', 'CONTACT_TYPE');
        drop_col('XXCMP_PARTY_CONTACTS', 'CONTACT_VALUE');
    end if;
    for i in (select 1 from dual where not exists (select 1 from user_indexes where index_name = 'XXCMP_PARTY_CONTACTS_U1')) loop
        run('create unique index xxcmp_party_contacts_u1 on xxcmp_party_contacts (case when primary_flag = ''Y'' then party_id end)');
    end loop;
    run(q'[update xxcmp_party_contacts set contact_name = 'Contact' where contact_name is null]');
    for c in (select 1 from user_tab_columns
               where table_name = 'XXCMP_PARTY_CONTACTS' and column_name = 'CONTACT_NAME' and nullable = 'Y') loop
        run('alter table xxcmp_party_contacts modify (contact_name not null)');
    end loop;

    ---------------------------------------------------------------- owners / officers
    drop_col('XXCMP_PARTY_RELATIONSHIPS', 'OFFICER_CORRECTED_FLAG');
    drop_col('XXCMP_PARTY_RELATIONSHIPS', 'LATEST_UBO_STATUS');

    ---------------------------------------------------------------- next KYC date of parties with an approved case
    run(q'[update xxcmp_parties p
              set next_kyc_date = (select max(c.next_review_date) keep (dense_rank last order by c.closed_date)
                                     from xxcmp_cases c where c.party_id = p.party_id and c.decision = 'APPROVED')
            where p.next_kyc_date is null
              and exists (select 1 from xxcmp_cases c where c.party_id = p.party_id and c.decision = 'APPROVED')]');
    commit;
end;
/
comment on table xxcmp_party_contacts is 'Contact persons of a party (name, job title, email, phone); one primary per party.';
comment on column xxcmp_parties.jurisdiction is 'Organisation: country of incorporation. Individual: nationality.';
comment on column xxcmp_parties.registration_number is 'Organisation: registration number. Individual: identity document number.';
comment on column xxcmp_parties.entity_type is 'Organisation: entity type (lookup ENTITY_TYPE). Individual: identity document type (lookup ID_DOCUMENT_TYPE).';
comment on column xxcmp_parties.incorporation_date is 'Organisation: date of incorporation. Individual: date of birth.';
comment on column xxcmp_requests.last_action_date is 'When the request last moved: saved, submitted, information requested / given, approved, rejected, cancelled.';

-- ==== 18e-kyc-requests-cases.sql
--------------------------------------------------------------------------------
-- 18e KYC requests and cases - seed (release R13)
-- Lookups, attachment entities, KYC parameters, starter questionnaires, data
-- security rules, page mapping and task deadlines for Module 1 and Module 2.
-- Idempotent; everything an administrator maintains is insert-only.
--------------------------------------------------------------------------------
declare
    c_staff constant varchar2(200) := 'COMPLIANCE_OFFICER,COMPLIANCE_MANAGER,HEAD_OF_COMPLIANCE';

    procedure lt(p_type in varchar2, p_meaning in varchar2, p_level in varchar2 default 'S') is
    begin
        merge into xxfnd_lookup_types t using (select p_type lookup_type from dual) s on (t.lookup_type = s.lookup_type)
         when not matched then insert (lookup_type, meaning, customization_level, application_code)
                               values (p_type, p_meaning, p_level, 'KYC');
    end lt;

    -- 'CODE=Meaning|CODE=Meaning' ; 'CODE=Meaning=TAG' sets the tag
    procedure lvs(p_type in varchar2, p_list in varchar2) is
        l_parts apex_t_varchar2;
        l_seq   pls_integer := 0;
        l_tag   varchar2(150);
    begin
        for v in (select column_value item from table(apex_string.split(p_list, '|'))) loop
            l_seq   := l_seq + 10;
            l_parts := apex_string.split(v.item, '=');
            l_tag   := case when l_parts.count > 2 then l_parts(3) end;   -- collection attributes: not inside SQL
            merge into xxfnd_lookup_values t
            using (select p_type lookup_type, l_parts(1) lookup_code from dual) s
               on (t.lookup_type = s.lookup_type and t.lookup_code = s.lookup_code)
             when not matched then insert (lookup_type, lookup_code, meaning, display_sequence, tag)
                                   values (p_type, l_parts(1), l_parts(2), l_seq, l_tag);
        end loop;
    end lvs;

    procedure entity(p_name in varchar2, p_user_name in varchar2, p_pk in varchar2) is
    begin
        merge into xxfnd_document_entities t using (select p_name entity_name from dual) s
           on (t.entity_name = s.entity_name)
         when matched then update set t.enabled_flag = 'Y' where t.table_name = p_name and t.enabled_flag = 'N'
         when not matched then insert (entity_name, application_code, table_name, pk1_column, enabled_flag)
                               values (p_name, 'KYC', p_name, p_pk, 'Y');
        merge into xxfnd_document_entities_tl t
        using (select p_name entity_name, 'en' language_code from dual) s
           on (t.entity_name = s.entity_name and t.language_code = s.language_code)
         when not matched then insert (entity_name, language_code, user_entity_name) values (p_name, 'en', p_user_name);
    end entity;

    function question(p_qnr in varchar2, p_seq in number, p_text in varchar2, p_type in varchar2,
                      p_gate in varchar2 default 'N', p_required in varchar2 default 'Y',
                      p_section in varchar2 default null) return number is
        l_id number;
    begin
        insert into xxcmp_questions (questionnaire_code, question_text, answer_type, gate_question_flag, required_flag,
                                     display_sequence, section_name)
        values (p_qnr, p_text, p_type, p_gate, p_required, p_seq, p_section)
        returning question_id into l_id;
        return l_id;
    end question;

    procedure answer(p_question in number, p_seq in number, p_label in varchar2, p_points in number,
                     p_critical in varchar2 default 'N', p_waiver in varchar2 default 'N') is
    begin
        insert into xxcmp_answer_options (question_id, answer_label, risk_points, critical_flag, waiver_qualifying_flag,
                                          display_sequence, approval_status)
        values (p_question, p_label, p_points, p_critical, p_waiver, p_seq, 'APPROVED');
    end answer;

    procedure starter_questions is
        l_q     number;
        l_count pls_integer;
    begin
        -- Starter content only for questionnaires that have no questions yet.
        select count(*) into l_count from xxcmp_questions where questionnaire_code = 'CORPORATE';
        if l_count = 0 then
            l_q := question('CORPORATE', 10, 'Is the counterparty listed on a regulated stock exchange, or a government entity?', 'YES_NO', p_gate => 'Y');
            answer(l_q, 10, 'Yes', 0, p_waiver => 'Y');
            answer(l_q, 20, 'No', 0);
            l_q := question('CORPORATE', 20, 'Risk of the country of incorporation', 'SINGLE_SELECT');
            answer(l_q, 10, 'Low-risk jurisdiction', 0);
            answer(l_q, 20, 'Medium-risk jurisdiction', 5);
            answer(l_q, 30, 'High-risk or sanctioned jurisdiction', 20, p_critical => 'Y');
            l_q := question('CORPORATE', 30, 'Expected annual transaction volume', 'SINGLE_SELECT');
            answer(l_q, 10, 'Below 1 million', 0);
            answer(l_q, 20, '1 to 10 million', 5);
            answer(l_q, 30, 'Above 10 million', 10);
            l_q := question('CORPORATE', 40, 'Is any owner, director or signatory a politically exposed person?', 'YES_NO');
            answer(l_q, 10, 'Yes', 15, p_critical => 'Y');
            answer(l_q, 20, 'No', 0);
            l_q := question('CORPORATE', 50, 'Is the business cash-intensive?', 'YES_NO');
            answer(l_q, 10, 'Yes', 10);
            answer(l_q, 20, 'No', 0);
        end if;
        select count(*) into l_count from xxcmp_questions where questionnaire_code = 'INDIVIDUAL';
        if l_count = 0 then
            l_q := question('INDIVIDUAL', 10, 'Is the individual an employee of the organisation acting in that capacity?', 'YES_NO', p_gate => 'Y');
            answer(l_q, 10, 'Yes', 0, p_waiver => 'Y');
            answer(l_q, 20, 'No', 0);
            l_q := question('INDIVIDUAL', 20, 'Risk of the country of residence', 'SINGLE_SELECT');
            answer(l_q, 10, 'Low-risk jurisdiction', 0);
            answer(l_q, 20, 'Medium-risk jurisdiction', 5);
            answer(l_q, 30, 'High-risk or sanctioned jurisdiction', 20, p_critical => 'Y');
            l_q := question('INDIVIDUAL', 30, 'Is the individual a politically exposed person?', 'YES_NO');
            answer(l_q, 10, 'Yes', 15, p_critical => 'Y');
            answer(l_q, 20, 'No', 0);
        end if;
        select count(*) into l_count from xxcmp_questions where questionnaire_code = 'OFFICER_INVESTIGATION';
        if l_count = 0 then
            l_q := question('OFFICER_INVESTIGATION', 10, 'Summary of findings', 'TEXT', p_required => 'N', p_section => 'Findings');
            l_q := question('OFFICER_INVESTIGATION', 20, 'Source of funds', 'TEXT', p_required => 'N', p_section => 'Enhanced Due Diligence');
            l_q := question('OFFICER_INVESTIGATION', 30, 'Source of wealth', 'TEXT', p_required => 'N', p_section => 'Enhanced Due Diligence');
        end if;
    end starter_questions;

    procedure page(p_feature in varchar2, p_page in number, p_tab in varchar2 default null, p_seq in number default null) is
    begin
        merge into xxfnd_feature_pages d
        using (select 'KYC' app_alias, p_page page_id from dual) s
           on (d.app_alias = s.app_alias and d.page_id = s.page_id)
         when matched then update set d.feature_code = p_feature,
                                      d.tab_label    = nvl(d.tab_label, p_tab),
                                      d.tab_sequence = nvl(d.tab_sequence, p_seq)
         when not matched then insert (app_alias, page_id, feature_code, tab_label, tab_sequence)
                               values ('KYC', p_page, p_feature, p_tab, p_seq);
    end page;

    procedure rule(p_role in varchar2, p_table in varchar2, p_type in varchar2, p_column in varchar2 default null) is
    begin
        merge into xxfnd_data_security_rules t
        using (select p_role r, p_table tb, p_type ty from dual) s
           on (t.role_code = s.r and t.table_name = s.tb and t.rule_type = s.ty)
         when not matched then insert (role_code, table_name, rule_type, column_name)
                               values (p_role, p_table, p_type, p_column);
    end rule;

    procedure task_setting(p_task in varchar2, p_due in number, p_reminder in number, p_role in varchar2, p_desc in varchar2) is
    begin
        merge into xxfnd_task_settings t using (select p_task task_definition from dual) s
           on (t.task_definition = s.task_definition)
         when not matched then insert (task_definition, due_days, reminder_days_before, escalation_role_code, description)
                               values (p_task, p_due, p_reminder, p_role, p_desc);
    end task_setting;
begin
    xxfnd_util_pkg.set_install_mode(true);

    lt('KYC_REQUEST_TYPE', 'KYC Request Types');
    lvs('KYC_REQUEST_TYPE', 'NEW_ONBOARDING=New onboarding|PERIODIC_REVIEW=Periodic review|EVENT_TRIGGERED_REVIEW=Event-triggered review');
    lt('KYC_TRIGGER_SOURCE', 'KYC Request Trigger Sources');
    lvs('KYC_TRIGGER_SOURCE', 'MANUAL=Manual|SCHEDULED=Scheduled|EVENT_DRIVEN=Event driven');
    lt('KYC_REQUEST_STATUS', 'KYC Request Status');
    lvs('KYC_REQUEST_STATUS', 'DRAFT=Draft|IN_PROGRESS=In Progress|INFO_NEEDED=Information Needed|APPROVED=Approved'
        || '|REJECTED=Rejected|CANCELLED=Cancelled');
    -- release 23: Submitted and Completed became In Progress and Approved
    update xxfnd_lookup_values set enabled_flag = 'N'
     where lookup_type = 'KYC_REQUEST_STATUS' and lookup_code in ('SUBMITTED', 'COMPLETED') and enabled_flag = 'Y';
    update xxfnd_lookup_values set meaning = 'In Progress', display_sequence = 20
     where lookup_type = 'KYC_REQUEST_STATUS' and lookup_code = 'IN_PROGRESS' and meaning = 'In progress';
    lt('PARTY_STATUS', 'Party Status');
    lvs('PARTY_STATUS', 'PENDING=Pending|APPROVED=Approved|REJECTED=Rejected|CANCELLED=Cancelled');
    lt('ID_DOCUMENT_TYPE', 'Identity Document Types', 'E');
    lvs('ID_DOCUMENT_TYPE', 'PASSPORT=Passport|NATIONAL_ID=National ID card|RESIDENCE_PERMIT=Residence permit');
    lt('REQUEST_MATCH_STATUS', 'Counterparty Match Status');
    lvs('REQUEST_MATCH_STATUS', 'SELECTED=Existing party chosen|NEW=New party|PENDING=Possible match - Compliance to decide'
        || '|MERGED=Merged into an existing party|CONFIRMED_NEW=Confirmed as a new party');
    lt('KYC_INTAKE_OUTCOME', 'KYC Intake Outcomes');
    lvs('KYC_INTAKE_OUTCOME', 'NOT_REQUIRED=KYC not required|AUTO_APPROVED=Auto-approved|ASSIGNED=Assigned to Compliance');
    lt('CASE_STATUS', 'Case Status');
    lvs('CASE_STATUS', 'INVESTIGATION=Under investigation|PENDING_APPROVAL=Pending approval|APPROVED=Approved|REJECTED=Rejected|CANCELLED=Cancelled');
    lt('SCREENING_TYPE', 'Screening Types');
    lvs('SCREENING_TYPE', 'REGISTRY=Registry check|SANCTIONS=Sanctions|PEP=Politically exposed person|ADVERSE_MEDIA=Adverse media');
    lt('SCREENING_MATCH_STATUS', 'Screening Match Status');
    lvs('SCREENING_MATCH_STATUS', 'NO_MATCH=No match|POTENTIAL_MATCH=Potential match|CONFIRMED_MATCH=Confirmed match|FALSE_POSITIVE=False positive');
    lt('DOC_VERIFICATION_STATUS', 'Document Verification Status');
    lvs('DOC_VERIFICATION_STATUS', 'VERIFIED=Verified|REJECTED=Rejected|EXPIRED=Expired');
    lt('UBO_BASIS', 'Beneficial Ownership Basis');
    lvs('UBO_BASIS', 'OWNERSHIP=Ownership|CONTROL=Control|FALLBACK=Fallback (senior managing official)');
    lt('REQUESTING_DEPARTMENT', 'Requesting Departments', 'E');
    lvs('REQUESTING_DEPARTMENT', 'FINANCE=Finance|PROCUREMENT=Procurement|SALES=Sales|TREASURY=Treasury|LEGAL=Legal|OTHER=Other');
    -- Parameters administrators maintain in Lookups (value in TAG).
    lt('KYC_PARAMETER', 'KYC Parameters', 'E');
    lvs('KYC_PARAMETER', 'CASE_SLA_DAYS=Case investigation SLA (days)=10|PEP_REVIEW_MONTHS=Review interval for PEP parties (months)=12'
        || '|REVIEW_LEAD_DAYS=Show upcoming reviews this many days ahead=30');
    -- Review interval per risk tier, in months (TAG), until an administrator sets another.
    update xxfnd_lookup_values set tag = decode(lookup_code, 'LOW', '36', 'MEDIUM', '24', 'HIGH', '12')
     where lookup_type = 'RISK_TIER' and tag is null;

    entity('XXCMP_REQUESTS', 'KYC Request', 'REQUEST_ID');
    entity('XXCMP_CASES', 'Case', 'CASE_ID');

    starter_questions;
    -- Sections for the starter questions (only where an administrator has not set one).
    for q in (select column_value v from table(apex_t_varchar2(
                  'CORPORATE|10|Listing and Status', 'CORPORATE|20|Geographic Risk', 'CORPORATE|30|Business Activity',
                  'CORPORATE|40|Ownership and Control', 'CORPORATE|50|Business Activity',
                  'INDIVIDUAL|10|Relationship', 'INDIVIDUAL|20|Geographic Risk', 'INDIVIDUAL|30|Politically Exposed Persons'))) loop
        update xxcmp_questions
           set section_name = regexp_substr(q.v, '[^|]+', 1, 3)
         where questionnaire_code = regexp_substr(q.v, '[^|]+', 1, 1)
           and display_sequence   = to_number(regexp_substr(q.v, '[^|]+', 1, 2))
           and section_name is null;
    end loop;

    -- KYC Requests: list, wizard (3 steps), request; Cases: workbench, case, decision, screening, UBO, document verification, new case, compliance report.
    for p in (select column_value page_id from table(apex_t_number(200, 201, 202, 203, 205))) loop
        page('KYC_REQUESTS', p.page_id);
    end loop;
    for p in (select column_value page_id from table(apex_t_number(210, 211, 212, 213, 214, 215, 216, 217))) loop
        page('CASES', p.page_id);
    end loop;
    -- Attachments on the request (wizard step 3 and the request page) and the party documents on the case.
    merge into xxfnd_attachment_functions t
    using (select 'KYC_REQUEST_SUBMIT' function_code, 'Create Request - Submit' function_name, 203 page_id from dual
           union all select 'KYC_REQUEST', 'KYC Request', 205 from dual
           union all select 'KYC_CASE', 'Case', 211 from dual) s
       on (t.function_code = s.function_code)
     when matched then update set t.apex_page_id = s.page_id
     when not matched then insert (function_code, application_code, function_name, apex_app_alias, apex_page_id)
                           values (s.function_code, 'KYC', s.function_name, 'KYC', s.page_id);
    merge into xxfnd_attachment_blocks t
    using (select 'KYC_REQUEST_SUBMIT' function_code, 'ATTACHMENTS' block_code, 'request_attachments' region, 'Documents' name from dual
           union all select 'KYC_REQUEST', 'ATTACHMENTS', 'request_attachments', 'Documents' from dual
           union all select 'KYC_CASE', 'PARTY_DOCUMENTS', 'party_documents', 'Party Documents' from dual) s
       on (t.function_code = s.function_code and t.block_code = s.block_code)
     when not matched then insert (function_code, block_code, region_static_id, block_name, display_sequence)
                           values (s.function_code, s.block_code, s.region, s.name, 10);
    merge into xxfnd_attachment_blk_entities t
    using (select 'KYC_REQUEST_SUBMIT' function_code, 'ATTACHMENTS' block_code, 'XXCMP_REQUESTS' entity_name, 'P203_REQUEST_ID' item, 'Y' del from dual
           union all select 'KYC_REQUEST', 'ATTACHMENTS', 'XXCMP_REQUESTS', 'P205_REQUEST_ID', 'N' from dual
           union all select 'KYC_CASE', 'PARTY_DOCUMENTS', 'XXCMP_PARTIES', 'P211_PARTY_ID', 'N' from dual) s
       on (t.function_code = s.function_code and t.block_code = s.block_code and t.entity_name = s.entity_name)
     when not matched then insert (function_code, block_code, entity_name, pk1_page_item, delete_allowed_flag, display_sequence)
                           values (s.function_code, s.block_code, s.entity_name, s.item, s.del, 10);

    -- My Tasks tabs: the task list and the requests for information.
    page('MY_TASKS', 40, 'Tasks', 10);
    page('MY_TASKS', 30, 'Requests for Information', 20);

    -- Row access: requesters see their own requests; the Compliance team every request and case.
    for r in (select column_value role_code from table(apex_string.split(c_staff, ','))) loop
        rule(r.role_code, 'XXCMP_REQUESTS', 'ALL_ROWS');
        rule(r.role_code, 'XXCMP_CASES', 'ALL_ROWS');
    end loop;
    rule('REQUESTER', 'XXCMP_REQUESTS', 'OWN_RECORDS', 'REQUESTER_USER_NAME');

    -- KYC Requests: requesters raise and edit their own; Compliance views them and raises reviews.
    for g in (select 'REQUESTER' r, column_value p from table(apex_t_varchar2('KYC_REQUESTS.VIEW','KYC_REQUESTS.CREATE','KYC_REQUESTS.MANAGE'))
              union all
              select s.column_value, p.column_value
                from table(apex_string.split(c_staff, ',')) s,
                     table(apex_t_varchar2('KYC_REQUESTS.VIEW','KYC_REQUESTS.CREATE')) p) loop
        merge into xxfnd_role_privileges t using (select g.r role_code, g.p privilege_code from dual) s
           on (t.role_code = s.role_code and t.privilege_code = s.privilege_code)
         when not matched then insert (role_code, privilege_code) values (s.role_code, s.privilege_code);
    end loop;

    task_setting('COUNTERPARTY_MATCH', 2, 1, 'COMPLIANCE_MANAGER', 'Compliance decides whether a new counterparty is an existing party.');
    task_setting('DOC_CHECKLIST_REVIEW', 2, 1, 'COMPLIANCE_MANAGER', 'Compliance checks the documents of a request before investigation.');
    task_setting('CASE_INVESTIGATION', 10, 2, 'COMPLIANCE_MANAGER', 'The officer investigates the case.');
    task_setting('CASE_APPROVAL', 3, 1, 'HEAD_OF_COMPLIANCE', 'An approver decides the case (one task per approval level).');

    xxfnd_util_pkg.set_install_mode(false);
    commit;
    xxfnd_vpd_pkg.apply_policies;
    xxfnd_ddl_pkg.mark_release('R13', 'Release 13: KYC requests and cases (intake, investigation, approval workflows)');
    commit;
end;
/

begin
    dbms_utility.compile_schema(user, false);
end;
/
select object_name, object_type, status from user_objects where status = 'INVALID';
select table_name, column_name from user_tab_columns
 where table_name in ('XXCMP_PARTIES', 'XXCMP_REQUESTS') and column_name in ('PARTY_STATUS', 'NEXT_KYC_DATE', 'LAST_ACTION_DATE');
